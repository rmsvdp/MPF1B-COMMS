﻿/************************************************************************
*
* EN CURSO
* Este core implementa :
*           -- CPU Z80
* instrucciones, todas menos las siguientes
* IN[en curso]
* 21/07/2025 Implementado , junto con el i8255 una gestión basica basada
* en updateInput pero se sale el array
*  
* OUT[PENDIENTE]
* interrupciones, lo implementado en el core
* Sistema[PENDIENTE]
*           -- Esquema de memoria ---
* ROM        4K , en páginas de 2K
* RAM        60K, en páginas de 2k
* Toda la memoria es accesible, sin ninguna restricción
*           -- Periféricos --
* Teclado[en curso]

 * * 19/07/2025  Codificando la disposición del teclado
*               #r2#
*    22/07/2025 El método updateInput() ya genera el array de teclas
* Display[en curso]
*    22/07/2025  Añadido control custom que simula un led de 7 segmentos
*    sólo construido e inicializado en tiempo de diseño
*    24/07/2025 Implementado código que captura las llamadas a la rutina scan
*    y genera un Action al Form1 para que pinte los valores. Se usa el valor
*    del registro IX que contiene el puntero a los valores que utilizará 
*    SCAN1 y se convierten a la tabla de valores que interpreta el control
*    SevenSegmentsLed.
*    
* Buzzer[PENDIENTE]
* Z80 PIO[PENDIENTE]
* Z80 CTC[PENDIENTE]
* I8255[en curso]
*  24/07/2025 Modelo básico para lectura y escritura de registros
*  la gestión del display se hace capturando las llamadas a la rutina scan1
*  la gestión del teclado se hace generando una matriz virtual, en función
*  de los valores que se pasan a los registros del i8255
*/
#define NEW_RZX_METHODS

using System;
using System.ComponentModel;
using System.IO;
using System.Drawing;
using Peripherals;
using System.Windows.Forms;

namespace Multitech
{
    public static class Mpf1bLayout
    {
 
    public static string[] Keywords = { "RESET","MOVE","INS","SBR",
            "PC","MONI","RELA","DEL","CBR","REG","INT","TAPE WR","STEP",
            "-","DATA","USER KEY","TAPE RD","GO","+","ADDR"
        };
    };

    // Disposición de lectura del teclado
    // El orden se corresponde con el Position Code
    // que devuelve la rutina SCAN1
    /* 
        * F1   GO          -       -
        * F2   STEP        +       +
        * F3   REG         S       TPWR
        * F4   PC          L       TPRD
        * F5   ADDR        N.A     RESET
        * F6   DATA        N.A     MONI
        * F7   CBR         N.A     INTR
        * F8   SBR         N.A     USER KEY
        * F9   RELA
        * F10  DEL
        * F11  INS
        * F12  MOVE
        * 
 */

    public enum keyCode
    {
        _3,                     // row 0 - 0
        _7,
        _B,
        _F,
        _X1,
        _X2,
        _2,                     // row 1 - 0
        _6,
        _A,
        _E,
        _X3,
        _X4,
        _1,
        _5,
        _9,
        _D,
        _STEP,      //F2
        _TPRD,      //L
        _0,
        _4,
        _8,
        _C,
        _GO,        //F1
        _TPWR,      //S
        _CBR,       //F7
        _PC,        //F4
        _REG,       //F3
        _ADDR,      //F5
        _DEL,       //F10
        _RELA,      //F9
        _SBR,       //F8
        _MINUS,     //-
        _DATA,      //F6
        _PLUS,      //+
        _INS,       //F11
        _MOVE,      //F12
        LAST
    };
    //Modelos de máquinas emuladas
    public enum MachineModel
    {
        _48k,                       // Reservado sin utilizar
        _mpf                        // Mpf 1b
    };



    //Handy enum for Monitor
    public enum MPF_EVENT
    {
        [Description("A")]                          OPCODE_A,
        [Description("PC")]                         OPCODE_PC,
        [Description("HL")]                         OPCODE_HL,
        [Description("BC")]                         OPCODE_BC,
        [Description("DE")]                         OPCODE_DE,
        [Description("IX")]                         OPCODE_IX,
        [Description("IY")]                         OPCODE_IY,
        [Description("SP")]                         OPCODE_SP,
        [Description("Memory Write")]               MEMORY_WRITE,
        [Description("Memory Read")]                MEMORY_READ,
        [Description("Memory Execute")]             MEMORY_EXECUTE,
        [Description("Port Write")]                 PORT_WRITE,
        [Description("Port Read")]                  PORT_READ,
        [Description("ULA Write")]                  ULA_WRITE,
        [Description("ULA Read")]                   ULA_READ,
        [Description("Retriggered Interrupt")]      RE_INTERRUPT,
        [Description("Interrupt")]                  INTERRUPT,
        [Description("Frame Start")]                FRAME_START,
        [Description("Frame End")]                  FRAME_END
    }

    #region Delegates and args for mpfBorad related events (used by monitor)
    public class MemoryEventArgs : EventArgs
    {
        private int addr, val;

        public MemoryEventArgs(int _addr, int _val) {
            this.addr = _addr;
            this.val = _val;
        }

        public int Address {
            get {
                return addr;
            }
        }

        public int Byte {
            get {
                return val;
            }
        }
    }

    public class OpcodeExecutedEventArgs : EventArgs { }

     public class PortIOEventArgs : EventArgs
    {
        private int port, val;
        private bool isWrite;

        public PortIOEventArgs(int _port, int _val, bool _write) {
            port = _port;
            val = _val;
            isWrite = _write;
        }

        public int Port {
            get { return port; }
        }

        public int Value {
            get { return val; }
        }

        public bool IsWrite {
            get { return isWrite; }
        }
    }

    public class StateChangeEventArgs : EventArgs
    {
        private MPF_EVENT eventType;

        public StateChangeEventArgs(MPF_EVENT _eventType)
        {
            eventType = _eventType;
        }

        public MPF_EVENT EventType
        {
            get { return eventType; }
        }
    }

    public delegate void MemoryWriteEventHandler(object sender, MemoryEventArgs e);

    public delegate void MemoryReadEventHandler(object sender, MemoryEventArgs e);

    public delegate void MemoryExecuteEventHandler(object sender, MemoryEventArgs e);

    public delegate void OpcodeExecutedEventHandler(object sender);

    public delegate void PortIOEventHandler(object sender, PortIOEventArgs e);

    public delegate void StateChangeEventHandler(object sender, StateChangeEventArgs e);

    public delegate void PopStackEventHandler(object sender, int addr);

    public delegate void PushStackEventHandler(object sender, int addr);

    public delegate void FrameStartEventHandler(object sender);

    public delegate void FrameEndEventHandler(object sender);
    #endregion

    /// <summary>
    /// zxmachine is the heart of mpfBorad emulation.
    /// It includes core execution, ula, sound, input and interrupt handling
    /// </summary>
    public abstract class zxmachine : Z80Core
    {


        public Action<String> display;                  // Disparador de acciones sobre los leds de 7 segmentos
        public Action<String> led_tone;                 // Led Tone (Sonido) PC7
        public Action<String> led_red;                  // Led HALT

        #region Event handlers for the Monitor, primarily
        public event MemoryWriteEventHandler MemoryWriteEvent;
        public event MemoryReadEventHandler MemoryReadEvent;
        public event MemoryExecuteEventHandler MemoryExecuteEvent;
        public event OpcodeExecutedEventHandler OpcodeExecutedEvent;
        public event PortIOEventHandler PortEvent;
        public event StateChangeEventHandler StateChangeEvent;
        //public event PopStackEventHandler PopStackEvent;
       // public event PushStackEventHandler PushStackEvent;
        public event FrameEndEventHandler FrameEndEvent;
        public event FrameStartEventHandler FrameStartEvent;

        protected virtual void OnFrameEndEvent()
        {
            if (FrameEndEvent != null)
                FrameEndEvent(this);
        }
        protected virtual void OnFrameStartEvent()
        {
            if (FrameStartEvent != null)
                FrameStartEvent(this);
        }
        protected virtual void OnMemoryWriteEvent(MemoryEventArgs e) {
            if (MemoryWriteEvent != null)
                MemoryWriteEvent(this, e);
        }
        protected virtual void OnMemoryReadEvent(MemoryEventArgs e) {
            if (MemoryReadEvent != null)
                MemoryReadEvent(this, e);
        }
        protected virtual void OnMemoryExecuteEvent(MemoryEventArgs e) {
            if (MemoryExecuteEvent != null)
                MemoryExecuteEvent(this, e);
        }
        public virtual void OnOpcodeExecutedEvent() {
            if (OpcodeExecutedEvent != null)
                OpcodeExecutedEvent(this);
        }
        protected virtual void OnPortEvent(PortIOEventArgs e) {
            if (PortEvent != null)
                PortEvent(this, e);
        }
        protected virtual void OnStateChangeEvent(StateChangeEventArgs e) {
            if (StateChangeEvent != null)
                StateChangeEvent(this, e);
        }
        protected virtual void OnPopStackEvent(int addr) {
            //if (callStackList.Count > 0)
            //    callStackList.RemoveAt(0);
            //if (PopStackEvent != null)
            //    PopStackEvent(this, addr);
        }
        protected virtual void OnPushStackEvent(int addr, int val) {
            //callStackList.Insert(0, new CallStack(addr, val));
            //if (PushStackEvent != null)
            //    PushStackEvent(this, addr);
        }
        #endregion

        public bool isMpf = false;                      // Booleano para generar excepciones 
                                                        // en máquinas MPF
        public bool dmp = false;                        // necesita redibujar display
        public bool tone = false;                       // led_tone activado
        public bool halt = false;                       // necesita redibujar led_red

        private IntPtr mainHandle;
        //#rmsvdp#
        //--------------------- nuevo modelo de memoria, con tamaños de 2k ( 6116 )
        public int PAGE_SIZE = 2048;                    // Paginas en modelo incial de memoria
        // Linea de scaneo del mpf. Se corresponde con con una columna. comenzando
        // en el extremo derecho del teclado.
        public int[] keyLine = { 255, 255, 255, 255, 255, 255 };
        // Array virtual con los valores según SCAN1 para cada uno de los 6 leds del equipo
        public int[] mpf_leds = { 0,0,0,0,0,0};
        // Array con el estado de los puntos d cada uno de los leds
        public bool[] mpf_dots = { false, false, false, false, false, false };

        //Misc variables
        protected int opcode = 0;
        protected int val, addr;
        public bool isROMprotected = true;  //not really used ATM
        public bool needsPaint = false;     //Raised when the ULA has finished painting the entire screen
        protected bool CapsLockOn = false;

        //Sound
        public const short MIN_SOUND_VOL = 0;
        public const short MAX_SOUND_VOL = short.MaxValue / 2;
        private short[] soundSamples = new short[882 * 2]; //882 samples, 2 channels, 2 bytes per channel (short)
        public MpfSound.SoundManager beeper;
        public const bool ENABLE_SOUND = false;
        protected int averagedSound = 0;
        protected short soundCounter = 0;
        protected int lastSoundOut = 0;
        public short soundOut = 0;
        protected int soundTStatesToSample = 79;
        private float soundVolume = 0f;        //cached reference used when beeper instance is recreated.
        private short soundSampleCounter = 0;
        //Threading stuff (not used)
        public bool doRun = true;           //z80 executes only when true. Mainly for debugging purpose.
        //Machine properties
        protected double clockSpeed;        //the CPU clock speed of the machine
        protected int TstatesPerScanline;   //total # tstates in one scanline
        protected int ScanLineWidth;        //total # pixels in one scanline
        protected int CharRows;             //total # chars in one PRINT row
        protected int CharCols;             //total # chars in one PRINT col
        protected int ScreenWidth;          //total # pixels in one display row
        protected int ScreenHeight;         //total # pixels in one display col
        protected int BorderTopHeight;      //total # pixels in top border
        protected int BorderBottomHeight;   //total # pixels in bottom border
        protected int BorderLeftWidth;      //total # pixels of width of left border
        protected int BorderRightWidth;     //total # pixels of width of right border
        protected int DisplayStart;         //memory address of display start
        protected int DisplayLength;        //total # bytes of display memory
        protected int AttributeStart;       //memory address of attribute start
        protected int AttributeLength;      //total # bytes of attribute memory
        public int LateTiming = 0;       //Some machines have late timings. This affects contention and has to be factored in.
        public bool monitorIsRunning = false;
        //The cpu needs access to this so are public
        public int InterruptPeriod;             //Number of t-states to hold down /INT
        public int FrameLength;                 //Number of t-states of in 1 frame before interrupt is fired.
        private byte FrameCount = 0;            //Used to keep tabs on tape play time out period.

        //Render related stuff
        public bool BeamEna = false;                    // Beeam Flag
        public int[] ScreenBuffer;                        //buffer for the windows side rasterizer
        protected byte[] screen;                           //display memory (16384 for 48k)
        protected short[] attr;                           //attribute memory lookup (mapped 1:1 to screen for convenience)
        protected short[] tstateToDisp;                   //tstate-display mapping
        protected short[] floatingBusTable;               //table that stores tstate to screen/attr addresses values
        protected int lastTState;                         //tstate at which last render update took place
        protected int elapsedTStates;                     //tstates elapsed since last render update
        protected int ActualULAStart;                     //tstate of top left raster pixel
        protected int screenByteCtr;                      //offset into display memory based on current tstate
        protected int ULAByteCtr;                         //offset into current pixel of rasterizer
        public int borderColour;                       //Used by the screen update routine to output border colour
        protected bool flashOn = false;

        //For floating bus implementation
        protected int lastPixelValue;                     //last 8-bit bitmap read from display memory
        protected int lastAttrValue;                      //last 8-bit attr val read from attribute memory
        protected int lastPixelValuePlusOne;              //last 8-bit bitmap read from display memory+1
        protected int lastAttrValuePlusOne;               //last 8-bit attr val read from attribute memory+1


        //These variables are used to create a screen display box (non border area).
        protected int TtateAtLeft, TstateWidth, TstateAtTop,
                      TstateHeight, TstateAtRight, TstateAtBottom;

       //#r#
        //----------------------- MODELO DE MEMORIAS DE 2K HASTA COMPLETAR 64 K
        // -- Microprofessor tiene 4 K de ROM y hasta 4K de RAM, pero consideraremos
        // -- el espacio completo de 64K , completando el resto de los 60K con RAM
        // -- Se implementa un array que permite habilitar/deshabilitar páginas de memoria (2K)
        protected byte[][] RAMpage = new byte[30][];            // 30 pages of 2K bytes each 60K     
        protected byte[][] ROMpage = new byte[2][];             //  2 pages of 2K bytes each  4K
        protected byte[][] JunkMemory = new byte[2][];
        protected Boolean[] PageEnabled = new Boolean [32];       // Habilita memoria a nivel de página ( 2K)
        protected byte[][] PageRDPtr = new byte[32][];          // total direccionado     --> 64 K
        protected byte[][] PageWRPtr = new byte[32][];          // total direccionado     --> 64 K
   

        //This holds the key lines used by the mpfBorad for input
        public bool[] keyBuffer;
        // Variable relacionada con los puertos, especialmente Chip AY
        public bool externalSingleStep = false;

        protected System.Collections.Generic.List<byte> rzxInputs = new System.Collections.Generic.List<byte>();
        public bool isRecordingAVI = false;  // Flag to control AVI recording
        public int RecordingMode = 1;        // Recording mode 0 = AVI, 1 = Raw
        public bool VideoAccessed = false;   // Flag to check if Z80 instrucction modifies video buffer
        public bool isSuspended = true;
        public System.Object lockThis = new System.Object(); //used to synchronise emulation with methods that change emulation state
        public System.Object lockThis2 = new System.Object(); //used by monitor/emulation

        public MachineModel model;
        private int emulationSpeed;
        public bool isResetOver = false;
        private const int MAX_CPU_SPEED = 500;

        //How long should we wait after mpfBorad reset before signalling that it's safe to assume so.
        private int resetFrameTarget = 0;
        private int resetFrameCounter = 0;

        public void Start() {
            display?.Invoke("      ");      // Limpia display
            led_tone?.Invoke("OFF");        // Apaga led verde
            led_red?.Invoke("OFF");         // Apaga led rojo
            doRun = true;
            return;//THREAD
        }

        public void Pause() {
            //beeper.Stop();
            return; //THREAD
        }

        public void Resume() {
            //beeper.Play();
            return;//THREAD
        }

        public void SetEmulationSpeed(int speed) {
            if (speed == 0) {
                speed = MAX_CPU_SPEED;
                soundTStatesToSample = 79;
                beeper.SetVolume(2.0f);
            } else {
                beeper.SetVolume(soundVolume);
                soundTStatesToSample = (int)((FrameLength * (50.0f * (speed / 100.0f))) / 44100.0f);
            }

            emulationSpeed = (speed - 100) / 100; //0 = normal.
        }

        public virtual int GetTotalScreenWidth() {
            return ScreenWidth + BorderLeftWidth + BorderRightWidth;
        }

        public virtual int GetTotalScreenHeight() {
            return ScreenHeight + BorderTopHeight + BorderBottomHeight;
        }

        //The display offset of the mpfBorad screen wrt to emulator window in horizontal direction.
        //Useful for "centering" unorthodox screen dimensions like the Pentagon that has different left & right border width.
        public virtual int GetOriginOffsetX() {
            return 0;
        }

        //The display offset of the mpfBorad screen wrt to emulator window in vertical direction.
        //Useful for "centering" unorthodox screen dimensions like the Pentagon that has different top & bottom border height.
        public virtual int GetOriginOffsetY() {
            return 0;
        }

        public void InsertBookmark() {        }
        // Vars to create a Binary File
        public FileStream StreamFlow;
        public BinaryWriter writer;
        public BinaryWriter writer2;

        public zxmachine(IntPtr handle, bool lateTimingModel) {
            mainHandle = handle;
            //-------------------- Nuevo modelo de memoria
            // ROM
            JunkMemory[0]   = new byte[PAGE_SIZE];
            JunkMemory[1]   = new byte[PAGE_SIZE];
            ROMpage[0]      = new byte[PAGE_SIZE];
            ROMpage[1]      = new byte[PAGE_SIZE];
            // RAM
            for (int i = 0; i < 30; i++) {
                RAMpage[i]  = new byte[PAGE_SIZE];
                PageEnabled[i] = true;                  // El modelo genérico habilitará todo
            }
            // ----------------------- fin nuevo modelo memoria
            LateTiming = (lateTimingModel ? 1 : 0);
            beeper = new MpfSound.SoundManager(handle, 16, 2, 44100);
            beeper.Play();

            interruptMode = 0;
            I = 0;
            R = 0;
            _R = 0;
            MemPtr = 0;

            PC = 0;
            SP = 0xffff;
            IY = 0xffff;
            IX = 0xffff;

            AF = 0xffff;
            BC = 0xffff;
            DE = 0xffff;
            HL = 0xffff;

            exx();
            ex_af_af();

            AF = 0xffff;
            BC = 0xffff;
            DE = 0xffff;
            HL = 0xffff;
        }

        //Reads next instruction from address pointed to by PC
        public int FetchInstruction() {
            R++;
            int b = GetOpcode(PC);
            PC = (PC + 1) & 0xffff;
            totalTStates++; //effectively, totalTStates + 4 because PeekByte does the other 3
            return b;
        }

        //Returns the actual memory address of a page
        public int GetPageAddress(int page) {            return PAGE_SIZE * page;        }
        //Returns the memory data at a page  // Esquema de 2K, asignación directa
        public byte[] GetPageData(int page) {            return RAMpage[page];           }

        //Resets the mpfBorad
        public virtual void Reset(bool coldBoot) {
            isResetOver = false;
            if (coldBoot)
            {
                SP = 0xffff;
                IY = 0xffff;
                IX = 0xffff;

                AF = 0xffff;
                BC = 0xffff;
                DE = 0xffff;
                HL = 0xffff;

                exx();
                ex_af_af();

                AF = 0xffff;
                BC = 0xffff;
                DE = 0xffff;
                HL = 0xffff;
                
            }
            PC = 0;
            interruptMode = 0;
            I = 0;
            R = 0;
            _R = 0;
            MemPtr = 0;
            resetOver = false;
            totalTStates = 0;
            timeToOutSound = 0;
            HaltOn = false;
            runningInterrupt = false;
            lastOpcodeWasEI = 0;
            ULAByteCtr = 0;
            lastTState = 0;
            elapsedTStates = 0;
            tstates = 0;
            frameCount = 0;
            IFF1 = false;
            IFF2 = false;
            averagedSound = 0;
            flashOn = false;
            //We jiggle the wait period after resetting so that FRAMES/RANDOMIZE works randomly enough on the mpfBorad.
            resetFrameTarget = new Random().Next(40, 90);
            // Desactivar teclado y visualización
            dmp = false;
            for (int i = 0; i < 6; i++) { mpf_leds[i] = 0; mpf_dots[i] = false; }
            led_red?.Invoke("OFF");

        }
        //Shutsdown MACHINE
        public virtual void Shutdown() {

            lock (lockThis) {
                beeper.Shutdown();
                beeper = null;
                ScreenBuffer = null;
                screen = null;
                attr = null;
                tstateToDisp = null;
                RAMpage = null;
                ROMpage = null;
                PageRDPtr = null;
                PageWRPtr = null;
                keyBuffer = null;
            }
        }

        //The main loop which executes opcodes repeatedly till 1 frame (69888 tstates) has been generated.
        public void Run() {
            for (int rep = 0; rep < 1; rep++)
            {
                while (doRun)
                {
                    if (OpcodeExecutedEvent != null)        OnOpcodeExecutedEvent();//Raise event for debugger
                    if (doRun)                              Process();              
                    if (needsPaint)
                    {
                                  FrameCount++;
                                  if (FrameCount > 50)  FrameCount = 0;
                                  if (!externalSingleStep)
                                  {
                                      while (!beeper.FinishedPlaying())  System.Threading.Thread.Sleep(1);
                                  }
                                  break;
                                  }
                    if (externalSingleStep)                 break;
                } //run loop
                
            }
        }

        //In r, (C)
        public int In() {
            int result = In(BC);
            F = ( F & F_CARRY) | sz53p[result];
            return result;
        }

        //Sets the sound volume of the beeper/ay
        public void SetSoundVolume(float vol) {
            soundVolume = vol;
            beeper.SetVolume(vol);
        }

        //Turns off the sound
        public void MuteSound(bool isMute) {
            if (isMute)
                beeper.SetVolume(0.0f);
            else
                beeper.SetVolume(soundVolume);
        }

        //Turns on the sound
        public void ResumeSound() {
            beeper.Play();
        }

        //Same as PeekByte, except specifically for opcode fetches in order to
        //trigger Memory Execute in debugger.
        public byte GetOpcode(int addr) {
            addr &= 0xffff;
            totalTStates += 3;

            int page = (addr) >> 11;            // 11 = 2048 ; 13 = 8192
            int offset = (addr) & 0x7FF;
            byte _b = PageRDPtr[page][offset];

            //This call flags a memory change event for the debugger
            if (MemoryExecuteEvent != null)
                OnMemoryExecuteEvent(new MemoryEventArgs(addr, _b));

            return _b;
        }

        //Returns the byte at a given 16 bit address (can be contended)
        public byte PeekByte(int addr) {
            addr &= 0xffff;
            totalTStates += 3;

            int page = (addr) >> 11;        // 11 = 2048 ; 13 = 8192
            if (!PageEnabled[page]) return (byte)0xff;                  // Si no está instalada --> $ff
            int offset = (addr) & 0x7FF;
            byte _b = PageRDPtr[page][offset];

            //This call flags a memory change event for the debugger
            if (MemoryReadEvent != null)
                OnMemoryReadEvent(new MemoryEventArgs(addr, _b));

            return _b;
        }

        //Returns the byte at a given 16 bit address (can be contended)
        public virtual void PokeByte(int addr, int _b) {
            addr &= 0xffff;
            byte b = (byte)(_b & 0xff);

            //This call flags a memory change event for the debugger
            if (MemoryWriteEvent != null)
                OnMemoryWriteEvent(new MemoryEventArgs(addr, _b & 0xff));
            totalTStates += 3;
            int page = (addr) >> 11;                // 11 = 2048 ; 13 = 8192
            if (!PageEnabled[page]) b = (byte)0xff;                  // Si no está instalada --> $ff
            int offset = (addr) & 0x7FF;
            PageWRPtr[page][offset] = b;
        }

        //Returns the byte at a given 16 bit address with no contention

        public byte PeekByteNoContend(int addr) {
            addr &= 0xffff;
            int page = (addr) >> 11;                // 11 = 2048 ; 13 = 8192
            int offset = (addr) & 0x7FF;            // 0x7ff = 2048 ; 0x1fff = 8192
            byte _b = PageRDPtr[page][offset];
            return _b;
        }

        //Returns a word at a given 16 bit address with no contention
        public int PeekWordNoContend(int addr) {
            return (PeekByteNoContend(addr) + (PeekByteNoContend(addr + 1) << 8));
        }

        //Pokes a 16 bit value at given address. Contention applies.
        public void PokeWord(int addr, int w) {
            PokeByte(addr, w);
            PokeByte((addr + 1), w >> 8);
        }

        //Returns a 16 bit value from given address. Contention applies.
        public int PeekWord(int addr) {
            return (PeekByte(addr)) | (PeekByte(addr + 1) << 8);
        }

        //The stack is pushed in low byte, high byte form
        public void PushStack(int val) {
            SP = (SP - 2) & 0xffff;
            PokeByte((SP + 1) & 0xffff, val >> 8);
            PokeByte(SP, val & 0xff);
            //if (PushStackEvent != null) OnPushStackEvent(SP, val);
        }

        public int PopStack() {
            int val = (PeekByte(SP)) | (PeekByte(SP + 1) << 8);
            SP = (SP + 2) & 0xffff;
            //if (PopStackEvent != null)   OnPopStackEvent(val);
            return val;
        }

        //Pokes a byte at a specific bank and offset
        //The offset input can be upto 16384, the bank and offset are adjusted
        //automatically.
        public void PokeRAMPage(int bank, int offset, byte val) {
            int indx = offset / PAGE_SIZE;
            RAMpage[bank * 2 + indx][offset % PAGE_SIZE] = val;
        }

        //Returns the byte at a given 16 bit address with no contention
        public void PokeByteNoContend(int addr, int b) {
            addr &= 0xffff;
            b &= 0xff;

            int page = (addr) >> 11;        // 11 = 2048 ; 13 = 8192
            int offset = (addr) & 0x7FF;
            PageWRPtr[page][offset] = (byte)b;
        }

        //Returns a value from a port (can be contended)
        public virtual int In(int port) {

            //Raise a port I/O event
            if (PortEvent != null)
                OnPortEvent(new PortIOEventArgs(port, 0, false));

            return 0;
        }

        //Used purely to raise an event with the debugger for IN with a specific value
        public virtual void In(int port, int val) {
            //Raise a port I/O event
            if (PortEvent != null)
                OnPortEvent(new PortIOEventArgs(port, val, false));
        }

        //Outputs a value to a port (can be contended)
        //The base call is used only to raise memory events
        public virtual void Out(int port, int val) {
            //Raise a port I/O event
            if (PortEvent != null)
                OnPortEvent(new PortIOEventArgs(port, val, true));
        }

        //Updates the state of the renderer
        //This was abstracted earlier but the logic seems to work with all models, so...
        public virtual void UpdateScreenBuffer(int _tstates) {
            if (_tstates < ActualULAStart) {
                return;
            } else if (_tstates >= FrameLength) {
                _tstates = FrameLength - 1;
                needsPaint = true;
            }

            //the additional 1 tstate is required to get correct number of bytes to output in ircontention.sna
            elapsedTStates = (_tstates + 1 - lastTState);

            //It takes 4 tstates to write 1 byte. Or, 2 pixels per t-state.

            int numBytes = (elapsedTStates >> 2) + ((elapsedTStates % 4) > 0 ? 1 : 0);

            int pixelData;
            int attrData;
            int bright;
            int ink;
            int paper;
            int flash;

            for (int i = 0; i < numBytes; i++) {
                if (tstateToDisp[lastTState] > 1) {
                   // for (int p = 0; p < 2; p++) {
                        screenByteCtr = tstateToDisp[lastTState] - 16384; //adjust for actual screen offset
                  
                        pixelData = screen[screenByteCtr];
                        attrData = screen[attr[screenByteCtr] - 16384];

                        lastPixelValue = pixelData;
                        lastAttrValue = attrData;
                        bright = (attrData & 0x40) >> 3;
                        flash = (attrData & 0x80) >> 7;
                        ink = (attrData & 0x07);
                        paper = ((attrData >> 3) & 0x7);

                        for (int a = 0; a < 8; ++a) {
                            if ((pixelData & 0x80) != 0) {

                                lastAttrValue = ink;

                            } else {

                                lastAttrValue = paper;

                            }
                            pixelData <<= 1;
                        }                 
                    // pixelData = lastPixelValue;
                } else if (tstateToDisp[lastTState] == 1) {
                }
                lastTState += 4;
            }
        }

        /*

        public unsafe void UpdateScreenBuffer2(int _tstates) {
            if (_tstates < ActualULAStart) {
                return;
            } else if (_tstates >= FrameLength) {
                _tstates = FrameLength - 1;
                //Since we're updating the entire screen here, we don't need to re-paint
                //it again in the  process loop on framelength overflow.
                needsPaint = true;
            }
            //the additional 1 tstate is required to get correct number of bytes to output in ircontention.sna
            elapsedTStates = (_tstates + 1 - lastTState);

            //It takes 4 tstates to write 1 byte.
            int numBytes = (elapsedTStates >> 2) + ((elapsedTStates % 4) > 0 ? 1 : 0);
            {
                int pixelData = 0;
                int attrData = 0;
                int bright = 0;
                int ink = 0;
                int paper = 0;
                bool flashBitOn = false;
                fixed (int* p = ScreenBuffer) {
                    for (int i = 0; i < numBytes; i++) {
                        if (tstateToDisp[lastTState] > 1) {
                            screenByteCtr = tstateToDisp[lastTState] - 16384; //adjust for actual screen offset

                            pixelData = screen[screenByteCtr];
                            attrData = screen[attr[screenByteCtr] - 16384];

                            lastPixelValue = pixelData;
                            lastAttrValue = attrData;
                            //if ((I & 192) == 192)
                            //{
                            //    if (screenByteCtr % 2 != 0)
                            //    {
                            //        pixelData = screen[(screenByteCtr-1) - 16384];
                            //        lastAttrValue = screen[attr[(screenByteCtr-1) - 16384] - 16384];
                            //    }
                            //}
                            
                            bright = (attrData & 0x40) >> 3;
                            flashBitOn = (attrData & 0x80) != 0;
                            ink = AttrColors[(attrData & 0x07) + bright];
                            paper = AttrColors[((attrData >> 3) & 0x7) + bright];

                            if (flashOn && flashBitOn) //swap paper and ink when flash is on
                            {
                                int temp = ink;
                                ink = paper;
                                paper = temp;
                            }

                            if (ULAPlusEnabled && ULAPaletteEnabled) {
                                ink = ULAPlusColours[((flashBitOn ? 1 : 0) << 1 + (bright != 0 ? 1 : 0)) << 4 + (attrData & 0x07)];
                                paper = ULAPlusColours[((flashBitOn ? 1 : 0) << 1 + (bright != 0 ? 1 : 0)) << 4 + ((attrData >> 3) & 0x7) + 8];
                            }

                            lock (this) {
                                for (int a = 0; a < 8; ++a) {
                                    if ((pixelData & 0x80) != 0) {
                                        *(p + ULAByteCtr) = ink;
                                    } else {
                                        *(p + ULAByteCtr) = paper;
                                    }
                                    pixelData <<= 1;
                                    ULAByteCtr++;
                                }
                            }
                        } else if (tstateToDisp[lastTState] == 1) {
                            int bor;
                            if (ULAPlusEnabled && ULAPaletteEnabled) {
                                bor = ULAPlusColours[borderColour];
                            } else
                                bor = AttrColors[borderColour];
                            lock (this) {
                                for (int g = 0; g < 8; g++) {
                                    *(p + ULAByteCtr) = bor;
                                    ULAByteCtr++;
                                }
                            }
                        }
                        lastTState += 4;
                    }
                }
            }
        }

        */

        //Loads in the ROM for the machine
        public abstract bool LoadROM(string path, string filename);

        //Updates the state of all inputs from the user

        // Simulamos la selección de línea en el puerto C del i8255
        // Correspondencia del teclado del PC con las teclas del MPF1
        /* 
                * F1   GO          -       -
                * F2   STEP        +       +
                * F3   REG         S       TPWR
                * F4   PC          L       TPRD
                * F5   ADDR        N.A     RESET
                * F6   DATA        N.A     MONI
                * F7   CBR         N.A     INTR
                * F8   SBR         N.A     USER KEY
                * F9   RELA
                * F10  DEL
                * F11  INS
                * F12  MOVE
                * 
         */


        public byte getRow(int rowNumber)
        {

            int a = 0;

            switch (rowNumber)
            {

                case 0:
                    // _3, _7, _B, _F, _X1, _X2,
                    a = (Convert.ToInt32(keyBuffer[(int)keyCode._X2]) << 5) |
                        (Convert.ToInt32(keyBuffer[(int)keyCode._X1]) << 4) |
                        (Convert.ToInt32(keyBuffer[(int)keyCode._F]) << 3) |
                        (Convert.ToInt32(keyBuffer[(int)keyCode._B]) << 2) |
                        (Convert.ToInt32(keyBuffer[(int)keyCode._7]) << 1) |
                         Convert.ToInt32(keyBuffer[(int)keyCode._3]);
                    break;
                case 1:
                    //  _2, _6, _A, _E, _X3, _X4,
                    a = (Convert.ToInt32(keyBuffer[(int)keyCode._X4]) << 5) |
                        (Convert.ToInt32(keyBuffer[(int)keyCode._X3]) << 4) |
                        (Convert.ToInt32(keyBuffer[(int)keyCode._E]) << 3) |
                        (Convert.ToInt32(keyBuffer[(int)keyCode._A]) << 2) |
                        (Convert.ToInt32(keyBuffer[(int)keyCode._6]) << 1) |
                         Convert.ToInt32(keyBuffer[(int)keyCode._2]);
                    break;
                case 2:
                    // _1, _5, _9, _D, _STEP, _TPRD,
                    a = (Convert.ToInt32(keyBuffer[(int)keyCode._TPRD]) << 5) |
                        (Convert.ToInt32(keyBuffer[(int)keyCode._STEP]) << 4) |
                        (Convert.ToInt32(keyBuffer[(int)keyCode._D]) << 3) |
                        (Convert.ToInt32(keyBuffer[(int)keyCode._9]) << 2) |
                        (Convert.ToInt32(keyBuffer[(int)keyCode._5]) << 1) |
                         Convert.ToInt32(keyBuffer[(int)keyCode._1]);
                    break;
                case 3:
                    //        _0, _4, _8, _C, _GO, _TPWR,
                    a = (Convert.ToInt32(keyBuffer[(int)keyCode._TPWR]) << 5) |
                        (Convert.ToInt32(keyBuffer[(int)keyCode._GO]) << 4) |
                        (Convert.ToInt32(keyBuffer[(int)keyCode._C]) << 3) |
                        (Convert.ToInt32(keyBuffer[(int)keyCode._8]) << 2) |
                        (Convert.ToInt32(keyBuffer[(int)keyCode._4]) << 1) |
                         Convert.ToInt32(keyBuffer[(int)keyCode._0]);
                    break;
                case 4:
                    // _CBR, _PC, _REG, _ADDR, _DEL, _RELA,
                    a = (Convert.ToInt32(keyBuffer[(int)keyCode._RELA]) << 5) |
                        (Convert.ToInt32(keyBuffer[(int)keyCode._DEL]) << 4) |
                        (Convert.ToInt32(keyBuffer[(int)keyCode._ADDR]) << 3) |
                        (Convert.ToInt32(keyBuffer[(int)keyCode._REG]) << 2) |
                        (Convert.ToInt32(keyBuffer[(int)keyCode._PC]) << 1) |
                         Convert.ToInt32(keyBuffer[(int)keyCode._CBR]);
                    break;
                case 5:
                    //  _SBR, _MINUS, _DATA, _PLUS, _INS, _MOVE,
                    a = (Convert.ToInt32(keyBuffer[(int)keyCode._MOVE]) << 5) |
                        (Convert.ToInt32(keyBuffer[(int)keyCode._INS]) << 4) |
                        (Convert.ToInt32(keyBuffer[(int)keyCode._PLUS]) << 3) |
                        (Convert.ToInt32(keyBuffer[(int)keyCode._DATA]) << 2) |
                        (Convert.ToInt32(keyBuffer[(int)keyCode._MINUS]) << 1) |
                         Convert.ToInt32(keyBuffer[(int)keyCode._SBR]);
                    break;
            }
            return (byte)~a;    // niego la operación
        }
        //#r2#
        public void UpdateInput() {

            for (int i=0;i<6;i++) keyLine[i] = getRow(i);

        }

        //Resets the state of all the keys
        public void ResetKeyboard() {
            for (int f = 0; f < keyBuffer.Length; f++) keyBuffer[f] = false;
            // Mpf tiene 6 lineas que escanear
            for (int f = 0; f < 6; f++)                keyLine[f] = 255;
        }

        //Adds a sound sample. This is called every 79 tstates from Process()
        public void OutSound() {
            averagedSound /= soundCounter;
            soundSamples[soundSampleCounter++] = (short)(averagedSound);
            soundSamples[soundSampleCounter++] = (short)(averagedSound);
            averagedSound = 0;
            soundCounter = 0;

            if (soundSampleCounter >= soundSamples.Length) {
                soundSampleCounter = 0;
                beeper.PlayBuffer(ref soundSamples);
            }
        }

        //Updates audio state, called from Process()
        private void UpdateAudio(int dt) {
            averagedSound += soundOut;
            soundCounter++;
        }

        private uint GetUIntFromString(string data) {
            byte[] carray = System.Text.ASCIIEncoding.UTF8.GetBytes(data);
            uint val = BitConverter.ToUInt32(carray, 0);
            return val;
        }

        //Resets the render state everytime an interrupt is generated
        public void ULAUpdateStart() {
            ULAByteCtr = 0;
            screenByteCtr = DisplayStart;
            lastTState = ActualULAStart;
            needsPaint = true;
        }
        /*
         * convierte el código de representación generado por el hardware
         * en el string ascci que pueden representar los leds del formulario Form1
         * CE : mpf_vale : Cósigo generado por el hardware
         * CS : String con el ascci equivalente.
         */
        public String convierte(int[] hw_display)
        {
            int mpf_value = 0;
            String ascci_str = "";
            String c ;
            for (int i = 0; i < 6; i++) {
                mpf_value = hw_display[i];
                c = "";
                switch (mpf_value)
               {
                    case 0xFD:
                    case 0XBD:                        c = "0";                        break;
                    case 0x70:
                    case 0X30:                        c = "1";                        break;
                    case 0xDB:
                    case 0X9B:                        c = "2";                        break;
                    case 0XFA:
                    case 0XBA:                        c = "3";                        break;
                    case 0x76:
                    case 0X36:                        c = "4";                        break;
                    case 0XEE:
                    case 0XAE:                        c = "5";                        break;
                    case 0XEF:
                    case 0XAF:                        c = "6";                        break;
                    case 0X78:
                    case 0X38:                        c = "7";                        break;
                    case 0XFF:
                    case 0XBF:                        c = "8";                        break;
                    case 0XFE:
                    case 0XBE:                        c = "9";                        break;
                    case 0x7F:
                    case 0X3F:                        c = "A";                        break;
                    case 0xE7:
                    case 0XA7:                        c = "B";                        break;
                    case 0xCD:
                    case 0X8D:                        c = "C";                        break;
                    case 0XF3:
                    case 0XB3:                        c = "D";                        break;
                    case 0XCF:
                    case 0X8F:                        c = "E";                        break;
                    case 0X4F:
                    case 0X0F:                        c = "F";                        break;
                    case 0XAD:                        c = "G";                        break;
                    case 0X37:                        c = "H";                        break;
                    case 0X89:                        c = "I";                        break;
                    case 0XB1:                        c = "J";                        break;
                    case 0X97:                        c = "K";                        break;
                    case 0X85:                        c = "L";                        break;
                    case 0X2B:                        c = "M";                        break;
                    case 0X23:                        c = "N";                        break;
                    case 0XA3:                        c = "o";                        break;
                    case 0X1F:                        c = "P";                        break;
                    case 0X3E:                        c = "q";                        break;
                    case 0X03:                        c = "r";                        break;
                    case 0XA6:                        c = "S";                        break;
                    case 0X87:                        c = "t";                        break;
                    case 0XA1:                        c = "u";                        break;
                    case 0XB7:                        c = "U";                        break;
                    case 0XA9:                        c = "W";                        break;
                    case 0X07:                        c = "X";                        break;
                    case 0XB6:                        c = "Y";                        break;
                    case 0X8A:                        c = "≡";                        break; // Z
                    case 0x02:                        c = "-";                        break;
                    case 0xc0:                        c = "_";                        break;
                    case 0x00:                        c = " ";                        break;
                    default:                          c = " ";                        break;
                }
                ascci_str = c + ascci_str;
            }
            return ascci_str;
        }  // convierte





        /*****************************************************************************************************/
        //The heart of the mpfBorad. Executes opcodes till 69888 tstates (1 frame) have passed
        public void Process() {

            ////////////////////////////////////   Maneja  Interrupciones relanzadas
            if (IFF1 && (lastOpcodeWasEI == 0) && (totalTStates < InterruptPeriod)) {
                if (StateChangeEvent != null)
                    OnStateChangeEvent(new StateChangeEventArgs(MPF_EVENT.RE_INTERRUPT));
                Interrupt();
            }
            if (lastOpcodeWasEI > 0)
                lastOpcodeWasEI--;
            R++;  
            oldTStates = totalTStates;
            opcode = GetOpcode(PC);

            PC = (PC + 1) & 0xffff;
            totalTStates++; //effectively, totalTStates + 4 because PeekByte does the other 3
            ////////////////////////////////////////// Ejecuta la instrucción actual
            Execute();
            /////////////////////////////////////////  Refesca display a cada instrucción
            if (dmp)
            {
                display?.Invoke(convierte(mpf_leds));   // Genero el string a mostrar
                dmp = false;                            // Hasta el siguiente scan_1 no actualizo
            }
 
            deltaTStates = totalTStates - oldTStates;
            
            //// Change CPU speed///////////////////////
            if (emulationSpeed > 0 ) {
                deltaTStates /= emulationSpeed;
                if (deltaTStates < 1)
                    deltaTStates = 1; 
                totalTStates = oldTStates + deltaTStates;
            }
            ///////////////////////////////////////////////////     Update Sound
            timeToOutSound += deltaTStates;            
            if (!externalSingleStep) {
                averagedSound += soundOut;
                soundCounter++;
                //Update sound every 79 tstates
                if (timeToOutSound >= soundTStatesToSample) {
                    averagedSound /= soundCounter;
                    while (timeToOutSound >= soundTStatesToSample) {
                        soundSamples[soundSampleCounter++] = (short)( averagedSound);
                        soundSamples[soundSampleCounter++] = (short)( averagedSound);
                        while (soundSampleCounter >= soundSamples.Length) {
                            byte[] sndbuf = beeper.LockBuffer();
                            if (sndbuf != null) {
                                System.Buffer.BlockCopy(soundSamples, 0, sndbuf, 0, sndbuf.Length);
                                beeper.UnlockBuffer(sndbuf);
                            }
                            soundSampleCounter = 0;
                        }
                        timeToOutSound -= soundTStatesToSample;
                    };
                    averagedSound = 0;
                    soundCounter = 0;
                }
            }
            ////////////////////////////////////////////////// End of frame?
            if (totalTStates >= FrameLength)
            {
                if (!needsPaint)  { /*UpdateScreenBuffer(FrameLength);*/   }
                OnFrameEndEvent();
                totalTStates -= FrameLength;
                frameCount++;
                if (frameCount > 15) {
                    flashOn = !flashOn;
                    frameCount = 0;
                }
                ULAUpdateStart();
            //////////////////////////////////////////////////// Procesa teclado
                UpdateInput();
                /////////////////////////////////////////////////// Pinta Leds
                
            /////////////////////////////////////////////////// Comprueba si hay necesidad de interrupciones
                if (IFF1 && lastOpcodeWasEI == 0) {
                    R++;
                    if (StateChangeEvent != null)
                        OnStateChangeEvent(new StateChangeEventArgs(MPF_EVENT.INTERRUPT));
                    Interrupt();
                }
            }         
        }
        //Executes a single opcode
        public void Execute() {
            disp = 0;
            //Massive switch-case to decode the instructions!
            switch (opcode) {

#region NOP

                case 0x00: //NOP
                    // Log("NOP");
                    break;

#endregion NOP

#region 16 bit load operations (LD rr, nn)
                /** LD rr, nn (excluding DD prefix) **/
                case 0x01: //LD BC, nn
                    BC = PeekWord(PC);
                    // Log(String.Format("LD BC, {0,-6:X}", BC));
                    PC += 2;
                    break;

                case 0x11:  //LD DE, nn
                    DE = PeekWord(PC);
                    // Log(String.Format("LD DE, {0,-6:X}", DE));
                    PC += 2;
                    break;

                case 0x21:  //LD HL, nn
                    HL = PeekWord(PC);
                    // Log(String.Format("LD HL, {0,-6:X}", HL));
                    PC += 2;
                    break;

                case 0x2A:  //LD HL, (nn)
                    disp = PeekWord(PC);
                    HL = PeekWord(disp);
                    // Log(String.Format("LD HL, ({0,-6:X})", disp));
                    PC += 2;
                    MemPtr = disp + 1;
                    break;

                case 0x31:  //LD SP, nn
                    SP = PeekWord(PC);
                    PC += 2;
                    break;

                case 0xF9:  //LD SP, HL
                    SP = HL;
                    break;
#endregion

#region 16 bit increments (INC rr)
                /** INC rr **/
                case 0x03:  //INC BC
                    BC++;
                    break;

                case 0x13:  //INC DE
                    DE++;
                    break;

                case 0x23:  //INC HL
                    HL++;
                    break;

                case 0x33:  //INC SP
                    SP++;
                    break;
#endregion INC rr

#region 8 bit increments (INC r)
                /** INC r + INC (HL) **/
                case 0x04:  //INC B
                    B = Inc(B);
                    // Log("INC B");
                    break;

                case 0x0C:  //INC C
                    C = Inc(C);
                    // Log("INC C");
                    break;

                case 0x14:  //INC D
                    D = Inc(D);
                    // Log("INC D");
                    break;

                case 0x1C:  //INC E
                    E = Inc(E);
                    // Log("INC E");
                    break;

                case 0x24:  //INC H
                    H = Inc(H);
                    // Log("INC H");
                    break;

                case 0x2C:  //INC L
                    L = Inc(L);
                    // Log("INC L");
                    break;

                case 0x34:  //INC (HL)
                    val = PeekByte(HL);
                    val = Inc(val);
                    PokeByte(HL, val);
                    // Log("INC (HL)");
                    break;

                case 0x3C:  //INC A
                    // Log("INC A");
                    A = Inc(A);
                    break;
#endregion

#region 8 bit decrement (DEC r)
                /** DEC r + DEC (HL)**/
                case 0x05: //DEC B
                    // Log("DEC B");
                    B = Dec(B);
                    break;

                case 0x0D:    //DEC C
                    // Log("DEC C");
                    C = Dec(C);
                    break;

                case 0x15:  //DEC D
                    // Log("DEC D");
                    D = Dec(D);
                    break;

                case 0x1D:  //DEC E
                    // Log("DEC E");
                    E = Dec(E);
                    break;

                case 0x25:  //DEC H
                    // Log("DEC H");
                    H = Dec(H);
                    break;

                case 0x2D:  //DEC L
                    // Log("DEC L");
                    L = Dec(L);
                    break;

                case 0x35:  //DEC (HL)
                    // Log("DEC (HL)");
                    //val = PeekByte(HL);
                    val = Dec(PeekByte(HL));
                    PokeByte(HL, val);
                    break;

                case 0x3D:  //DEC A
                    // Log("DEC A");
                    A = Dec(A);
                    //Deck DEC A short circuit (from SpecEmu's source with permission from Woody)
                    break;
#endregion

#region 16 bit decrements
                /** DEC rr **/
                case 0x0B:  //DEC BC
                    // Log("DEC BC");
                    BC--;
                    break;

                case 0x1B:  //DEC DE
                    // Log("DEC DE");
                    DE--;
                    break;

                case 0x2B:  //DEC HL
                    // Log("DEC HL");
                    HL--;
                    break;

                case 0x3B:  //DEC SP
                    // Log("DEC SP");
                    SP--;
                    break;
#endregion

#region Immediate load operations (LD (nn), r)
                /** LD (rr), r + LD (nn), HL  + LD (nn), A **/
                case 0x02: //LD (BC), A
                    // Log("LD (BC), A");
                    PokeByte(BC, A);
                    MemPtr = (((BC + 1) & 0xff) | (A << 8));
                    break;

                case 0x12:  //LD (DE), A
                    // Log("LD (DE), A");
                    PokeByte(DE, A);
                    MemPtr = (((DE + 1) & 0xff) | (A << 8));
                    break;

                case 0x22:  //LD (nn), HL
                    addr = PeekWord(PC);
                    // Log(String.Format("LD ({0,-6:X}), HL", addr));

                    PokeWord(addr, HL);
                    MemPtr = addr + 1;
                    PC += 2;
                    break;

                case 0x32:  //LD (nn), A
                    addr = PeekWord(PC);
                    // Log(String.Format("LD ({0,-6:X}), A", addr));

                    PokeByte(addr, A);
                    MemPtr = (((addr + 1) & 0xff) | (A << 8));
                    PC += 2;
                    break;

                case 0x36:  //LD (HL), n
                    val = PeekByte(PC);
                    // Log(String.Format("LD (HL), {0,-6:X}", val));

                    PokeByte(HL, val);
                    PC += 1;
                    break;
#endregion

#region Indirect load operations (LD r, r)
                /** LD r, r **/
                case 0x06: //LD B, n
                    B = PeekByte(PC);
                    // Log(String.Format("LD B, {0,-6:X}", B));

                    PC += 1;
                    break;

                case 0x0A:  //LD A, (BC)
                    A = PeekByte(BC);
                    MemPtr = BC + 1;
                    // Log("LD A, (BC)");

                    break;

                case 0x0E:  //LD C, n
                    C = PeekByte(PC);
                    // Log(String.Format("LD C, {0,-6:X}", C));

                    PC += 1;
                    break;

                case 0x16:  //LD D,n
                    D = PeekByte(PC);
                    // Log(String.Format("LD D, {0,-6:X}", D));

                    PC += 1;
                    break;

                case 0x1A:  //LD A,(DE)
                    // Log("LD A, (DE)");
                    A = PeekByte(DE);
                    MemPtr = DE + 1;
                    break;

                case 0x1E:  //LD E,n
                    E = PeekByte(PC);
                    // Log(String.Format("LD E, {0,-6:X}", E));

                    PC += 1;
                    break;

                case 0x26:  //LD H,n
                    H = PeekByte(PC);
                    // Log(String.Format("LD H, {0,-6:X}", H));

                    PC += 1;
                    break;

                case 0x2E:  //LD L,n
                    L = PeekByte(PC);
                    // Log(String.Format("LD L, {0,-6:X}", L));

                    PC += 1;
                    break;

                case 0x3A:  //LD A,(nn)
                    addr = PeekWord(PC);
                    // Log(String.Format("LD A, ({0,-6:X})", addr));
                    MemPtr = addr + 1;
                    A = PeekByte(addr);
                    PC += 2;
                    break;

                case 0x3E:  //LD A,n
                    A = PeekByte(PC);
                    // Log(String.Format("LD A, {0,-6:X}", A));

                    PC += 1;
                    break;

                case 0x40:  //LD B,B
                    // Log("LD B, B");
                    B = B;
                    break;

                case 0x41:  //LD B,C
                    // Log("LD B, C");
                    B = C;
                    break;

                case 0x42:  //LD B,D
                    // Log("LD B, D");
                    B = D;
                    break;

                case 0x43:  //LD B,E
                    // Log("LD B, E");
                    B = E;
                    break;

                case 0x44:  //LD B,H
                    // Log("LD B, H");
                    B = H;
                    break;

                case 0x45:  //LD B,L
                    // Log("LD B, L");
                    B = L;
                    break;

                case 0x46:  //LD B,(HL)
                    // Log("LD B, (HL)");
                    B = PeekByte(HL);
                    break;

                case 0x47:  //LD B,A
                    // Log("LD B, A");
                    B = A;
                    break;

                case 0x48:  //LD C,B
                    // Log("LD C, B");
                    C = B;
                    break;

                case 0x49:  //LD C,C
                    // Log("LD C, C");
                    C = C;
                    break;

                case 0x4A:  //LD C,D
                    // Log("LD C, D");
                    C = D;
                    break;

                case 0x4B:  //LD C,E
                    // Log("LD C, E");
                    C = E;
                    break;

                case 0x4C:  //LD C,H
                    // Log("LD C, H");
                    C = H;
                    break;

                case 0x4D:  //LD C,L
                    // Log("LD C, L");
                    C = L;
                    break;

                case 0x4E:  //LD C, (HL)
                    // Log("LD C, (HL)");
                    C = PeekByte(HL);
                    break;

                case 0x4F:  //LD C,A
                    // Log("LD C, A");
                    C = A;
                    break;

                case 0x50:  //LD D,B
                    // Log("LD D, B");
                    D = B;
                    break;

                case 0x51:  //LD D,C
                    // Log("LD D, C");
                    D = C;
                    break;

                case 0x52:  //LD D,D
                    // Log("LD D, D");
                    D = D;
                    break;

                case 0x53:  //LD D,E
                    // Log("LD D, E");
                    D = E;
                    break;

                case 0x54:  //LD D,H
                    // Log("LD D, H");
                    D = H;
                    break;

                case 0x55:  //LD D,L
                    // Log("LD D, L");
                    D = L;
                    break;

                case 0x56:  //LD D,(HL)
                    // Log("LD D, (HL)");
                    D = PeekByte(HL);
                    break;

                case 0x57:  //LD D,A
                    // Log("LD D, A");
                    D = A;
                    break;

                case 0x58:  //LD E,B
                    // Log("LD E, B");
                    E = B;
                    break;

                case 0x59:  //LD E,C
                    // Log("LD E, C");
                    E = C;
                    break;

                case 0x5A:  //LD E,D
                    // Log("LD E, D");
                    E = D;
                    break;

                case 0x5B:  //LD E,E
                    // Log("LD E, E");
                    E = E;
                    break;

                case 0x5C:  //LD E,H
                    // Log("LD E, H");
                    E = H;
                    break;

                case 0x5D:  //LD E,L
                    // Log("LD E, L");
                    E = L;
                    break;

                case 0x5E:  //LD E,(HL)
                    // Log("LD E, (HL)");
                    E = PeekByte(HL);
                    break;

                case 0x5F:  //LD E,A
                    // Log("LD E, A");
                    E = A;
                    break;

                case 0x60:  //LD H,B
                    // Log("LD H, B");
                    H = B;
                    break;

                case 0x61:  //LD H,C
                    // Log("LD H, C");
                    H = C;
                    break;

                case 0x62:  //LD H,D
                    // Log("LD H, D");
                    H = D;
                    break;

                case 0x63:  //LD H,E
                    // Log("LD H, E");
                    H = E;
                    break;

                case 0x64:  //LD H,H
                    // Log("LD H, H");
                    H = H;
                    break;

                case 0x65:  //LD H,L
                    // Log("LD H, L");
                    H = L;
                    break;

                case 0x66:  //LD H,(HL)
                    // Log("LD H, (HL)");
                    H = PeekByte(HL);
                    break;

                case 0x67:  //LD H,A
                    // Log("LD H, A");
                    H = A;
                    break;

                case 0x68:  //LD L,B
                    // Log("LD L, B");
                    L = B;
                    break;

                case 0x69:  //LD L,C
                    // Log("LD L, C");
                    L = C;
                    break;

                case 0x6A:  //LD L,D
                    // Log("LD L, D");
                    L = D;
                    break;

                case 0x6B:  //LD L,E
                    // Log("LD L, E");
                    L = E;
                    break;

                case 0x6C:  //LD L,H
                    // Log("LD L, H");
                    L = H;
                    break;

                case 0x6D:  //LD L,L
                    // Log("LD L, L");
                    L = L;
                    break;

                case 0x6E:  //LD L,(HL)
                    // Log("LD L, (HL)");
                    L = PeekByte(HL);
                    break;

                case 0x6F:  //LD L,A
                    // Log("LD L, A");
                    L = A;
                    break;

                case 0x70:  //LD (HL),B
                    // Log("LD (HL), B");
                    PokeByte(HL, B);
                    break;

                case 0x71:  //LD (HL),C
                    // Log("LD (HL), C");
                    PokeByte(HL, C);
                    break;

                case 0x72:  //LD (HL),D
                    // Log("LD (HL), D");
                    PokeByte(HL, D);
                    break;

                case 0x73:  //LD (HL),E
                    // Log("LD (HL), E");
                    PokeByte(HL, E);
                    break;

                case 0x74:  //LD (HL),H
                    // Log("LD (HL), H");
                    PokeByte(HL, H);
                    break;

                case 0x75:  //LD (HL),L
                    // Log("LD (HL), L");
                    PokeByte(HL, L);
                    break;

                case 0x77:  //LD (HL),A
                    // Log("LD (HL), A");
                    PokeByte(HL, A);
                    break;

                case 0x78:  //LD A,B
                    // Log("LD A, B");
                    A = B;
                    break;

                case 0x79:  //LD A,C
                    // Log("LD A, C");
                    A = C;
                    break;

                case 0x7A:  //LD A,D
                    // Log("LD A, D");
                    A = D;
                    break;

                case 0x7B:  //LD A,E
                    // Log("LD A, E");
                    A = E;
                    break;

                case 0x7C:  //LD A,H
                    // Log("LD A, H");
                    A = H;
                    break;

                case 0x7D:  //LD A,L
                    // Log("LD A, L");
                    A = L;
                    break;

                case 0x7E:  //LD A,(HL)
                    // Log("LD A, (HL)");
                    A = PeekByte(HL);
                    break;

                case 0x7F:  //LD A,A
                    // Log("LD A, A");
                    A = A;
                    break;
#endregion

#region Rotates on Accumulator
                /** Accumulator Rotates **/
                case 0x07: //RLCA
                    // Log("RLCA");
                    bool ac = (A & F_SIGN) != 0; //save the msb bit

                    if (ac) {
                        A = ((A << 1) | F_CARRY) & 0xff;
                    } else {
                        A = (A << 1) & 0xff;
                    }
                    SetF3((A & F_3) != 0);
                    SetF5((A & F_5) != 0);
                    SetCarry(ac);
                    SetHalf(false);
                    SetNeg(false);
                    break;

                case 0x0F:  //RRCA
                    // Log("RRCA");

                    ac = (A & F_CARRY) != 0; //save the lsb bit

                    if (ac) {
                        A = (A >> 1) | F_SIGN;
                    } else {
                        A = A >> 1;
                    }

                    SetF3((A & F_3) != 0);
                    SetF5((A & F_5) != 0);
                    SetCarry(ac);
                    SetHalf(false);
                    SetNeg(false);
                    break;

                case 0x17:  //RLA
                    // Log("RLA");
                    ac = ((A & F_SIGN) != 0);

                    int msb = F & F_CARRY;

                    if (msb != 0) {
                        A = ((A << 1) | F_CARRY);
                    } else {
                        A = (A << 1);
                    }
                    SetF3((A & F_3) != 0);
                    SetF5((A & F_5) != 0);
                    SetCarry(ac);
                    SetHalf(false);
                    SetNeg(false);
                    break;

                case 0x1F:  //RRA
                    // Log("RRA");
                    ac = (A & F_CARRY) != 0; //save the lsb bit
                    int lsb = F & F_CARRY;

                    if (lsb != 0) {
                        A = (A >> 1) | F_SIGN;
                    } else {
                        A = A >> 1;
                    }
                    SetF3((A & F_3) != 0);
                    SetF5((A & F_5) != 0);
                    SetCarry(ac);
                    SetHalf(false);
                    SetNeg(false);
                    break;
#endregion

#region Exchange operations (EX)
                /** Exchange operations **/
                case 0x08:     //EX AF, AF'
                    // Log("EX AF, AF'");
                    ex_af_af();
                    break;

                case 0xD9:   //EXX
                    // Log("EXX");
                    exx();
                    break;

                case 0xE3:  //EX (SP), HL
                    // Log("EX (SP), HL");
                    //int temp = HL;
                    addr = PeekWord(SP);
                    PokeByte((SP + 1) & 0xffff, HL >> 8);
                    PokeByte(SP, HL & 0xff);
                    HL = addr;
                    MemPtr = HL;
                    break;

                case 0xEB:  //EX DE, HL
                    // Log("EX DE, HL");
                    int temp = DE;
                    DE = HL;
                    HL = temp;
                    break;
#endregion

#region 16 bit addition to HL (Add HL, rr)
                /** Add HL, rr **/
                case 0x09:     //ADD HL, BC
                    // Log("ADD HL, BC");
                    MemPtr = HL + 1;
                    HL = Add_RR(HL, BC);

                    break;

                case 0x19:    //ADD HL, DE
                    // Log("ADD HL, DE");
                    MemPtr = HL + 1;
                    HL = Add_RR(HL, DE);

                    break;

                case 0x29:  //ADD HL, HL
                    // Log("ADD HL, HL");
                    MemPtr = HL + 1;
                    HL = Add_RR(HL, HL);
                    break;

                case 0x39:  //ADD HL, SP
                    // Log("ADD HL, SP");
                    MemPtr = HL + 1;
                    HL = Add_RR(HL, SP);
                    break;
#endregion

#region 8 bit addition to accumulator (Add r, r)
                /*** ADD r, r ***/
                case 0x80:  //ADD A,B
                    // Log("ADD A, B");
                    Add_R(B);
                    break;

                case 0x81:  //ADD A,C
                    // Log("ADD A, C");
                    Add_R(C);
                    break;

                case 0x82:  //ADD A,D
                    // Log("ADD A, D");
                    Add_R(D);
                    break;

                case 0x83:  //ADD A,E
                    // Log("ADD A, E");
                    Add_R(E);
                    break;

                case 0x84:  //ADD A,H
                    // Log("ADD A, H");
                    Add_R(H);
                    break;

                case 0x85:  //ADD A,L
                    // Log("ADD A, L");
                    Add_R(L);
                    break;

                case 0x86:  //ADD A, (HL)
                    // Log("ADD A, (HL)");
                    Add_R(PeekByte(HL));
                    break;

                case 0x87:  //ADD A, A
                    // Log("ADD A, A");
                    Add_R(A);
                    break;

                case 0xC6:  //ADD A, n
                    disp = PeekByte(PC);
                    // Log(String.Format("ADD A, {0,-6:X}", disp));
                    Add_R(disp);
                    PC++;
                    break;
#endregion

#region Add to accumulator with carry (Adc A, r)
                /** Adc a, r **/
                case 0x88:  //ADC A,B
                    // Log("ADC A, B");
                    Adc_R(B);
                    break;

                case 0x89:  //ADC A,C
                    // Log("ADC A, C");
                    Adc_R(C);
                    break;

                case 0x8A:  //ADC A,D
                    // Log("ADC A, D");
                    Adc_R(D);
                    break;

                case 0x8B:  //ADC A,E
                    // Log("ADC A, E");
                    Adc_R(E);
                    break;

                case 0x8C:  //ADC A,H
                    // Log("ADC A, H");
                    Adc_R(H);
                    break;

                case 0x8D:  //ADC A,L
                    // Log("ADC A, L");
                    Adc_R(L);
                    break;

                case 0x8E:  //ADC A,(HL)
                    // Log("ADC A, (HL)");
                    Adc_R(PeekByte(HL));
                    break;

                case 0x8F:  //ADC A,A
                    // Log("ADC A, A");
                    Adc_R(A);
                    break;

                case 0xCE:  //ADC A, n
                    disp = PeekByte(PC);
                    // Log(String.Format("ADC A, {0,-6:X}", disp));
                    Adc_R(disp);
                    PC += 1;
                    break;
#endregion

#region 8 bit subtraction from accumulator(SUB r)
                case 0x90:  //SUB B
                    // Log("SUB B");
                    Sub_R(B);
                    break;

                case 0x91:  //SUB C
                    // Log("SUB C");
                    Sub_R(C);
                    break;

                case 0x92:  //SUB D
                    // Log("SUB D");
                    Sub_R(D);
                    break;

                case 0x93:  //SUB E
                    // Log("SUB E");
                    Sub_R(E);
                    break;

                case 0x94:  //SUB H
                    // Log("SUB H");
                    Sub_R(H);
                    break;

                case 0x95:  //SUB L
                    // Log("SUB L");
                    Sub_R(L);
                    break;

                case 0x96:  //SUB (HL)
                    // Log("SUB (HL)");
                    Sub_R(PeekByte(HL));
                    break;

                case 0x97:  //SUB A
                    // Log("SUB A");
                    Sub_R(A);
                    break;

                case 0xD6:  //SUB n
                    disp = PeekByte(PC);
                    // Log(String.Format("SUB {0,-6:X}", disp));
                    Sub_R(disp);
                    PC += 1;
                    break;
#endregion

#region 8 bit subtraction from accumulator with carry(SBC A, r)
                case 0x98:  //SBC A, B
                    // Log("SBC A, B");
                    Sbc_R(B);
                    break;

                case 0x99:  //SBC A, C
                    // Log("SBC A, C");
                    Sbc_R(C);
                    break;

                case 0x9A:  //SBC A, D
                    // Log("SBC A, D");
                    Sbc_R(D);
                    break;

                case 0x9B:  //SBC A, E
                    // Log("SBC A, E");
                    Sbc_R(E);
                    break;

                case 0x9C:  //SBC A, H
                    // Log("SBC A, H");
                    Sbc_R(H);
                    break;

                case 0x9D:  //SBC A, L
                    // Log("SBC A, L");
                    Sbc_R(L);
                    break;

                case 0x9E:  //SBC A, (HL)
                    // Log("SBC A, (HL)");
                    Sbc_R(PeekByte(HL));
                    break;

                case 0x9F:  //SBC A, A
                    // Log("SBC A, A");
                    Sbc_R(A);
                    break;

                case 0xDE:  //SBC A, n
                    disp = PeekByte(PC);
                    // Log(String.Format("SBC A, {0,-6:X}", disp));
                    Sbc_R(disp);
                    PC += 1;
                    break;
#endregion

#region Relative Jumps (JR / DJNZ)
                /*** Relative Jumps ***/
                case 0x10:  //DJNZ n
                    disp = GetDisplacement(PeekByte(PC));
                    // Log(String.Format("DJNZ {0,-6:X}", PC + disp + 1));
                    B--;
                    if (B != 0) {
                        PC += disp;
                        MemPtr = PC + 1;
                    }
                    PC++;

                    break;

                case 0x18:  //JR n
                    disp = GetDisplacement(PeekByte(PC));
                    // Log(String.Format("JR {0,-6:X}", PC + disp + 1));
                    PC += disp;
                    PC++;
                    MemPtr = PC;
                    break;

                case 0x20:  //JRNZ n
                    disp = GetDisplacement(PeekByte(PC));
                    // Log(String.Format("JR NZ, {0,-6:X}", PC + disp + 1));
                    if ((F & F_ZERO) == 0) {
                        PC += disp;
                        MemPtr = PC + 1;
                    }
                    PC++;
                    break;

                case 0x28:  //JRZ n
                    disp = GetDisplacement(PeekByte(PC));
                    // Log(String.Format("JR Z, {0,-6:X}", PC + disp + 1));

                    if ((F & F_ZERO) != 0) {
                        PC += disp;
                        MemPtr = PC + 1;
                    }
                    PC++;
                    break;

                case 0x30:  //JRNC n
                    disp = GetDisplacement(PeekByte(PC));
                    // Log(String.Format("JR NC, {0,-6:X}", PC + disp + 1));

                    if ((F & F_CARRY) == 0) {
                        PC += disp;
                        MemPtr = PC + 1;
                    }
                    PC++;
                    break;

                case 0x38:  //JRC n
                    disp = GetDisplacement(PeekByte(PC));
                    // Log(String.Format("JR C, {0,-6:X}", PC + disp + 1));

                    if ((F & F_CARRY) != 0) {
                        PC += disp;
                        MemPtr = PC + 1;
                    }
                    PC++;
                    break;
#endregion

#region Direct jumps (JP)
                /*** Direct jumps ***/
                case 0xC2:  //JPNZ nn
                    disp = PeekWord(PC);
                    // Log(String.Format("JP NZ, {0,-6:X}", disp));
                    if ((F & F_ZERO) == 0) {
                        PC = disp;
                    } else {
                        PC += 2;
                    }
                    MemPtr = disp;
                    break;

                case 0xC3:  //JP nn
                    disp = PeekWord(PC);
                    // Log(String.Format("JP {0,-6:X}", disp));
                    PC = disp;
                    MemPtr = disp;
                    break;

                case 0xCA:  //JPZ nn
                    disp = PeekWord(PC);
                    // Log(String.Format("JP Z, {0,-6:X}", disp));
                    if ((F & F_ZERO) != 0) {
                        PC = disp;
                    } else {
                        PC += 2;
                    }
                    MemPtr = disp;
                    break;

                case 0xD2:  //JPNC nn
                    disp = PeekWord(PC);
                    // Log(String.Format("JP NC, {0,-6:X}", disp));
                    if ((F & F_CARRY) == 0) {
                        PC = disp;
                    } else {
                        PC += 2;
                    }
                    MemPtr = disp;
                    break;

                case 0xDA:  //JPC nn
                    disp = PeekWord(PC);
                    // Log(String.Format("JP C, {0,-6:X}", disp));
                    if ((F & F_CARRY) != 0) {
                        PC = disp;
                    } else {
                        PC += 2;
                    }
                    MemPtr = disp;
                    break;

                case 0xE2:  //JP PO nn
                    disp = PeekWord(PC);
                    // Log(String.Format("JP PO, {0,-6:X}", disp));
                    if ((F & F_PARITY) == 0) {
                        PC = disp;
                    } else {
                        PC += 2;
                    }
                    MemPtr = disp;
                    break;

                case 0xE9:  //JP (HL)
                    // Log("JP (HL)");
                    //PC = PeekWord(HL);
                    PC = HL;
                    //  MemPtr = PC;
                    break;

                case 0xEA:  //JP PE nn
                    disp = PeekWord(PC);
                    // Log(String.Format("JP PE, {0,-6:X}", disp));
                    if ((F & F_PARITY) != 0) {
                        PC = disp;
                    } else {
                        PC += 2;
                    }
                    MemPtr = disp;
                    break;

                case 0xF2:  //JP P nn
                    disp = PeekWord(PC);
                    // Log(String.Format("JP P, {0,-6:X}", disp));
                    if ((F & F_SIGN) == 0) {
                        PC = disp;
                    } else {
                        PC += 2;
                    }
                    MemPtr = disp;
                    break;

                case 0xFA:  //JP M nn
                    disp = PeekWord(PC);
                    // Log(String.Format("JP M, {0,-6:X}", disp));
                    if ((F & F_SIGN) != 0) {
                        PC = disp;
                    } else {
                        PC += 2;
                    }
                    MemPtr = disp;
                    break;
#endregion

#region Compare instructions (CP)
                /*** Compare instructions **/
                case 0xB8:  //CP B
                    // Log("CP B");
                    Cp_R(B);
                    break;

                case 0xB9:  //CP C
                    // Log("CP C");
                    Cp_R(C);
                    break;

                case 0xBA:  //CP D
                    // Log("CP D");
                    Cp_R(D);
                    break;

                case 0xBB:  //CP E
                    // Log("CP E");
                    Cp_R(E);
                    break;

                case 0xBC:  //CP H
                    // Log("CP H");
                    Cp_R(H);
                    break;

                case 0xBD:  //CP L
                    // Log("CP L");
                    Cp_R(L);
                    break;

                case 0xBE:  //CP (HL)
                    // Log("CP (HL)");
                    val = PeekByte(HL);
                    Cp_R(val);
                    break;

                case 0xBF:  //CP A
                    // Log("CP A");
                    Cp_R(A);
                    //if (tape_readToPlay)
                    //    if (PC == 0x56b)
                    //        FlashLoadTape();
                    break;

                case 0xFE:  //CP n
                    disp = PeekByte(PC);
                    // Log(String.Format(String.Format("CP {0,-6:X}", disp)));
                    Cp_R(disp);
                    PC += 1;
                    break;
#endregion

#region Carry Flag operations
                /*** Carry Flag operations ***/
                case 0x37:  //SCF
                    // Log("SCF");
                    SetCarry(true);
                    SetNeg(false);
                    SetHalf(false);
                    SetF3((A & F_3) != 0);
                    SetF5((A & F_5) != 0);
                    break;

                case 0x3F:  //CCF
                    // Log("CCF");

                    SetF3((A & F_3) != 0);
                    SetF5((A & F_5) != 0);
                    SetHalf((F & F_CARRY) != 0);
                    SetNeg(false);
                    SetCarry(((F & F_CARRY) != 0) ? false : true);

                    break;
#endregion

#region Bitwise AND (AND r)
                case 0xA0:  //AND B
                    // Log("AND B");
                    And_R(B);
                    break;

                case 0xA1:  //AND C
                    // Log("AND C");
                    And_R(C);
                    break;

                case 0xA2:  //AND D
                    // Log("AND D");
                    And_R(D);
                    break;

                case 0xA3:  //AND E
                    // Log("AND E");
                    And_R(E);
                    break;

                case 0xA4:  //AND H
                    // Log("AND H");
                    And_R(H);
                    break;

                case 0xA5:  //AND L
                    // Log("AND L");
                    And_R(L);
                    break;

                case 0xA6:  //AND (HL)
                    // Log("AND (HL)");
                    And_R(PeekByte(HL));
                    break;

                case 0xA7:  //AND A
                    // Log("AND A");
                    And_R(A);
                    break;

                case 0xE6:  //AND n
                    disp = PeekByte(PC);
                    // Log(String.Format("AND {0,-6:X}", disp));
                    And_R(disp);

                    PC++;
                    break;
#endregion

#region Bitwise XOR (XOR r)
                case 0xA8: //XOR B
                    // Log("XOR B");
                    Xor_R(B);
                    break;

                case 0xA9: //XOR C
                    // Log("XOR C");
                    Xor_R(C);
                    break;

                case 0xAA: //XOR D
                    // Log("XOR D");
                    Xor_R(D);
                    break;

                case 0xAB: //XOR E
                    // Log("XOR E");
                    Xor_R(E);
                    break;

                case 0xAC: //XOR H
                    // Log("XOR H");
                    Xor_R(H);
                    break;

                case 0xAD: //XOR L
                    // Log("XOR L");
                    Xor_R(L);
                    break;

                case 0xAE: //XOR (HL)
                    // Log("XOR (HL)");
                    Xor_R(PeekByte(HL));
                    break;

                case 0xAF: //XOR A
                    // Log("XOR A");
                    Xor_R(A);
                    break;

                case 0xEE:  //XOR n
                    disp = PeekByte(PC);
                    // Log(String.Format("XOR {0,-6:X}", disp));
                    Xor_R(disp);
                    PC++;
                    break;

#endregion

#region Bitwise OR (OR r)
                case 0xB0:  //OR B
                    // Log("OR B");
                    Or_R(B);
                    break;

                case 0xB1:  //OR C
                    // Log("OR C");
                    Or_R(C);
                    break;

                case 0xB2:  //OR D
                    // Log("OR D");
                    Or_R(D);
                    break;

                case 0xB3:  //OR E
                    // Log("OR E");
                    Or_R(E);
                    break;

                case 0xB4:  //OR H
                    // Log("OR H");
                    Or_R(H);
                    break;

                case 0xB5:  //OR L
                    // Log("OR L");
                    Or_R(L);
                    break;

                case 0xB6:  //OR (HL)
                    // Log("OR (HL)");
                    Or_R(PeekByte(HL));
                    break;

                case 0xB7:  //OR A
                    // Log("OR A");
                    Or_R(A);
                    break;

                case 0xF6:  //OR n
                    disp = PeekByte(PC);
                    // Log(String.Format("OR {0,-6:X}", disp));
                    Or_R(disp);
                    PC++;
                    break;
#endregion

#region Return instructions
                case 0xC0:  //RET NZ
                    // Log("RET NZ");
                    if ((F & F_ZERO) == 0) {
                        PC = PopStack();
                        MemPtr = PC;
                    }
                    break;

                case 0xC8:  //RET Z
                    // Log("RET Z");
                    if ((F & F_ZERO) != 0) {
                        PC = PopStack();
                        MemPtr = PC;
                    }
                    break;

                case 0xC9:  //RET
                    // Log("RET");
                    PC = PopStack();
                    MemPtr = PC;
                    if (tone) {             // tone solo es true si lo activo un CALL TONE
                        tone = false;
                        led_tone?.Invoke("OFF");
                    }
                    break;

                case 0xD0:  //RET NC
                    // Log("RET NC");
                    if ((F & F_CARRY) == 0) {
                        PC = PopStack();
                        MemPtr = PC;
                    }
                    break;

                case 0xD8:  //RET C
                    // Log("RET C");
                    if ((F & F_CARRY) != 0) {
                        PC = PopStack();
                        MemPtr = PC;
                    }
                    break;

                case 0xE0:  //RET PO
                    // Log("RET PO");
                    if ((F & F_PARITY) == 0) {
                        PC = PopStack();
                        MemPtr = PC;
                    }
                    break;

                case 0xE8:  //RET PE
                    // Log("RET PE");
                    if ((F & F_PARITY) != 0) {
                        PC = PopStack();
                        MemPtr = PC;
                    }
                    break;

                case 0xF0:  //RET P
                    // Log("RET P");
                    if ((F & F_SIGN) == 0) {
                        PC = PopStack();
                        MemPtr = PC;
                    }
                    break;

                case 0xF8:  //RET M
                    // Log("RET M");
                    if ((F & F_SIGN) != 0) {
                        PC = PopStack();
                        MemPtr = PC;
                    }
                    break;
#endregion

#region POP/PUSH instructions
                case 0xC1:  //POP BC
                    // Log("POP BC");
                    BC = PopStack();
                    break;

                case 0xC5:  //PUSH BC
                    // Log("PUSH BC");
                    PushStack(BC);
                    break;

                case 0xD1:  //POP DE
                    // Log("POP DE");

                    DE = PopStack();
                    break;

                case 0xD5:  //PUSH DE
                    // Log("PUSH DE");
                    PushStack(DE);
                    break;

                case 0xE1:  //POP HL
                    // Log("POP HL");
                    HL = PopStack();
                    break;

                case 0xE5:  //PUSH HL
                    // Log("PUSH HL");
                    PushStack(HL);
                    break;

                case 0xF1:  //POP AF
                    // Log("POP AF");
                    AF = PopStack();
                    break;

                case 0xF5:  //PUSH AF
                    // Log("PUSH AF");
                    PushStack(AF);
                    break;
#endregion

#region CALL instructions
                case 0xC4:  //CALL NZ, nn
                    disp = PeekWord(PC);
                    MemPtr = disp;
                    // Log(String.Format("CALL NZ, {0,-6:X}", disp));
                    if ((F & F_ZERO) == 0) {
                        PushStack(PC + 2);
                        PC = disp;
                    } else {
                        PC += 2;
                    }
                    break;

                case 0xCC:  //CALL Z, nn
                    disp = PeekWord(PC);
                    MemPtr = disp;
                    // Log(String.Format("CALL Z, {0,-6:X}", disp));
                    if ((F & F_ZERO) != 0) {
                        PushStack(PC + 2);
                        PC = disp;
                    } else {
                        PC += 2;
                    }
                    break;
// #rmsvdp#
                case 0xCD:  //CALL nn
                    disp = PeekWord(PC);
                    if (disp == 0x0624)         // Captura SCAN1
                    {
                        mpf_leds[0] = PeekByte(IX + 5);
                        mpf_dots[0] = ((PeekByte(IX + 5) & 0b01000000) == 0x40) ? true : false;
                        mpf_leds[1] = PeekByte(IX + 4);
                        mpf_dots[1] = ((PeekByte(IX + 4) & 0b01000000) == 0x40) ? true : false;
                        mpf_leds[2] = PeekByte(IX + 3);
                        mpf_dots[2] = ((PeekByte(IX + 3) & 0b01000000) == 0x40) ? true : false;
                        mpf_leds[3] = PeekByte(IX + 2);
                        mpf_dots[3] = ((PeekByte(IX + 2) & 0b01000000) == 0x40) ? true : false;
                        mpf_leds[4] = PeekByte(IX + 1);
                        mpf_dots[4] = ((PeekByte(IX + 1) & 0b01000000) == 0x40) ? true : false;
                        mpf_leds[5] = PeekByte(IX + 0);
                        mpf_dots[5] = ((PeekByte(IX + 0) & 0b01000000) == 0x40) ? true : false;
                        dmp = true;
                    }
                    if (disp == 0x05E4) { // Capturamos la llamada a TONE
                        tone = true;
                        led_tone?.Invoke("ON"); // Encedemos el led verde justo antes de ejecutar esta sentencia
                    }
                    MemPtr = disp;
                    // Log(String.Format("CALL {0,-6:X}", disp));
                    PushStack(PC + 2);
                    PC = disp;

                    break;

                case 0xD4:  //CALL NC, nn
                    disp = PeekWord(PC);
                    MemPtr = disp;
                    // Log(String.Format("CALL NC, {0,-6:X}", disp));
                    if ((F & F_CARRY) == 0) {
                        PushStack(PC + 2);
                        PC = disp;
                    } else {
                        PC += 2;
                    }
                    break;

                case 0xDC:  //CALL C, nn
                    disp = PeekWord(PC);
                    MemPtr = disp;
                    // Log(String.Format("CALL C, {0,-6:X}", disp));
                    if ((F & F_CARRY) != 0) {
                        PushStack(PC + 2);
                        PC = disp;
                    } else {
                        PC += 2;
                    }
                    break;

                case 0xE4:  //CALL PO, nn
                    disp = PeekWord(PC);
                    MemPtr = disp;
                    // Log(String.Format("CALL PO, {0,-6:X}", disp));
                    if ((F & F_PARITY) == 0) {
                        PushStack(PC + 2);
                        PC = disp;
                    } else {
                        PC += 2;
                    }
                    break;

                case 0xEC:  //CALL PE, nn
                    disp = PeekWord(PC);
                    MemPtr = disp;
                    // Log(String.Format("CALL PE, {0,-6:X}", disp));
                    if ((F & F_PARITY) != 0) {
                        PushStack(PC + 2);
                        PC = disp;
                    } else {
                        PC += 2;
                    }
                    break;

                case 0xF4:  //CALL P, nn
                    disp = PeekWord(PC);
                    MemPtr = disp;
                    // Log(String.Format("CALL P, {0,-6:X}", disp));
                    if ((F & F_SIGN) == 0) {
                        PushStack(PC + 2);
                        PC = disp;
                    } else {
                        PC += 2;
                    }
                    break;

                case 0xFC:  //CALL M, nn
                    disp = PeekWord(PC);
                    MemPtr = disp;
                    // Log(String.Format("CALL M, {0,-6:X}", disp));
                    if ((F & F_SIGN) != 0) {
                        PushStack(PC + 2);
                        PC = disp;
                    } else {
                        PC += 2;
                    }
                    break;
#endregion

#region Restart instructions (RST n)
                case 0xC7:  //RST 0x00
                    // Log("RST 00");
                    PushStack(PC);
                    PC = 0x00;
                    MemPtr = PC;
                    break;

                case 0xCF:  //RST 0x08
                    // Log("RST 08");
                    PushStack(PC);
                    PC = 0x08;
                    MemPtr = PC;
                    break;

                case 0xD7:  //RST 0x10
                    // Log("RST 10");
                    PushStack(PC);
                    PC = 0x10;
                    MemPtr = PC;
                    break;

                case 0xDF:  //RST 0x18
                    // Log("RST 18");
                    PushStack(PC);
                    PC = 0x18;
                    MemPtr = PC;
                    break;

                case 0xE7:  //RST 0x20
                    // Log("RST 20");
                    PushStack(PC);
                    PC = 0x20;
                    MemPtr = PC;
                    break;

                case 0xEF:  //RST 0x28
                    // Log("RST 28");
                    PushStack(PC);
                    PC = 0x28;
                    MemPtr = PC;
                    break;

                case 0xF7:  //RST 0x30
                    // Log("RST 30");
                    PushStack(PC);
                    PC = 0x30;
                    MemPtr = PC;
                    break;

                case 0xFF:  //RST 0x38
                    // Log("RST 38");
                    PushStack(PC);
                    PC = 0x38;
                    MemPtr = PC;
                    break;
#endregion

#region IN A, (n)
                case 0xDB:  //IN A, (n)
                    
                    disp = PeekByte(PC);
                    //int port = (A << 8) | disp; // Sinclair zx Spectrum
                    int port = disp;
                    //if (((disp & 0x1) == 0) &&  and_32_Or_64)
                    //    CheckEdgeLoader2();
          
                    // Log(String.Format("IN A, ({0:X})", disp));
                    //MemPtr = (A << 8) + disp + 1;
                    MemPtr = disp + 1;
                    A = In(port);
                    //Auto-load tape routine kicks in here
                    //ULA port?
   
                    and_32_Or_64 = false;
                    PC++;
                    break;
#endregion

#region OUT (n), A
                case 0xD3:  //OUT (n), A
                    disp = PeekByte(PC);
                    // Log(String.Format("OUT ({0:X}), A", disp));
                    //Out(disp | (A << 8), A);        // Sinclair zx Spectrum
                    Out(disp , A);                  // MPF 1b
                    //MemPtr = ((disp + 1) & 0xff) | (A << 8);
                    MemPtr = (disp + 1);  //#TODO hacer el incremento circular 
                    PC++;
                    break;
#endregion

#region Decimal Adjust Accumulator (DAA)
                case 0x27:  //DAA
                    // Log("DAA");
                    DAA();
                    break;
#endregion

#region Complement (CPL)
                case 0x2f:  //CPL
                    // Log("CPL");
                    A = A ^ 0xff;
                    SetF3((A & F_3) != 0);
                    SetF5((A & F_5) != 0);
                    SetNeg(true);
                    SetHalf(true);
                    break;
                #endregion

#region Halt (HALT) 
                // #rmsvdp#
                // Para simular que el Z80 se queda bloqueado, no incrementamos PC
                // De esta forma en la siguiente interacción de Process() vuelve a este 
                // mismo sitio.
                // Hay que bloquear Invoke, porque sino nos quedamos sin interacción
                // en el formulario.
                case 0x76:  //HALT
                    // Log("HALT");
                    PC--;
                    if (!HaltOn)
                    {
                        led_red?.Invoke("ON");
                        HaltOn = true;
                    }
                    break;
#endregion

#region Interrupts
                case 0xF3:  //DI
                    // Log("DI");
                    IFF1 = false;
                    IFF2 = false;
                    break;

                case 0xFB:  //EI
                    // Log("EI");
                    IFF1 = true;
                    IFF2 = true;
                    lastOpcodeWasEI = 1;

                    break;
#endregion

#region Opcodes with CB prefix
                case 0xCB:
                    switch (opcode = FetchInstruction()) {
#region Rotate instructions
                        case 0x00: //RLC B
                            // Log("RLC B");
                            B = Rlc_R(B);
                            break;

                        case 0x01: //RLC C
                            // Log("RLC C");
                            C = Rlc_R(C);
                            break;

                        case 0x02: //RLC D
                            // Log("RLC D");
                            D = Rlc_R(D);
                            break;

                        case 0x03: //RLC E
                            // Log("RLC E");
                            E = Rlc_R(E);
                            break;

                        case 0x04: //RLC H
                            // Log("RLC H");
                            H = Rlc_R(H);
                            break;

                        case 0x05: //RLC L
                            // Log("RLC L");
                            L = Rlc_R(L);
                            break;

                        case 0x06: //RLC (HL)
                            // Log("RLC (HL)");
                            disp = PeekByte(HL);
                            
                            PokeByte(HL, Rlc_R(disp));
                            break;

                        case 0x07: //RLC A
                            // Log("RLC A");
                            A = Rlc_R(A);
                            break;

                        case 0x08: //RRC B
                            // Log("RRC B");
                            B = Rrc_R(B);
                            break;

                        case 0x09: //RRC C
                            // Log("RRC C");
                            C = Rrc_R(C);
                            break;

                        case 0x0A: //RRC D
                            // Log("RRC D");
                            D = Rrc_R(D);
                            break;

                        case 0x0B: //RRC E
                            // Log("RRC E");
                            E = Rrc_R(E);
                            break;

                        case 0x0C: //RRC H
                            // Log("RRC H");
                            H = Rrc_R(H);
                            break;

                        case 0x0D: //RRC L
                            // Log("RRC L");
                            L = Rrc_R(L);
                            break;

                        case 0x0E: //RRC (HL)
                            // Log("RRC (HL)");
                            disp = PeekByte(HL);
                            
                            PokeByte(HL, Rrc_R(disp));
                            break;

                        case 0x0F: //RRC A
                            // Log("RRC A");
                            A = Rrc_R(A);
                            break;

                        case 0x10: //RL B
                            // Log("RL B");
                            B = Rl_R(B);
                            break;

                        case 0x11: //RL C
                            // Log("RL C");
                            C = Rl_R(C);
                            break;

                        case 0x12: //RL D
                            // Log("RL D");
                            D = Rl_R(D);
                            break;

                        case 0x13: //RL E
                            // Log("RL E");
                            E = Rl_R(E);
                            break;

                        case 0x14: //RL H
                            // Log("RL H");
                            H = Rl_R(H);
                            break;

                        case 0x15: //RL L
                            // Log("RL L");
                            L = Rl_R(L);
                            break;

                        case 0x16: //RL (HL)
                            // Log("RL (HL)");
                            disp = PeekByte(HL);
                            
                            PokeByte(HL, Rl_R(disp));
                            break;

                        case 0x17: //RL A
                            // Log("RL A");
                            A = Rl_R(A);
                            break;

                        case 0x18: //RR B
                            // Log("RR B");
                            B = Rr_R(B);
                            break;

                        case 0x19: //RR C
                            // Log("RR C");
                            C = Rr_R(C);
                            break;

                        case 0x1A: //RR D
                            // Log("RR D");
                            D = Rr_R(D);
                            break;

                        case 0x1B: //RR E
                            // Log("RR E");
                            E = Rr_R(E);
                            break;

                        case 0x1C: //RR H
                            // Log("RR H");
                            H = Rr_R(H);
                            break;

                        case 0x1D: //RR L
                            // Log("RR L");
                            L = Rr_R(L);
                            break;

                        case 0x1E: //RR (HL)
                            // Log("RR (HL)");
                            disp = PeekByte(HL);
                            
                            PokeByte(HL, Rr_R(disp));
                            break;

                        case 0x1F: //RR A
                            // Log("RR A");
                            A = Rr_R(A);
                            break;
#endregion

#region Register shifts
                        case 0x20:  //SLA B
                            // Log("SLA B");
                            B = Sla_R(B);
                            break;

                        case 0x21:  //SLA C
                            // Log("SLA C");
                            C = Sla_R(C);
                            break;

                        case 0x22:  //SLA D
                            // Log("SLA D");
                            D = Sla_R(D);
                            break;

                        case 0x23:  //SLA E
                            // Log("SLA E");
                            E = Sla_R(E);
                            break;

                        case 0x24:  //SLA H
                            // Log("SLA H");
                            H = Sla_R(H);
                            break;

                        case 0x25:  //SLA L
                            // Log("SLA L");
                            L = Sla_R(L);
                            break;

                        case 0x26:  //SLA (HL)
                            // Log("SLA (HL)");
                            disp = PeekByte(HL);
                            
                            PokeByte(HL, Sla_R(disp));
                            break;

                        case 0x27:  //SLA A
                            // Log("SLA A");
                            A = Sla_R(A);
                            break;

                        case 0x28:  //SRA B
                            // Log("SRA B");
                            B = Sra_R(B);
                            break;

                        case 0x29:  //SRA C
                            // Log("SRA C");
                            C = Sra_R(C);
                            break;

                        case 0x2A:  //SRA D
                            // Log("SRA D");
                            D = Sra_R(D);
                            break;

                        case 0x2B:  //SRA E
                            // Log("SRA E");
                            E = Sra_R(E);
                            break;

                        case 0x2C:  //SRA H
                            // Log("SRA H");
                            H = Sra_R(H);
                            break;

                        case 0x2D:  //SRA L
                            // Log("SRA L");
                            L = Sra_R(L);
                            break;

                        case 0x2E:  //SRA (HL)
                            // Log("SRA (HL)");
                            disp = PeekByte(HL);
                            
                            PokeByte(HL, Sra_R(disp));
                            break;

                        case 0x2F:  //SRA A
                            // Log("SRA A");
                            A = Sra_R(A);
                            break;

                        case 0x30:  //SLL B
                            // Log("SLL B");
                            B = Sll_R(B);
                            break;

                        case 0x31:  //SLL C
                            // Log("SLL C");
                            C = Sll_R(C);
                            break;

                        case 0x32:  //SLL D
                            // Log("SLL D");
                            D = Sll_R(D);
                            break;

                        case 0x33:  //SLL E
                            // Log("SLL E");
                            E = Sll_R(E);
                            break;

                        case 0x34:  //SLL H
                            // Log("SLL H");
                            H = Sll_R(H);
                            break;

                        case 0x35:  //SLL L
                            // Log("SLL L");
                            L = Sll_R(L);
                            break;

                        case 0x36:  //SLL (HL)
                            // Log("SLL (HL)");
                            disp = PeekByte(HL);
                            
                            PokeByte(HL, Sll_R(disp));
                            break;

                        case 0x37:  //SLL A
                            // Log("SLL A");
                            //tstates += 8;
                            A = Sll_R(A);
                            break;

                        case 0x38:  //SRL B
                            // Log("SRL B");
                            //tstates += 8;
                            B = Srl_R(B);
                            break;

                        case 0x39:  //SRL C
                            // Log("SRL C");
                            //tstates += 8;
                            C = Srl_R(C);
                            break;

                        case 0x3A:  //SRL D
                            // Log("SRL D");
                            //tstates += 8;
                            D = Srl_R(D);
                            break;

                        case 0x3B:  //SRL E
                            // Log("SRL E");
                            //tstates += 8;
                            E = Srl_R(E);
                            break;

                        case 0x3C:  //SRL H
                            // Log("SRL H");
                            //tstates += 8;
                            H = Srl_R(H);
                            break;

                        case 0x3D:  //SRL L
                            // Log("SRL L");
                            //tstates += 8;
                            L = Srl_R(L);
                            break;

                        case 0x3E:  //SRL (HL)
                            // Log("SRL (HL)");
                            disp = PeekByte(HL);
                            
                            PokeByte(HL, Srl_R(disp));
                            break;

                        case 0x3F:  //SRL A
                            // Log("SRL A");
                            A = Srl_R(A);
                            break;
#endregion

#region Bit test operation (BIT b, r)
                        case 0x40:  //BIT 0, B
                            // Log("BIT 0, B");
                            Bit_R(0, B);
                            break;

                        case 0x41:  //BIT 0, C
                            // Log("BIT 0, C");
                            Bit_R(0, C);
                            break;

                        case 0x42:  //BIT 0, D
                            // Log("BIT 0, D");
                            Bit_R(0, D);
                            break;

                        case 0x43:  //BIT 0, E
                            // Log("BIT 0, E");
                            Bit_R(0, E);
                            break;

                        case 0x44:  //BIT 0, H
                            // Log("BIT 0, H");
                            Bit_R(0, H);
                            break;

                        case 0x45:  //BIT 0, L
                            // Log("BIT 0, L");
                            Bit_R(0, L);
                            break;

                        case 0x46:  //BIT 0, (HL)
                            // Log("BIT 0, (HL)");
                            Bit_R(0, PeekByte(HL));
                            
                            SetF3((MemPtr & MEMPTR_11) != 0);
                            SetF5((MemPtr & MEMPTR_13) != 0);
                            break;

                        case 0x47:  //BIT 0, A
                            // Log("BIT 0, A");
                            Bit_R(0, A);
                            break;

                        case 0x48:  //BIT 1, B
                            // Log("BIT 1, B");
                            Bit_R(1, B);
                            break;

                        case 0x49:  //BIT 1, C
                            // Log("BIT 1, C");
                            Bit_R(1, C);
                            break;

                        case 0x4A:  //BIT 1, D
                            // Log("BIT 1, D");
                            Bit_R(1, D);
                            break;

                        case 0x4B:  //BIT 1, E
                            // Log("BIT 1, E");
                            Bit_R(1, E);
                            break;

                        case 0x4C:  //BIT 1, H
                            // Log("BIT 1, H");
                            Bit_R(1, H);
                            break;

                        case 0x4D:  //BIT 1, L
                            // Log("BIT 1, L");
                            Bit_R(1, L);
                            break;

                        case 0x4E:  //BIT 1, (HL)
                            // Log("BIT 1, (HL)");
                            Bit_R(1, PeekByte(HL));
                            
                            SetF3((MemPtr & MEMPTR_11) != 0);
                            SetF5((MemPtr & MEMPTR_13) != 0);
                            break;

                        case 0x4F:  //BIT 1, A
                            // Log("BIT 1, A");
                            Bit_R(1, A);
                            break;

                        case 0x50:  //BIT 2, B
                            // Log("BIT 2, B");
                            Bit_R(2, B);
                            break;

                        case 0x51:  //BIT 2, C
                            // Log("BIT 2, C");
                            Bit_R(2, C);
                            break;

                        case 0x52:  //BIT 2, D
                            // Log("BIT 2, D");
                            Bit_R(2, D);
                            break;

                        case 0x53:  //BIT 2, E
                            // Log("BIT 2, E");
                            Bit_R(2, E);
                            break;

                        case 0x54:  //BIT 2, H
                            // Log("BIT 2, H");
                            Bit_R(2, H);
                            break;

                        case 0x55:  //BIT 2, L
                            // Log("BIT 2, L");
                            Bit_R(2, L);
                            break;

                        case 0x56:  //BIT 2, (HL)
                            // Log("BIT 2, (HL)");
                            Bit_R(2, PeekByte(HL));
                            
                            SetF3((MemPtr & MEMPTR_11) != 0);
                            SetF5((MemPtr & MEMPTR_13) != 0);
                            break;

                        case 0x57:  //BIT 2, A
                            // Log("BIT 2, A");
                            Bit_R(2, A);
                            break;

                        case 0x58:  //BIT 3, B
                            // Log("BIT 3, B");
                            Bit_R(3, B);
                            break;

                        case 0x59:  //BIT 3, C
                            // Log("BIT 3, C");
                            Bit_R(3, C);
                            break;

                        case 0x5A:  //BIT 3, D
                            // Log("BIT 3, D");
                            Bit_R(3, D);
                            break;

                        case 0x5B:  //BIT 3, E
                            // Log("BIT 3, E");
                            Bit_R(3, E);
                            break;

                        case 0x5C:  //BIT 3, H
                            // Log("BIT 3, H");
                            Bit_R(3, H);
                            break;

                        case 0x5D:  //BIT 3, L
                            // Log("BIT 3, L");
                            Bit_R(3, L);
                            break;

                        case 0x5E:  //BIT 3, (HL)
                            // Log("BIT 3, (HL)");
                            Bit_R(3, PeekByte(HL));
                            
                            SetF3((MemPtr & MEMPTR_11) != 0);
                            SetF5((MemPtr & MEMPTR_13) != 0);
                            break;

                        case 0x5F:  //BIT 3, A
                            // Log("BIT 3, A");
                            Bit_R(3, A);
                            break;

                        case 0x60:  //BIT 4, B
                            // Log("BIT 4, B");
                            Bit_R(4, B);
                            break;

                        case 0x61:  //BIT 4, C
                            // Log("BIT 4, C");
                            Bit_R(4, C);
                            break;

                        case 0x62:  //BIT 4, D
                            // Log("BIT 4, D");
                            Bit_R(4, D);
                            break;

                        case 0x63:  //BIT 4, E
                            // Log("BIT 4, E");
                            Bit_R(4, E);
                            break;

                        case 0x64:  //BIT 4, H
                            // Log("BIT 4, H");
                            Bit_R(4, H);
                            break;

                        case 0x65:  //BIT 4, L
                            // Log("BIT 4, L");
                            Bit_R(4, L);
                            break;

                        case 0x66:  //BIT 4, (HL)
                            // Log("BIT 4, (HL)");
                            Bit_R(4, PeekByte(HL));
                            
                            SetF3((MemPtr & MEMPTR_11) != 0);
                            SetF5((MemPtr & MEMPTR_13) != 0);
                            break;

                        case 0x67:  //BIT 4, A
                            // Log("BIT 4, A");
                            Bit_R(4, A);
                            break;

                        case 0x68:  //BIT 5, B
                            // Log("BIT 5, B");
                            Bit_R(5, B);
                            break;

                        case 0x69:  //BIT 5, C
                            // Log("BIT 5, C");
                            Bit_R(5, C);
                            break;

                        case 0x6A:  //BIT 5, D
                            // Log("BIT 5, D");
                            Bit_R(5, D);
                            break;

                        case 0x6B:  //BIT 5, E
                            // Log("BIT 5, E");
                            Bit_R(5, E);
                            break;

                        case 0x6C:  //BIT 5, H
                            // Log("BIT 5, H");
                            Bit_R(5, H);
                            break;

                        case 0x6D:  //BIT 5, L
                            // Log("BIT 5, L");
                            Bit_R(5, L);
                            break;

                        case 0x6E:  //BIT 5, (HL)
                            // Log("BIT 5, (HL)");
                            Bit_R(5, PeekByte(HL));
                            
                            SetF3((MemPtr & MEMPTR_11) != 0);
                            SetF5((MemPtr & MEMPTR_13) != 0);
                            break;

                        case 0x6F:  //BIT 5, A
                            // Log("BIT 5, A");
                            Bit_R(5, A);
                            break;

                        case 0x70:  //BIT 6, B
                            // Log("BIT 6, B");
                            Bit_R(6, B);
                            break;

                        case 0x71:  //BIT 6, C
                            // Log("BIT 6, C");
                            Bit_R(6, C);
                            break;

                        case 0x72:  //BIT 6, D
                            // Log("BIT 6, D");
                            Bit_R(6, D);
                            break;

                        case 0x73:  //BIT 6, E
                            // Log("BIT 6, E");
                            Bit_R(6, E);
                            break;

                        case 0x74:  //BIT 6, H
                            // Log("BIT 6, H");
                            Bit_R(6, H);
                            break;

                        case 0x75:  //BIT 6, L
                            // Log("BIT 6, L");
                            Bit_R(6, L);
                            break;

                        case 0x76:  //BIT 6, (HL)
                            // Log("BIT 6, (HL)");
                            Bit_R(6, PeekByte(HL));
                            
                            SetF3((MemPtr & MEMPTR_11) != 0);
                            SetF5((MemPtr & MEMPTR_13) != 0);
                            break;

                        case 0x77:  //BIT 6, A
                            // Log("BIT 6, A");
                            Bit_R(6, A);
                            break;

                        case 0x78:  //BIT 7, B
                            // Log("BIT 7, B");
                            Bit_R(7, B);
                            break;

                        case 0x79:  //BIT 7, C
                            // Log("BIT 7, C");
                            Bit_R(7, C);
                            break;

                        case 0x7A:  //BIT 7, D
                            // Log("BIT 7, D");
                            Bit_R(7, D);
                            break;

                        case 0x7B:  //BIT 7, E
                            // Log("BIT 7, E");
                            Bit_R(7, E);
                            break;

                        case 0x7C:  //BIT 7, H
                            // Log("BIT 7, H");
                            Bit_R(7, H);
                            break;

                        case 0x7D:  //BIT 7, L
                            // Log("BIT 7, L");
                            Bit_R(7, L);
                            break;

                        case 0x7E:  //BIT 7, (HL)
                            // Log("BIT 7, (HL)");
                            Bit_R(7, PeekByte(HL));
                            
                            SetF3((MemPtr & MEMPTR_11) != 0);
                            SetF5((MemPtr & MEMPTR_13) != 0);
                            break;

                        case 0x7F:  //BIT 7, A
                            // Log("BIT 7, A");
                            Bit_R(7, A);
                            break;
#endregion

#region Reset bit operation (RES b, r)
                        case 0x80:  //RES 0, B
                            // Log("RES 0, B");
                            B = Res_R(0, B);
                            break;

                        case 0x81:  //RES 0, C
                            // Log("RES 0, C");
                            C = Res_R(0, C);
                            break;

                        case 0x82:  //RES 0, D
                            // Log("RES 0, D");
                            D = Res_R(0, D);
                            break;

                        case 0x83:  //RES 0, E
                            // Log("RES 0, E");
                            E = Res_R(0, E);
                            break;

                        case 0x84:  //RES 0, H
                            // Log("RES 0, H");
                            H = Res_R(0, H);
                            break;

                        case 0x85:  //RES 0, L
                            // Log("RES 0, L");
                            L = Res_R(0, L);
                            break;

                        case 0x86:  //RES 0, (HL)
                            disp = PeekByte(HL);
                            // Log("RES 0, (HL)");
                            
                            PokeByte(HL, Res_R(0, disp));
                            break;

                        case 0x87:  //RES 0, A
                            // Log("RES 0, A");
                            A = Res_R(0, A);
                            break;

                        case 0x88:  //RES 1, B
                            // Log("RES 1, B");
                            B = Res_R(1, B);
                            break;

                        case 0x89:  //RES 1, C
                            // Log("RES 1, C");
                            C = Res_R(1, C);
                            break;

                        case 0x8A:  //RES 1, D
                            // Log("RES 1, D");
                            D = Res_R(1, D);
                            break;

                        case 0x8B:  //RES 1, E
                            // Log("RES 1, E");
                            E = Res_R(1, E);
                            break;

                        case 0x8C:  //RES 1, H
                            // Log("RES 1, H");
                            //tstates += 8;
                            H = Res_R(1, H);
                            break;

                        case 0x8D:  //RES 1, L
                            // Log("RES 1, L");
                            L = Res_R(1, L);
                            break;

                        case 0x8E:  //RES 1, (HL)
                            disp = PeekByte(HL);
                            // Log("RES 1, (HL)");
                            
                            PokeByte(HL, Res_R(1, disp));
                            break;

                        case 0x8F:  //RES 1, A
                            // Log("RES 1, A");
                            A = Res_R(1, A);
                            break;

                        case 0x90:  //RES 2, B
                            // Log("RES 2, B");
                            B = Res_R(2, B);
                            break;

                        case 0x91:  //RES 2, C
                            // Log("RES 2, C");
                            C = Res_R(2, C);
                            break;

                        case 0x92:  //RES 2, D
                            // Log("RES 2, D");
                            D = Res_R(2, D);
                            break;

                        case 0x93:  //RES 2, E
                            // Log("RES 2, E");
                            E = Res_R(2, E);
                            break;

                        case 0x94:  //RES 2, H
                            // Log("RES 2, H");
                            H = Res_R(2, H);
                            break;

                        case 0x95:  //RES 2, L
                            // Log("RES 2, L");
                            L = Res_R(2, L);
                            break;

                        case 0x96:  //RES 2, (HL)
                            disp = PeekByte(HL);
                            // Log("RES 2, (HL)");
                            
                            PokeByte(HL, Res_R(2, disp));
                            break;

                        case 0x97:  //RES 2, A
                            // Log("RES 2, A");
                            A = Res_R(2, A);
                            break;

                        case 0x98:  //RES 3, B
                            // Log("RES 3, B");
                            B = Res_R(3, B);
                            break;

                        case 0x99:  //RES 3, C
                            // Log("RES 3, C");
                            C = Res_R(3, C);
                            break;

                        case 0x9A:  //RES 3, D
                            // Log("RES 3, D");
                            D = Res_R(3, D);
                            break;

                        case 0x9B:  //RES 3, E
                            // Log("RES 3, E");
                            E = Res_R(3, E);
                            break;

                        case 0x9C:  //RES 3, H
                            // Log("RES 3, H");
                            H = Res_R(3, H);
                            break;

                        case 0x9D:  //RES 3, L
                            // Log("RES 3, L");
                            L = Res_R(3, L);
                            break;

                        case 0x9E:  //RES 3, (HL)
                            disp = PeekByte(HL);
                            // Log("RES 3, (HL)");
                            
                            PokeByte(HL, Res_R(3, disp));
                            break;

                        case 0x9F:  //RES 3, A
                            // Log("RES 3, A");
                            A = Res_R(3, A);
                            break;

                        case 0xA0:  //RES 4, B
                            // Log("RES 4, B");
                            B = Res_R(4, B);
                            break;

                        case 0xA1:  //RES 4, C
                            // Log("RES 4, C");
                            C = Res_R(4, C);
                            break;

                        case 0xA2:  //RES 4, D
                            // Log("RES 4, D");
                            D = Res_R(4, D);
                            break;

                        case 0xA3:  //RES 4, E
                            // Log("RES 4, E");
                            E = Res_R(4, E);
                            break;

                        case 0xA4:  //RES 4, H
                            // Log("RES 4, H");
                            H = Res_R(4, H);
                            break;

                        case 0xA5:  //RES 4, L
                            // Log("RES 4, L");
                            L = Res_R(4, L);
                            break;

                        case 0xA6:  //RES 4, (HL)
                            disp = PeekByte(HL);
                            // Log("RES 4, (HL)");
                            
                            PokeByte(HL, Res_R(4, disp));
                            break;

                        case 0xA7:  //RES 4, A
                            // Log("RES 4, A");
                            A = Res_R(4, A);
                            break;

                        case 0xA8:  //RES 5, B
                            // Log("RES 5, B");
                            B = Res_R(5, B);
                            break;

                        case 0xA9:  //RES 5, C
                            // Log("RES 5, C");
                            C = Res_R(5, C);
                            break;

                        case 0xAA:  //RES 5, D
                            // Log("RES 5, D");
                            D = Res_R(5, D);
                            break;

                        case 0xAB:  //RES 5, E
                            // Log("RES 5, E");
                            E = Res_R(5, E);
                            break;

                        case 0xAC:  //RES 5, H
                            // Log("RES 5, H");
                            H = Res_R(5, H);
                            break;

                        case 0xAD:  //RES 5, L
                            // Log("RES 5, L");
                            L = Res_R(5, L);
                            break;

                        case 0xAE:  //RES 5, (HL)
                            disp = PeekByte(HL);
                            // Log("RES 5, (HL)");
                            
                            PokeByte(HL, Res_R(5, disp));
                            break;

                        case 0xAF:  //RES 5, A
                            // Log("RES 5, A");
                            A = Res_R(5, A);
                            break;

                        case 0xB0:  //RES 6, B
                            // Log("RES 6, B");
                            B = Res_R(6, B);
                            break;

                        case 0xB1:  //RES 6, C
                            // Log("RES 6, C");
                            C = Res_R(6, C);
                            break;

                        case 0xB2:  //RES 6, D
                            // Log("RES 6, D");
                            D = Res_R(6, D);
                            break;

                        case 0xB3:  //RES 6, E
                            // Log("RES 6, E");
                            E = Res_R(6, E);
                            break;

                        case 0xB4:  //RES 6, H
                            // Log("RES 6, H");
                            H = Res_R(6, H);
                            break;

                        case 0xB5:  //RES 6, L
                            // Log("RES 6, L");
                            L = Res_R(6, L);
                            break;

                        case 0xB6:  //RES 6, (HL)
                            disp = PeekByte(HL);
                            // Log("RES 6, (HL)");
                            
                            PokeByte(HL, Res_R(6, disp));
                            break;

                        case 0xB7:  //RES 6, A
                            // Log("RES 6, A");
                            A = Res_R(6, A);
                            break;

                        case 0xB8:  //RES 7, B
                            // Log("RES 7, B");
                            B = Res_R(7, B);
                            break;

                        case 0xB9:  //RES 7, C
                            // Log("RES 7, C");
                            C = Res_R(7, C);
                            break;

                        case 0xBA:  //RES 7, D
                            // Log("RES 7, D");
                            D = Res_R(7, D);
                            break;

                        case 0xBB:  //RES 7, E
                            // Log("RES 7, E");
                            E = Res_R(7, E);
                            break;

                        case 0xBC:  //RES 7, H
                            // Log("RES 7, H");
                            H = Res_R(7, H);
                            break;

                        case 0xBD:  //RES 7, L
                            // Log("RES 7, L");
                            L = Res_R(7, L);
                            break;

                        case 0xBE:  //RES 7, (HL)
                            disp = PeekByte(HL);
                            // Log("RES 7, (HL)");
                            
                            PokeByte(HL, Res_R(7, disp));
                            break;

                        case 0xBF:  //RES 7, A
                            // Log("RES 7, A");
                            A = Res_R(7, A);
                            break;
#endregion

#region Set bit operation (SET b, r)
                        case 0xC0:  //SET 0, B
                            // Log("SET 0, B");
                            B = Set_R(0, B);
                            break;

                        case 0xC1:  //SET 0, C
                            // Log("SET 0, C");
                            C = Set_R(0, C);
                            break;

                        case 0xC2:  //SET 0, D
                            // Log("SET 0, D");
                            D = Set_R(0, D);
                            break;

                        case 0xC3:  //SET 0, E
                            // Log("SET 0, E");
                            E = Set_R(0, E);
                            break;

                        case 0xC4:  //SET 0, H
                            // Log("SET 0, H");
                            H = Set_R(0, H);
                            break;

                        case 0xC5:  //SET 0, L
                            // Log("SET 0, L");
                            L = Set_R(0, L);
                            break;

                        case 0xC6:  //SET 0, (HL)
                            disp = PeekByte(HL);
                            // Log("SET 0, (HL)");
                            
                            PokeByte(HL, Set_R(0, disp));
                            break;

                        case 0xC7:  //SET 0, A
                            // Log("SET 0, A");
                            A = Set_R(0, A);
                            break;

                        case 0xC8:  //SET 1, B
                            // Log("SET 1, B");
                            B = Set_R(1, B);
                            break;

                        case 0xC9:  //SET 1, C
                            // Log("SET 1, C");
                            C = Set_R(1, C);
                            break;

                        case 0xCA:  //SET 1, D
                            // Log("SET 1, D");
                            D = Set_R(1, D);
                            break;

                        case 0xCB:  //SET 1, E
                            // Log("SET 1, E");
                            E = Set_R(1, E);
                            break;

                        case 0xCC:  //SET 1, H
                            // Log("SET 1, H");
                            H = Set_R(1, H);
                            break;

                        case 0xCD:  //SET 1, L
                            // Log("SET 1, L");
                            L = Set_R(1, L);
                            break;

                        case 0xCE:  //SET 1, (HL)
                            disp = PeekByte(HL);
                            // Log("SET 1, (HL)");
                            
                            PokeByte(HL, Set_R(1, disp));
                            break;

                        case 0xCF:  //SET 1, A
                            // Log("SET 1, A");
                            A = Set_R(1, A);
                            break;

                        case 0xD0:  //SET 2, B
                            // Log("SET 2, B");
                            B = Set_R(2, B);
                            break;

                        case 0xD1:  //SET 2, C
                            // Log("SET 2, C");
                            C = Set_R(2, C);
                            break;

                        case 0xD2:  //SET 2, D
                            // Log("SET 2, D");
                            D = Set_R(2, D);
                            break;

                        case 0xD3:  //SET 2, E
                            // Log("SET 2, E");
                            E = Set_R(2, E);
                            break;

                        case 0xD4:  //SET 2, H
                            // Log("SET 2, H");
                            H = Set_R(2, H);
                            break;

                        case 0xD5:  //SET 2, L
                            // Log("SET 2, L");
                            L = Set_R(2, L);
                            break;

                        case 0xD6:  //SET 2, (HL)
                            disp = PeekByte(HL);
                            // Log("SET 2, (HL)");
                            
                            PokeByte(HL, Set_R(2, disp));
                            break;

                        case 0xD7:  //SET 2, A
                            // Log("SET 2, A");
                            A = Set_R(2, A);
                            break;

                        case 0xD8:  //SET 3, B
                            // Log("SET 3, B");
                            B = Set_R(3, B);
                            break;

                        case 0xD9:  //SET 3, C
                            // Log("SET 3, C");
                            C = Set_R(3, C);
                            break;

                        case 0xDA:  //SET 3, D
                            // Log("SET 3, D");
                            D = Set_R(3, D);
                            break;

                        case 0xDB:  //SET 3, E
                            // Log("SET 3, E");
                            E = Set_R(3, E);
                            break;

                        case 0xDC:  //SET 3, H
                            // Log("SET 3, H");
                            H = Set_R(3, H);
                            break;

                        case 0xDD:  //SET 3, L
                            // Log("SET 3, L");
                            L = Set_R(3, L);
                            break;

                        case 0xDE:  //SET 3, (HL)
                            disp = PeekByte(HL);
                            // Log("SET 3, (HL)");
                            
                            PokeByte(HL, Set_R(3, disp));
                            break;

                        case 0xDF:  //SET 3, A
                            // Log("SET 3, A");
                            A = Set_R(3, A);
                            break;

                        case 0xE0:  //SET 4, B
                            // Log("SET 4, B");
                            B = Set_R(4, B);
                            break;

                        case 0xE1:  //SET 4, C
                            // Log("SET 4, C");
                            C = Set_R(4, C);
                            break;

                        case 0xE2:  //SET 4, D
                            // Log("SET 4, D");
                            D = Set_R(4, D);
                            break;

                        case 0xE3:  //SET 4, E
                            // Log("SET 4, E");
                            E = Set_R(4, E);
                            break;

                        case 0xE4:  //SET 4, H
                            // Log("SET 4, H");
                            H = Set_R(4, H);
                            break;

                        case 0xE5:  //SET 4, L
                            // Log("SET 4, L");
                            L = Set_R(4, L);
                            break;

                        case 0xE6:  //SET 4, (HL)
                            disp = PeekByte(HL);
                            // Log("SET 4, (HL)");
                            PokeByte(HL, Set_R(4, disp));
                            break;

                        case 0xE7:  //SET 4, A
                            // Log("SET 4, A");
                            A = Set_R(4, A);
                            break;

                        case 0xE8:  //SET 5, B
                            // Log("SET 5, B");
                            B = Set_R(5, B);
                            break;

                        case 0xE9:  //SET 5, C
                            // Log("SET 5, C");
                            C = Set_R(5, C);
                            break;

                        case 0xEA:  //SET 5, D
                            // Log("SET 5, D");
                            D = Set_R(5, D);
                            break;

                        case 0xEB:  //SET 5, E
                            // Log("SET 5, E");
                            E = Set_R(5, E);
                            break;

                        case 0xEC:  //SET 5, H
                            // Log("SET 5, H");
                            H = Set_R(5, H);
                            break;

                        case 0xED:  //SET 5, L
                            // Log("SET 5, L");
                            L = Set_R(5, L);
                            break;

                        case 0xEE:  //SET 5, (HL)
                            disp = PeekByte(HL);
                            // Log("SET 5, (HL)");
                            PokeByte(HL, Set_R(5, disp));
                            break;

                        case 0xEF:  //SET 5, A
                            // Log("SET 5, A");
                            A = Set_R(5, A);
                            break;

                        case 0xF0:  //SET 6, B
                            // Log("SET 6, B");
                            B = Set_R(6, B);
                            break;

                        case 0xF1:  //SET 6, C
                            // Log("SET 6, C");
                            C = Set_R(6, C);
                            break;

                        case 0xF2:  //SET 6, D
                            // Log("SET 6, D");
                            D = Set_R(6, D);
                            break;

                        case 0xF3:  //SET 6, E
                            // Log("SET 6, E");
                            E = Set_R(6, E);
                            break;

                        case 0xF4:  //SET 6, H
                            // Log("SET 6, H");
                            H = Set_R(6, H);
                            break;

                        case 0xF5:  //SET 6, L
                            // Log("SET 6, L");
                            L = Set_R(6, L);
                            break;

                        case 0xF6:  //SET 6, (HL)
                            disp = PeekByte(HL);
                            // Log("SET 6, (HL)");
                            PokeByte(HL, Set_R(6, disp));
                            break;

                        case 0xF7:  //SET 6, A
                            // Log("SET 6, A");
                            A = Set_R(6, A);
                            break;

                        case 0xF8:  //SET 7, B
                            // Log("SET 7, B");
                            B = Set_R(7, B);
                            break;

                        case 0xF9:  //SET 7, C
                            // Log("SET 7, C");
                            C = Set_R(7, C);
                            break;

                        case 0xFA:  //SET 7, D
                            // Log("SET 7, D");
                            D = Set_R(7, D);
                            break;

                        case 0xFB:  //SET 7, E
                            // Log("SET 7, E");
                            E = Set_R(7, E);
                            break;

                        case 0xFC:  //SET 7, H
                            // Log("SET 7, H");
                            H = Set_R(7, H);
                            break;

                        case 0xFD:  //SET 7, L
                            // Log("SET 7, L");
                            L = Set_R(7, L);
                            break;

                        case 0xFE:  //SET 7, (HL)
                            disp = PeekByte(HL);
                            // Log("SET 7, (HL)");
                            PokeByte(HL, Set_R(7, disp));
                            break;

                        case 0xFF:  //SET 7, A
                            // Log("SET 7, A");
                            A = Set_R(7, A);
                            break;
#endregion

                        //  default:
                        //      String msg = "ERROR: Could not handle DD " + opcode.ToString();
                        //      MessageBox.Show(msg, "Opcode handler",
                        //                  MessageBoxButtons.OKCancel, MessageBoxIcon.Error);
                        //      break;
                    }
                    break;
#endregion

#region Opcodes with DD prefix (includes DDCB)
                case 0xDD:
                    switch (opcode = FetchInstruction()) {
#region Addition instructions
                        case 0x09:  //ADD IX, BC
                            // Log("ADD IX, BC");
                            
                            MemPtr = IX + 1;
                            IX = Add_RR(IX, BC);
                            break;

                        case 0x19:  //ADD IX, DE
                            // Log("ADD IX, DE");
                            
                            MemPtr = IX + 1;
                            IX = Add_RR(IX, DE);
                            break;

                        case 0x29:  //ADD IX, IX
                            // Log("ADD IX, IX");
                            
                            MemPtr = IX + 1;
                            IX = Add_RR(IX, IX);
                            break;

                        case 0x39:  //ADD IX, SP
                            // Log("ADD IX, SP");
                            
                            MemPtr = IX + 1;
                            IX = Add_RR(IX, SP);
                            break;

                        case 0x84:  //ADD A, IXH
                            // Log("ADD A, IXH");
                            Add_R(IXH);
                            break;

                        case 0x85:  //ADD A, IXL
                            // Log("ADD A, IXL");
                            Add_R(IXL);
                            break;

                        case 0x86:  //Add A, (IX+d)
                            disp = GetDisplacement(PeekByte(PC));
                            int offset = IX + disp; //The displacement required
                            // Log(string.Format("ADD A, (IX + {0:X})", disp));
                            //if (model == MachineModel._plus3)
                            //    totalTStates += 5;
                            //else
                            
                            Add_R(PeekByte(offset));
                            PC++;
                            MemPtr = offset;
                            break;

                        case 0x8C:  //ADC A, IXH
                            // Log("ADC A, IXH");
                            Adc_R(IXH);
                            break;

                        case 0x8D:  //ADC A, IXL
                            // Log("ADC A, IXL");
                            Adc_R(IXL);
                            break;

                        case 0x8E: //ADC A, (IX+d)
                            disp = GetDisplacement(PeekByte(PC));
                            offset = IX + disp; //The displacement required
                            // Log(string.Format("ADC A, (IX + {0:X})", disp));
                            //if (model == MachineModel._plus3)
                            //    totalTStates += 5;
                            //else
                            
                            Adc_R(PeekByte(offset));
                            MemPtr = offset;
                            PC++;
                            break;
#endregion

#region Subtraction instructions
                        case 0x94:  //SUB A, IXH
                            // Log("SUB A, IXH");
                            Sub_R(IXH);
                            break;

                        case 0x95:  //SUB A, IXL
                            // Log("SUB A, IXL");
                            Sub_R(IXL);
                            break;

                        case 0x96:  //SUB (IX + d)
                            disp = GetDisplacement(PeekByte(PC));
                            offset = IX + disp; //The displacement required
                            // Log(string.Format("SUB (IX + {0:X})", disp));
                            //if (model == MachineModel._plus3)
                            //    totalTStates += 5;
                            //else
                            
                            Sub_R(PeekByte(offset));
                            MemPtr = offset;
                            PC++;
                            break;

                        case 0x9C:  //SBC A, IXH
                            // Log("SBC A, IXH");
                            Sbc_R(IXH);
                            break;

                        case 0x9D:  //SBC A, IXL
                            // Log("SBC A, IXL");
                            Sbc_R(IXL);
                            break;

                        case 0x9E:  //SBC A, (IX + d)
                            disp = GetDisplacement(PeekByte(PC));
                            offset = IX + disp; //The displacement required
                            // Log(string.Format("SBC A, (IX + {0:X})", disp));
                            //if (model == MachineModel._plus3)
                            //    totalTStates += 5;
                            //else
                            
                            MemPtr = offset;
                            Sbc_R(PeekByte(offset));
                            PC++;
                            break;
#endregion

#region Increment/Decrements
                        case 0x23:  //INC IX
                            // Log("INC IX");
                            IX++;
                            break;

                        case 0x24:  //INC IXH
                            // Log("INC IXH");
                            IXH = Inc(IXH);
                            break;

                        case 0x25:  //DEC IXH
                            // Log("DEC IXH");
                            IXH = Dec(IXH);
                            break;

                        case 0x2B:  //DEC IX
                            // Log("DEC IX");
                            IX--;
                            break;

                        case 0x2C:  //INC IXL
                            // Log("INC IXL");
                            IXL = Inc(IXL);
                            break;

                        case 0x2D:  //DEC IXL
                            // Log("DEC IXL");
                            IXL = Dec(IXL);
                            break;

                        case 0x34:  //INC (IX + d)
                            disp = GetDisplacement(PeekByte(PC));
                            offset = IX + disp; //The displacement required
                            // Log(string.Format("INC (IX + {0:X})", disp));
                            disp = Inc(PeekByte(offset));                          
                            PokeByte(offset, disp);
                            MemPtr = offset;
                            PC++;
                            break;

                        case 0x35:  //DEC (IX + d)
                            disp = GetDisplacement(PeekByte(PC));
                            offset = IX + disp; //The displacement required
                            // Log(string.Format("DEC (IX + {0:X})", disp));
                            
                            disp = Dec(PeekByte(offset));
                            
                            PokeByte(offset, disp);
                            MemPtr = offset;
                            PC++;
                            break;
#endregion

#region Bitwise operators

                        case 0xA4:  //AND IXH
                            // Log("AND IXH");
                            And_R(IXH);
                            break;

                        case 0xA5:  //AND IXL
                            // Log("AND IXL");
                            And_R(IXL);
                            break;

                        case 0xA6:  //AND (IX + d)
                            disp = GetDisplacement(PeekByte(PC));
                            offset = IX + disp; //The displacement required
                            // Log(string.Format("AND (IX + {0:X})", disp));
                            //if (model == MachineModel._plus3)
                            //    totalTStates += 5;
                            //else
                            
                            And_R(PeekByte(offset));
                            MemPtr = offset;
                            PC++;
                            break;

                        case 0xAC:  //XOR IXH
                            // Log("XOR IXH");
                            Xor_R(IXH);
                            break;

                        case 0xAD:  //XOR IXL
                            // Log("XOR IXL");
                            Xor_R(IXL);
                            break;

                        case 0xAE:  //XOR (IX + d)
                            disp = GetDisplacement(PeekByte(PC));

                            offset = IX + disp; //The displacement required
                            // Log(string.Format("XOR (IX + {0:X})", disp));
                            //if (model == MachineModel._plus3)
                            //    totalTStates += 5;
                            //else
                            
                            Xor_R(PeekByte(offset));
                            MemPtr = offset;
                            PC++;
                            break;

                        case 0xB4:  //OR IXH
                            // Log("OR IXH");
                            Or_R(IXH);
                            break;

                        case 0xB5:  //OR IXL
                            // Log("OR IXL");
                            Or_R(IXL);
                            break;

                        case 0xB6:  //OR (IX + d)
                            disp = GetDisplacement(PeekByte(PC));

                            offset = IX + disp; //The displacement required
                            // Log(string.Format("OR (IX + {0:X})", disp));
                            //if (model == MachineModel._plus3)
                            //    totalTStates += 5;
                            //else
                            
                            Or_R(PeekByte(offset));
                            MemPtr = offset;
                            PC++;
                            break;
#endregion

#region Compare operator
                        case 0xBC:  //CP IXH
                            // Log("CP IXH");
                            Cp_R(IXH);
                            break;

                        case 0xBD:  //CP IXL
                            // Log("CP IXL");
                            Cp_R(IXL);
                            break;

                        case 0xBE:  //CP (IX + d)
                            disp = GetDisplacement(PeekByte(PC));

                            offset = IX + disp; //The displacement required
                            // Log(string.Format("CP (IX + {0:X})", disp));
                            //if (model == MachineModel._plus3)
                            //    totalTStates += 5;
                            //else
                            
                            Cp_R(PeekByte(offset));
                            MemPtr = offset;
                            PC++;
                            break;
#endregion

#region Load instructions
                        case 0x21:  //LD IX, nn
                            // Log(string.Format("LD IX, {0,-6:X}", PeekWord(PC)));
                            IX = PeekWord(PC);
                            PC += 2;
                            break;

                        case 0x22:  //LD (nn), IX
                            // Log(string.Format("LD ({0:X}), IX", PeekWord(PC)));
                            addr = PeekWord(PC);
                            PokeWord(addr, IX);
                            PC += 2;
                            MemPtr = addr + 1;
                            break;

                        case 0x26:  //LD IXH, n
                            // Log(string.Format("LD IXH, {0:X}", PeekByte(PC)));
                            IXH = PeekByte(PC);
                            PC++;
                            break;

                        case 0x2A:  //LD IX, (nn)
                            // Log(string.Format("LD IX, ({0:X})", PeekWord(PC)));
                            addr = PeekWord(PC);
                            IX = PeekWord(addr);
                            MemPtr = addr + 1;
                            PC += 2;
                            break;

                        case 0x2E:  //LD IXL, n
                            // Log(string.Format("LD IXL, {0:X}", PeekByte(PC)));
                            IXL = PeekByte(PC);
                            PC++;
                            break;

                        case 0x36:  //LD (IX + d), n
                            disp = GetDisplacement(PeekByte(PC));

                            offset = IX + disp; //The displacement required
                            // Log(string.Format("LD (IX + {0:X}), {1,-6:X}", disp, PeekByte(PC + 1)));
                            disp = PeekByte(PC + 1);
                            PokeByte(offset, disp);
                            MemPtr = offset;
                            PC += 2;
                            break;

                        case 0x44:  //LD B, IXH
                            // Log("LD B, IXH");
                            B = IXH;
                            break;

                        case 0x45:  //LD B, IXL
                            // Log("LD B, IXL");
                            B = IXL;
                            break;

                        case 0x46:  //LD B, (IX + d)
                            disp = GetDisplacement(PeekByte(PC));
                            offset = IX + disp; //The displacement required
                            // Log(string.Format("LD B, (IX + {0:X})", disp));
                            B = PeekByte(offset);
                            MemPtr = offset;
                            PC++;
                            break;

                        case 0x4C:  //LD C, IXH
                            // Log("LD C, IXH");
                            C = IXH;
                            break;

                        case 0x4D:  //LD C, IXL
                            // Log("LD C, IXL");
                            C = IXL;
                            break;

                        case 0x4E:  //LD C, (IX + d)
                            disp = GetDisplacement(PeekByte(PC));

                            offset = IX + disp; //The displacement required
                            // Log(string.Format("LD C, (IX + {0:X})", disp));                         
                            C = PeekByte(offset);
                            MemPtr = offset;
                            PC++;
                            break;

                        case 0x54:  //LD D, IXH
                            // Log("LD D, IXH");
                            //tstates += 4;
                            D = IXH;
                            break;

                        case 0x55:  //LD D, IXL
                            // Log("LD D, IXL");
                            //tstates += 4;
                            D = IXL;
                            break;

                        case 0x56:  //LD D, (IX + d)
                            disp = GetDisplacement(PeekByte(PC));

                            offset = IX + disp; //The displacement required
                            // Log(string.Format("LD D, (IX + {0:X})", disp));                         
                            D = PeekByte(offset);
                            MemPtr = offset;
                            PC++;
                            break;

                        case 0x5C:  //LD E, IXH
                            // Log("LD E, IXH");
                            //tstates += 4;
                            E = IXH;
                            break;

                        case 0x5D:  //LD E, IXL
                            // Log("LD E, IXL");
                            //tstates += 4;
                            E = IXL;
                            break;

                        case 0x5E:  //LD E, (IX + d)
                            disp = GetDisplacement(PeekByte(PC));

                            offset = IX + disp; //The displacement required
                            // Log(string.Format("LD E, (IX + {0:X})", disp));                       
                            E = PeekByte(offset);
                            MemPtr = offset;
                            PC++;
                            break;

                        case 0x60:  //LD IXH, B
                            // Log("LD IXH, B");
                            //tstates += 4;
                            IXH = B;
                            break;

                        case 0x61:  //LD IXH, C
                            // Log("LD IXH, C");
                            //tstates += 4;
                            IXH = C;
                            break;

                        case 0x62:  //LD IXH, D
                            // Log("LD IXH, D");
                            //tstates += 4;
                            IXH = D;
                            break;

                        case 0x63:  //LD IXH, E
                            // Log("LD IXH, E");
                            //tstates += 4;
                            IXH = E;
                            break;

                        case 0x64:  //LD IXH, IXH
                            // Log("LD IXH, IXH");
                            //tstates += 4;
                            IXH = IXH;
                            break;

                        case 0x65:  //LD IXH, IXL
                            // Log("LD IXH, IXL");
                            //tstates += 4;
                            IXH = IXL;
                            break;

                        case 0x66:  //LD H, (IX + d)
                            disp = GetDisplacement(PeekByte(PC));

                            offset = IX + disp; //The displacement required
                            // Log(string.Format("LD H, (IX + {0:X})", disp));
                            H = PeekByte(offset);
                            MemPtr = offset;
                            PC++;
                            break;

                        case 0x67:  //LD IXH, A
                            // Log("LD IXH, A");
                            //tstates += 4;
                            IXH = A;
                            break;

                        case 0x68:  //LD IXL, B
                            // Log("LD IXL, B");
                            //tstates += 4;
                            IXL = B;
                            break;

                        case 0x69:  //LD IXL, C
                            // Log("LD IXL, C");
                            //tstates += 4;
                            IXL = C;
                            break;

                        case 0x6A:  //LD IXL, D
                            // Log("LD IXL, D");
                            //tstates += 4;
                            IXL = D;
                            break;

                        case 0x6B:  //LD IXL, E
                            // Log("LD IXL, E");
                            //tstates += 4;
                            IXL = E;
                            break;

                        case 0x6C:  //LD IXL, IXH
                            // Log("LD IXL, IXH");
                            //tstates += 4;
                            IXL = IXH;
                            break;

                        case 0x6D:  //LD IXL, IXL
                            // Log("LD IXL, IXL");
                            //tstates += 4;
                            IXL = IXL;
                            break;

                        case 0x6E:  //LD L, (IX + d)
                            disp = GetDisplacement(PeekByte(PC));

                            offset = IX + disp; //The displacement required
                            // Log(string.Format("LD L, (IX + {0:X})", disp));                           
                            L = PeekByte(offset);
                            MemPtr = offset;
                            PC++;
                            break;

                        case 0x6F:  //LD IXL, A
                            // Log("LD IXL, A");
                            //tstates += 4;
                            IXL = A;
                            break;

                        case 0x70:  //LD (IX + d), B
                            disp = GetDisplacement(PeekByte(PC));

                            offset = IX + disp; //The displacement required
                            // Log(string.Format("LD (IX + {0:X}), B", disp));                         
                            PokeByte(offset, B);
                            MemPtr = offset;
                            PC++;
                            break;

                        case 0x71:  //LD (IX + d), C
                            disp = GetDisplacement(PeekByte(PC));

                            offset = IX + disp; //The displacement required
                            // Log(string.Format("LD (IX + {0:X}), C", disp));
                            PokeByte(offset, C);
                            MemPtr = offset;
                            PC++;
                            break;

                        case 0x72:  //LD (IX + d), D
                            disp = GetDisplacement(PeekByte(PC));

                            offset = IX + disp; //The displacement required
                            // Log(string.Format("LD (IX + {0:X}), D", disp));
                            PokeByte(offset, D);
                            MemPtr = offset;
                            PC++;
                            break;

                        case 0x73:  //LD (IX + d), E
                            disp = GetDisplacement(PeekByte(PC));

                            offset = IX + disp; //The displacement required
                            // Log(string.Format("LD (IX + {0:X}), E", disp));
                            PokeByte(offset, E);
                            MemPtr = offset;
                            PC++;
                            break;

                        case 0x74:  //LD (IX + d), H
                            disp = GetDisplacement(PeekByte(PC));

                            offset = IX + disp; //The displacement required
                            // Log(string.Format("LD (IX + {0:X}), H", disp));
                            PokeByte(offset, H);
                            MemPtr = offset;
                            PC++;
                            break;

                        case 0x75:  //LD (IX + d), L
                            disp = GetDisplacement(PeekByte(PC));

                            offset = IX + disp; //The displacement required
                            // Log(string.Format("LD (IX + {0:X}), L", disp));
                            PokeByte(offset, L);
                            MemPtr = offset;
                            PC++;
                            break;

                        case 0x77:  //LD (IX + d), A
                            disp = GetDisplacement(PeekByte(PC));

                            offset = IX + disp; //The displacement required
                            // Log(string.Format("LD (IX + {0:X}), A", disp));
                            PokeByte(offset, A);
                            MemPtr = offset;
                            PC++;
                            break;

                        case 0x7C:  //LD A, IXH
                            // Log("LD A, IXH");
                            A = IXH;
                            break;

                        case 0x7D:  //LD A, IXL
                            // Log("LD A, IXL");
                            A = IXL;
                            break;

                        case 0x7E:  //LD A, (IX + d)
                            disp = GetDisplacement(PeekByte(PC));

                            offset = IX + disp; //The displacement required
                            // Log(string.Format("LD A, (IX + {0:X})", disp));
                            A = PeekByte(offset);
                            MemPtr = offset;
                            PC++;
                            break;

                        case 0xF9:  //LD SP, IX
                            // Log("LD SP, IX");
                            
                            SP = IX;
                            break;
#endregion

#region All DDCB instructions
                        case 0xCB:
                            disp = GetDisplacement(PeekByte(PC));
                            offset = IX + disp; //The displacement required
                            PC++;
                            opcode = GetOpcode(PC);      //The opcode comes after the offset byte!
                            PC++;
                            disp = PeekByte(offset);
                            
                            // if ((opcode >= 0x40) && (opcode <= 0x7f))
                            MemPtr = offset;

                            switch (opcode) {
                                case 0x00: //LD B, RLC (IX+d)
                                    // Log(string.Format("LD B, RLC (IX + {0:X})", disp));
                                    B = Rlc_R(disp);
                                    PokeByte(offset, B);
                                    break;

                                case 0x01: //LD C, RLC (IX+d)
                                    // Log(string.Format("LD C, RLC (IX + {0:X})", disp));
                                    C = Rlc_R(disp);
                                    PokeByte(offset, C);
                                    break;

                                case 0x02: //LD D, RLC (IX+d)
                                    // Log(string.Format("LD D, RLC (IX + {0:X})", disp));
                                    D = Rlc_R(disp);
                                    PokeByte(offset, D);
                                    break;

                                case 0x03: //LD E, RLC (IX+d)
                                    // Log(string.Format("LD E, RLC (IX + {0:X})", disp));
                                    E = Rlc_R(disp);
                                    PokeByte(offset, E);
                                    break;

                                case 0x04: //LD H, RLC (IX+d)
                                    // Log(string.Format("LD H, RLC (IX + {0:X})", disp));
                                    H = Rlc_R(disp);
                                    PokeByte(offset, H);
                                    break;

                                case 0x05: //LD L, RLC (IX+d)
                                    // Log(string.Format("LD L, RLC (IX + {0:X})", disp));
                                    L = Rlc_R(disp);
                                    PokeByte(offset, L);
                                    break;

                                case 0x06:  //RLC (IX + d)
                                    // Log(string.Format("RLC (IX + {0:X})", disp));
                                    PokeByte(offset, Rlc_R(disp));
                                    break;

                                case 0x07: //LD A, RLC (IX+d)
                                    // Log(string.Format("LD A, RLC (IX + {0:X})", disp));
                                    A = Rlc_R(disp);
                                    PokeByte(offset, A);
                                    break;

                                case 0x08: //LD B, RRC (IX+d)
                                    // Log(string.Format("LD B, RRC (IX + {0:X})", disp));
                                    B = Rrc_R(disp);
                                    PokeByte(offset, B);
                                    break;

                                case 0x09: //LD C, RRC (IX+d)
                                    // Log(string.Format("LD C, RRC (IX + {0:X})", disp));
                                    C = Rrc_R(disp);
                                    PokeByte(offset, C);
                                    break;

                                case 0x0A: //LD D, RRC (IX+d)
                                    // Log(string.Format("LD D, RRC (IX + {0:X})", disp));
                                    D = Rrc_R(disp);
                                    PokeByte(offset, D);
                                    break;

                                case 0x0B: //LD E, RRC (IX+d)
                                    // Log(string.Format("LD E, RRC (IX + {0:X})", disp));
                                    E = Rrc_R(disp);
                                    PokeByte(offset, E);
                                    break;

                                case 0x0C: //LD H, RRC (IX+d)
                                    // Log(string.Format("LD H, RRC (IX + {0:X})", disp));
                                    H = Rrc_R(disp);
                                    PokeByte(offset, H);
                                    break;

                                case 0x0D: //LD L, RRC (IX+d)
                                    // Log(string.Format("LD L, RRC (IX + {0:X})", disp));
                                    L = Rrc_R(disp);
                                    PokeByte(offset, L);
                                    break;

                                case 0x0E:  //RRC (IX + d)
                                    // Log(string.Format("RRC (IX + {0:X})", disp));
                                    PokeByte(offset, Rrc_R(disp));
                                    break;

                                case 0x0F: //LD A, RRC (IX+d)
                                    // Log(string.Format("LD A, RRC (IX + {0:X})", disp));
                                    A = Rrc_R(disp);
                                    PokeByte(offset, A);
                                    break;

                                case 0x10: //LD B, RL (IX+d)
                                    // Log(string.Format("LD B, RL (IX + {0:X})", disp));
                                    B = Rl_R(disp);
                                    PokeByte(offset, B);
                                    break;

                                case 0x11: //LD C, RL (IX+d)
                                    // Log(string.Format("LD C, RL (IX + {0:X})", disp));
                                    C = Rl_R(disp);
                                    PokeByte(offset, C);
                                    break;

                                case 0x12: //LD D, RL (IX+d)
                                    // Log(string.Format("LD D, RL (IX + {0:X})", disp));
                                    D = Rl_R(disp);
                                    PokeByte(offset, D);
                                    break;

                                case 0x13: //LD E, RL (IX+d)
                                    // Log(string.Format("LD E, RL (IX + {0:X})", disp));
                                    E = Rl_R(disp);
                                    PokeByte(offset, E);
                                    break;

                                case 0x14: //LD H, RL (IX+d)
                                    // Log(string.Format("LD H, RL (IX + {0:X})", disp));
                                    H = Rl_R(disp);
                                    PokeByte(offset, H);
                                    break;

                                case 0x15: //LD L, RL (IX+d)
                                    // Log(string.Format("LD L, RL (IX + {0:X})", disp));
                                    L = Rl_R(disp);
                                    PokeByte(offset, L);
                                    break;

                                case 0x16:  //RL (IX + d)
                                    // Log(string.Format("RL (IX + {0:X})", disp));
                                    PokeByte(offset, Rl_R(disp));

                                    break;

                                case 0x17: //LD A, RL (IX+d)
                                    // Log(string.Format("LD A, RL (IX + {0:X})", disp));
                                    A = Rl_R(disp);
                                    PokeByte(offset, A);
                                    break;

                                case 0x18: //LD B, RR (IX+d)
                                    // Log(string.Format("LD B, RR (IX + {0:X})", disp));
                                    B = Rr_R(disp);
                                    PokeByte(offset, B);
                                    break;

                                case 0x19: //LD C, RR (IX+d)
                                    // Log(string.Format("LD C, RR (IX + {0:X})", disp));
                                    C = Rr_R(disp);
                                    PokeByte(offset, C);
                                    break;

                                case 0x1A: //LD D, RR (IX+d)
                                    // Log(string.Format("LD D, RR (IX + {0:X})", disp));
                                    D = Rr_R(disp);
                                    PokeByte(offset, D);
                                    break;

                                case 0x1B: //LD E, RR (IX+d)
                                    // Log(string.Format("LD E, RR (IX + {0:X})", disp));
                                    E = Rr_R(disp);
                                    PokeByte(offset, E);
                                    break;

                                case 0x1C: //LD H, RR (IX+d)
                                    // Log(string.Format("LD H, RR (IX + {0:X})", disp));
                                    H = Rr_R(disp);
                                    PokeByte(offset, H);
                                    break;

                                case 0x1D: //LD L, RR (IX+d)
                                    // Log(string.Format("LD L, RR (IX + {0:X})", disp));
                                    L = Rr_R(disp);
                                    PokeByte(offset, L);
                                    break;

                                case 0x1E:  //RR (IX + d)
                                    // Log(string.Format("RR (IX + {0:X})", disp));
                                    PokeByte(offset, Rr_R(disp));
                                    break;

                                case 0x1F: //LD A, RR (IX+d)
                                    // Log(string.Format("LD A, RR (IX + {0:X})", disp));
                                    A = Rr_R(disp);
                                    PokeByte(offset, A);
                                    break;

                                case 0x20: //LD B, SLA (IX+d)
                                    // Log(string.Format("LD B, SLA (IX + {0:X})", disp));
                                    B = Sla_R(disp);
                                    PokeByte(offset, B);
                                    break;

                                case 0x21: //LD C, SLA (IX+d)
                                    // Log(string.Format("LD C, SLA (IX + {0:X})", disp));
                                    C = Sla_R(disp);
                                    PokeByte(offset, C);
                                    break;

                                case 0x22: //LD D, SLA (IX+d)
                                    // Log(string.Format("LD D, SLA (IX + {0:X})", disp));
                                    D = Sla_R(disp);
                                    PokeByte(offset, D);
                                    break;

                                case 0x23: //LD E, SLA (IX+d)
                                    // Log(string.Format("LD E, SLA (IX + {0:X})", disp));
                                    E = Sla_R(disp);
                                    PokeByte(offset, E);
                                    break;

                                case 0x24: //LD H, SLA (IX+d)
                                    // Log(string.Format("LD H, SLA (IX + {0:X})", disp));
                                    H = Sla_R(disp);
                                    PokeByte(offset, H);
                                    break;

                                case 0x25: //LD L, SLA (IX+d)
                                    // Log(string.Format("LD L, SLA (IX + {0:X})", disp));
                                    L = Sla_R(disp);
                                    PokeByte(offset, L);
                                    break;

                                case 0x26:  //SLA (IX + d)
                                    // Log(string.Format("SLA (IX + {0:X})", disp));
                                    PokeByte(offset, Sla_R(disp));
                                    break;

                                case 0x27: //LD A, SLA (IX+d)
                                    // Log(string.Format("LD A, SLA (IX + {0:X})", disp));
                                    A = Sla_R(disp);
                                    PokeByte(offset, A);
                                    break;

                                case 0x28: //LD B, SRA (IX+d)
                                    // Log(string.Format("LD B, SRA (IX + {0:X})", disp));
                                    B = Sra_R(disp);
                                    PokeByte(offset, B);
                                    break;

                                case 0x29: //LD C, SRA (IX+d)
                                    // Log(string.Format("LD C, SRA (IX + {0:X})", disp));
                                    C = Sra_R(disp);
                                    PokeByte(offset, C);
                                    break;

                                case 0x2A: //LD D, SRA (IX+d)
                                    // Log(string.Format("LD D, SRA (IX + {0:X})", disp));
                                    D = Sra_R(disp);
                                    PokeByte(offset, D);
                                    break;

                                case 0x2B: //LD E, SRA (IX+d)
                                    // Log(string.Format("LD E, SRA (IX + {0:X})", disp));
                                    E = Sra_R(disp);
                                    PokeByte(offset, E);
                                    break;

                                case 0x2C: //LD H, SRA (IX+d)
                                    // Log(string.Format("LD H, SRA (IX + {0:X})", disp));
                                    H = Sra_R(disp);
                                    PokeByte(offset, H);
                                    break;

                                case 0x2D: //LD L, SRA (IX+d)
                                    // Log(string.Format("LD L, SRA (IX + {0:X})", disp));
                                    L = Sra_R(disp);
                                    PokeByte(offset, L);
                                    break;

                                case 0x2E:  //SRA (IX + d)
                                    // Log(string.Format("SRA (IX + {0:X})", disp));
                                    PokeByte(offset, Sra_R(disp));
                                    break;

                                case 0x2F: //LD A, SRA (IX+d)
                                    // Log(string.Format("LD A, SRA (IX + {0:X})", disp));
                                    A = Sra_R(disp);
                                    PokeByte(offset, A);
                                    break;

                                case 0x30: //LD B, SLL (IX+d)
                                    // Log(string.Format("LD B, SLL (IX + {0:X})", disp));
                                    B = Sll_R(disp);
                                    PokeByte(offset, B);
                                    break;

                                case 0x31: //LD C, SLL (IX+d)
                                    // Log(string.Format("LD C, SLL (IX + {0:X})", disp));
                                    C = Sll_R(disp);
                                    PokeByte(offset, C);
                                    break;

                                case 0x32: //LD D, SLL (IX+d)
                                    // Log(string.Format("LD D, SLL (IX + {0:X})", disp));
                                    D = Sll_R(disp);
                                    PokeByte(offset, D);
                                    break;

                                case 0x33: //LD E, SLL (IX+d)
                                    // Log(string.Format("LD E, SLL (IX + {0:X})", disp));
                                    E = Sll_R(disp);
                                    PokeByte(offset, E);
                                    break;

                                case 0x34: //LD H, SLL (IX+d)
                                    // Log(string.Format("LD H, SLL (IX + {0:X})", disp));
                                    H = Sll_R(disp);
                                    PokeByte(offset, H);
                                    break;

                                case 0x35: //LD L, SLL (IX+d)
                                    // Log(string.Format("LD L, SLL (IX + {0:X})", disp));
                                    L = Sll_R(disp);
                                    PokeByte(offset, L);
                                    break;

                                case 0x36:  //SLL (IX + d)
                                    // Log(string.Format("SLL (IX + {0:X})", disp));
                                    PokeByte(offset, Sll_R(disp));
                                    break;

                                case 0x37: //LD A, SLL (IX+d)
                                    // Log(string.Format("LD A, SLL (IX + {0:X})", disp));
                                    A = Sll_R(disp);
                                    PokeByte(offset, A);
                                    break;

                                case 0x38: //LD B, SRL (IX+d)
                                    // Log(string.Format("LD B, SRL (IX + {0:X})", disp));
                                    B = Srl_R(disp);
                                    PokeByte(offset, B);
                                    break;

                                case 0x39: //LD C, SRL (IX+d)
                                    // Log(string.Format("LD C, SRL (IX + {0:X})", disp));
                                    C = Srl_R(disp);
                                    PokeByte(offset, C);
                                    break;

                                case 0x3A: //LD D, SRL (IX+d)
                                    // Log(string.Format("LD D, SRL (IX + {0:X})", disp));
                                    D = Srl_R(disp);
                                    PokeByte(offset, D);
                                    break;

                                case 0x3B: //LD E, SRL (IX+d)
                                    // Log(string.Format("LD E, SRL (IX + {0:X})", disp));
                                    E = Srl_R(disp);
                                    PokeByte(offset, E);
                                    break;

                                case 0x3C: //LD H, SRL (IX+d)
                                    // Log(string.Format("LD H, SRL (IX + {0:X})", disp));
                                    H = Srl_R(disp);
                                    PokeByte(offset, H);
                                    break;

                                case 0x3D: //LD L, SRL (IX+d)
                                    // Log(string.Format("LD L, SRL (IX + {0:X})", disp));
                                    L = Srl_R(disp);
                                    PokeByte(offset, L);
                                    break;

                                case 0x3E:  //SRL (IX + d)
                                    // Log(string.Format("SRL (IX + {0:X})", disp));
                                    PokeByte(offset, Srl_R(disp));
                                    break;

                                case 0x3F: //LD A, SRL (IX+d)
                                    // Log(string.Format("LD A, SRL (IX + {0:X})", disp));
                                    A = Srl_R(disp);
                                    PokeByte(offset, A);
                                    break;

                                case 0x40:  //BIT 0, (IX + d)
                                case 0x41:  //BIT 0, (IX + d)
                                case 0x42:  //BIT 0, (IX + d)
                                case 0x43:  //BIT 0, (IX + d)
                                case 0x44:  //BIT 0, (IX + d)
                                case 0x45:  //BIT 0, (IX + d)
                                case 0x46:  //BIT 0, (IX + d)
                                case 0x47:  //BIT 0, (IX + d)
                                    // Log(string.Format("BIT 0, (IX + {0:X})", disp));
                                    Bit_R(0, disp);
                                    SetF3((MemPtr & MEMPTR_11) != 0);
                                    SetF5((MemPtr & MEMPTR_13) != 0);
                                    break;

                                case 0x48:  //BIT 1, (IX + d)
                                case 0x49:  //BIT 1, (IX + d)
                                case 0x4A:  //BIT 1, (IX + d)
                                case 0x4B:  //BIT 1, (IX + d)
                                case 0x4C:  //BIT 1, (IX + d)
                                case 0x4D:  //BIT 1, (IX + d)
                                case 0x4E:  //BIT 1, (IX + d)
                                case 0x4F:  //BIT 1, (IX + d)
                                    // Log(string.Format("BIT 1, (IX + {0:X})", disp));
                                    Bit_R(1, disp);
                                    SetF3((MemPtr & MEMPTR_11) != 0);
                                    SetF5((MemPtr & MEMPTR_13) != 0);
                                    break;

                                case 0x50:  //BIT 2, (IX + d)
                                case 0x51:  //BIT 2, (IX + d)
                                case 0x52:  //BIT 2, (IX + d)
                                case 0x53:  //BIT 2, (IX + d)
                                case 0x54:  //BIT 2, (IX + d)
                                case 0x55:  //BIT 2, (IX + d)
                                case 0x56:  //BIT 2, (IX + d)
                                case 0x57:  //BIT 2, (IX + d)
                                    // Log(string.Format("BIT 2, (IX + {0:X})", disp));
                                    Bit_R(2, disp);
                                    SetF3((MemPtr & MEMPTR_11) != 0);
                                    SetF5((MemPtr & MEMPTR_13) != 0);
                                    break;

                                case 0x58:  //BIT 3, (IX + d)
                                case 0x59:  //BIT 3, (IX + d)
                                case 0x5A:  //BIT 3, (IX + d)
                                case 0x5B:  //BIT 3, (IX + d)
                                case 0x5C:  //BIT 3, (IX + d)
                                case 0x5D:  //BIT 3, (IX + d)
                                case 0x5E:  //BIT 3, (IX + d)
                                case 0x5F:  //BIT 3, (IX + d)
                                    // Log(string.Format("BIT 3, (IX + {0:X})", disp));
                                    Bit_R(3, disp);
                                    SetF3((MemPtr & MEMPTR_11) != 0);
                                    SetF5((MemPtr & MEMPTR_13) != 0);
                                    break;

                                case 0x60:  //BIT 4, (IX + d)
                                case 0x61:  //BIT 4, (IX + d)
                                case 0x62:  //BIT 4, (IX + d)
                                case 0x63:  //BIT 4, (IX + d)
                                case 0x64:  //BIT 4, (IX + d)
                                case 0x65:  //BIT 4, (IX + d)
                                case 0x66:  //BIT 4, (IX + d)
                                case 0x67:  //BIT 4, (IX + d)
                                    // Log(string.Format("BIT 4, (IX + {0:X})", disp));
                                    Bit_R(4, disp);
                                    SetF3((MemPtr & MEMPTR_11) != 0);
                                    SetF5((MemPtr & MEMPTR_13) != 0);
                                    break;

                                case 0x68:  //BIT 5, (IX + d)
                                case 0x69:  //BIT 5, (IX + d)
                                case 0x6A:  //BIT 5, (IX + d)
                                case 0x6B:  //BIT 5, (IX + d)
                                case 0x6C:  //BIT 5, (IX + d)
                                case 0x6D:  //BIT 5, (IX + d)
                                case 0x6E:  //BIT 5, (IX + d)
                                case 0x6F:  //BIT 5, (IX + d)
                                    // Log(string.Format("BIT 5, (IX + {0:X})", disp));
                                    Bit_R(5, disp);
                                    SetF3((MemPtr & MEMPTR_11) != 0);
                                    SetF5((MemPtr & MEMPTR_13) != 0);
                                    break;

                                case 0x70://BIT 6, (IX + d)
                                case 0x71://BIT 6, (IX + d)
                                case 0x72://BIT 6, (IX + d)
                                case 0x73://BIT 6, (IX + d)
                                case 0x74://BIT 6, (IX + d)
                                case 0x75://BIT 6, (IX + d)
                                case 0x76://BIT 6, (IX + d)
                                case 0x77:  //BIT 6, (IX + d)
                                    // Log(string.Format("BIT 6, (IX + {0:X})", disp));
                                    Bit_R(6, disp);
                                    SetF3((MemPtr & MEMPTR_11) != 0);
                                    SetF5((MemPtr & MEMPTR_13) != 0);
                                    break;

                                case 0x78:  //BIT 7, (IX + d)
                                case 0x79:  //BIT 7, (IX + d)
                                case 0x7A:  //BIT 7, (IX + d)
                                case 0x7B:  //BIT 7, (IX + d)
                                case 0x7C:  //BIT 7, (IX + d)
                                case 0x7D:  //BIT 7, (IX + d)
                                case 0x7E:  //BIT 7, (IX + d)
                                case 0x7F:  //BIT 7, (IX + d)
                                    // Log(string.Format("BIT 7, (IX + {0:X})", disp));
                                    Bit_R(7, disp);
                                    SetF3((MemPtr & MEMPTR_11) != 0);
                                    SetF5((MemPtr & MEMPTR_13) != 0);
                                    break;

                                case 0x80: //LD B, RES 0, (IX+d)
                                    // Log(string.Format("LD B, RES 0, (IX + {0:X})", disp));
                                    B = Res_R(0, disp);
                                    PokeByte(offset, B);
                                    break;

                                case 0x81: //LD C, RES 0, (IX+d)
                                    // Log(string.Format("LD C, RES 0, (IX + {0:X})", disp));
                                    C = Res_R(0, disp);
                                    PokeByte(offset, C);
                                    break;

                                case 0x82: //LD D, RES 0, (IX+d)
                                    // Log(string.Format("LD D, RES 0, (IX + {0:X})", disp));
                                    D = Res_R(0, disp);
                                    PokeByte(offset, D);
                                    break;

                                case 0x83: //LD E, RES 0, (IX+d)
                                    // Log(string.Format("LD E, RES 0, (IX + {0:X})", disp));
                                    E = Res_R(0, disp);
                                    PokeByte(offset, E);
                                    break;

                                case 0x84: //LD H, RES 0, (IX+d)
                                    // Log(string.Format("LD H, RES 0, (IX + {0:X})", disp));
                                    H = Res_R(0, disp);
                                    PokeByte(offset, H);
                                    break;

                                case 0x85: //LD L, RES 0, (IX+d)
                                    // Log(string.Format("LD L, RES 0, (IX + {0:X})", disp));
                                    L = Res_R(0, disp);
                                    PokeByte(offset, L);
                                    break;

                                case 0x86:  //RES 0, (IX + d)
                                    // Log(string.Format("RES 0, (IX + {0:X})", disp));
                                    PokeByte(offset, Res_R(0, disp));
                                    break;

                                case 0x87: //LD A, RES 0, (IX+d)
                                    // Log(string.Format("LD A, RES 0, (IX + {0:X})", disp));
                                    A = Res_R(0, disp);
                                    PokeByte(offset, A);
                                    break;

                                case 0x88: //LD B, RES 1, (IX+d)
                                    // Log(string.Format("LD B, RES 1, (IX + {0:X})", disp));
                                    B = Res_R(1, disp);
                                    PokeByte(offset, B);
                                    break;

                                case 0x89: //LD C, RES 1, (IX+d)
                                    // Log(string.Format("LD C, RES 1, (IX + {0:X})", disp));
                                    C = Res_R(1, disp);
                                    PokeByte(offset, C);
                                    break;

                                case 0x8A: //LD D, RES 1, (IX+d)
                                    // Log(string.Format("LD D, RES 1, (IX + {0:X})", disp));
                                    D = Res_R(1, disp);
                                    PokeByte(offset, D);
                                    break;

                                case 0x8B: //LD E, RES 1, (IX+d)
                                    // Log(string.Format("LD E, RES 1, (IX + {0:X})", disp));
                                    E = Res_R(1, disp);
                                    PokeByte(offset, E);
                                    break;

                                case 0x8C: //LD H, RES 1, (IX+d)
                                    // Log(string.Format("LD H, RES 1, (IX + {0:X})", disp));
                                    H = Res_R(1, disp);
                                    PokeByte(offset, H);
                                    break;

                                case 0x8D: //LD L, RES 1, (IX+d)
                                    // Log(string.Format("LD L, RES 1, (IX + {0:X})", disp));
                                    L = Res_R(1, disp);
                                    PokeByte(offset, L);
                                    break;

                                case 0x8E:  //RES 1, (IX + d)
                                    // Log(string.Format("RES 1, (IX + {0:X})", disp));
                                    PokeByte(offset, Res_R(1, disp));
                                    break;

                                case 0x8F: //LD A, RES 1, (IX+d)
                                    // Log(string.Format("LD A, RES 1, (IX + {0:X})", disp));
                                    A = Res_R(1, disp);
                                    PokeByte(offset, A);
                                    break;

                                case 0x90: //LD B, RES 2, (IX+d)
                                    // Log(string.Format("LD B, RES 2, (IX + {0:X})", disp));
                                    B = Res_R(2, disp);
                                    PokeByte(offset, B);
                                    break;

                                case 0x91: //LD C, RES 2, (IX+d)
                                    // Log(string.Format("LD C, RES 2, (IX + {0:X})", disp));
                                    C = Res_R(2, disp);
                                    PokeByte(offset, C);
                                    break;

                                case 0x92: //LD D, RES 2, (IX+d)
                                    // Log(string.Format("LD D, RES 2, (IX + {0:X})", disp));
                                    D = Res_R(2, disp);
                                    PokeByte(offset, D);
                                    break;

                                case 0x93: //LD E, RES 2, (IX+d)
                                    // Log(string.Format("LD E, RES 2, (IX + {0:X})", disp));
                                    E = Res_R(2, disp);
                                    PokeByte(offset, E);
                                    break;

                                case 0x94: //LD H, RES 2, (IX+d)
                                    // Log(string.Format("LD H, RES 2, (IX + {0:X})", disp));
                                    H = Res_R(2, disp);
                                    PokeByte(offset, H);
                                    break;

                                case 0x95: //LD L, RES 2, (IX+d)
                                    // Log(string.Format("LD L, RES 2, (IX + {0:X})", disp));
                                    L = Res_R(2, disp);
                                    PokeByte(offset, L);
                                    break;

                                case 0x96:  //RES 2, (IX + d)
                                    // Log(string.Format("RES 2, (IX + {0:X})", disp));
                                    PokeByte(offset, Res_R(2, disp));
                                    break;

                                case 0x97: //LD A, RES 2, (IX+d)
                                    // Log(string.Format("LD A, RES 2, (IX + {0:X})", disp));
                                    A = Res_R(2, disp);
                                    PokeByte(offset, A);
                                    break;

                                case 0x98: //LD B, RES 3, (IX+d)
                                    // Log(string.Format("LD B, RES 3, (IX + {0:X})", disp));
                                    B = Res_R(3, disp);
                                    PokeByte(offset, B);
                                    break;

                                case 0x99: //LD C, RES 3, (IX+d)
                                    // Log(string.Format("LD C, RES 3, (IX + {0:X})", disp));
                                    C = Res_R(3, disp);
                                    PokeByte(offset, C);
                                    break;

                                case 0x9A: //LD D, RES 3, (IX+d)
                                    // Log(string.Format("LD D, RES 3, (IX + {0:X})", disp));
                                    D = Res_R(3, disp);
                                    PokeByte(offset, D);
                                    break;

                                case 0x9B: //LD E, RES 3, (IX+d)
                                    // Log(string.Format("LD E, RES 3, (IX + {0:X})", disp));
                                    E = Res_R(3, disp);
                                    PokeByte(offset, E);
                                    break;

                                case 0x9C: //LD H, RES 3, (IX+d)
                                    // Log(string.Format("LD H, RES 3, (IX + {0:X})", disp));
                                    H = Res_R(3, disp);
                                    PokeByte(offset, H);
                                    break;

                                case 0x9D: //LD L, RES 3, (IX+d)
                                    // Log(string.Format("LD L, RES 3, (IX + {0:X})", disp));
                                    L = Res_R(3, disp);
                                    PokeByte(offset, L);
                                    break;

                                case 0x9E:  //RES 3, (IX + d)
                                    // Log(string.Format("RES 3, (IX + {0:X})", disp));
                                    PokeByte(offset, Res_R(3, disp));
                                    break;

                                case 0x9F: //LD A, RES 3, (IX+d)
                                    // Log(string.Format("LD A, RES 3, (IX + {0:X})", disp));
                                    A = Res_R(3, disp);
                                    PokeByte(offset, A);
                                    break;

                                case 0xA0: //LD B, RES 4, (IX+d)
                                    // Log(string.Format("LD B, RES 4, (IX + {0:X})", disp));
                                    B = Res_R(4, disp);
                                    PokeByte(offset, B);
                                    break;

                                case 0xA1: //LD C, RES 4, (IX+d)
                                    // Log(string.Format("LD C, RES 4, (IX + {0:X})", disp));
                                    C = Res_R(4, disp);
                                    PokeByte(offset, C);
                                    break;

                                case 0xA2: //LD D, RES 4, (IX+d)
                                    // Log(string.Format("LD D, RES 4, (IX + {0:X})", disp));
                                    D = Res_R(4, disp);
                                    PokeByte(offset, D);
                                    break;

                                case 0xA3: //LD E, RES 4, (IX+d)
                                    // Log(string.Format("LD E, RES 4, (IX + {0:X})", disp));
                                    E = Res_R(4, disp);
                                    PokeByte(offset, E);
                                    break;

                                case 0xA4: //LD H, RES 4, (IX+d)
                                    // Log(string.Format("LD H, RES 4, (IX + {0:X})", disp));
                                    H = Res_R(4, disp);
                                    PokeByte(offset, H);
                                    break;

                                case 0xA5: //LD L, RES 4, (IX+d)
                                    // Log(string.Format("LD L, RES 4, (IX + {0:X})", disp));
                                    L = Res_R(4, disp);
                                    PokeByte(offset, L);
                                    break;

                                case 0xA6:  //RES 4, (IX + d)
                                    // Log(string.Format("RES 4, (IX + {0:X})", disp));
                                    PokeByte(offset, Res_R(4, disp));
                                    break;

                                case 0xA7: //LD A, RES 4, (IX+d)
                                    // Log(string.Format("LD A, RES 4, (IX + {0:X})", disp));
                                    A = Res_R(4, disp);
                                    PokeByte(offset, A);
                                    break;

                                case 0xA8: //LD B, RES 5, (IX+d)
                                    // Log(string.Format("LD B, RES 5, (IX + {0:X})", disp));
                                    B = Res_R(5, disp);
                                    PokeByte(offset, B);
                                    break;

                                case 0xA9: //LD C, RES 5, (IX+d)
                                    // Log(string.Format("LD C, RES 5, (IX + {0:X})", disp));
                                    C = Res_R(5, disp);
                                    PokeByte(offset, C);
                                    break;

                                case 0xAA: //LD D, RES 5, (IX+d)
                                    // Log(string.Format("LD D, RES 5, (IX + {0:X})", disp));
                                    D = Res_R(5, disp);
                                    PokeByte(offset, D);
                                    break;

                                case 0xAB: //LD E, RES 5, (IX+d)
                                    // Log(string.Format("LD E, RES 5, (IX + {0:X})", disp));
                                    E = Res_R(5, disp);
                                    PokeByte(offset, E);
                                    break;

                                case 0xAC: //LD H, RES 5, (IX+d)
                                    // Log(string.Format("LD H, RES 5, (IX + {0:X})", disp));
                                    H = Res_R(5, disp);
                                    PokeByte(offset, H);
                                    break;

                                case 0xAD: //LD L, RES 5, (IX+d)
                                    // Log(string.Format("LD L, RES 5, (IX + {0:X})", disp));
                                    L = Res_R(5, disp);
                                    PokeByte(offset, L);
                                    break;

                                case 0xAE:  //RES 5, (IX + d)
                                    // Log(string.Format("RES 5, (IX + {0:X})", disp));
                                    PokeByte(offset, Res_R(5, disp));
                                    break;

                                case 0xAF: //LD A, RES 5, (IX+d)
                                    // Log(string.Format("LD A, RES 5, (IX + {0:X})", disp));
                                    A = Res_R(5, disp);
                                    PokeByte(offset, A);
                                    break;

                                case 0xB0: //LD B, RES 6, (IX+d)
                                    // Log(string.Format("LD B, RES 6, (IX + {0:X})", disp));
                                    B = Res_R(6, disp);
                                    PokeByte(offset, B);
                                    break;

                                case 0xB1: //LD C, RES 6, (IX+d)
                                    // Log(string.Format("LD C, RES 6, (IX + {0:X})", disp));
                                    C = Res_R(6, disp);
                                    PokeByte(offset, C);
                                    break;

                                case 0xB2: //LD D, RES 6, (IX+d)
                                    // Log(string.Format("LD D, RES 6, (IX + {0:X})", disp));
                                    D = Res_R(5, disp);
                                    PokeByte(offset, D);
                                    break;

                                case 0xB3: //LD E, RES 6, (IX+d)
                                    // Log(string.Format("LD E, RES 6, (IX + {0:X})", disp));
                                    E = Res_R(6, disp);
                                    PokeByte(offset, E);
                                    break;

                                case 0xB4: //LD H, RES 5, (IX+d)
                                    // Log(string.Format("LD H, RES 6, (IX + {0:X})", disp));
                                    H = Res_R(6, disp);
                                    PokeByte(offset, H);
                                    break;

                                case 0xB5: //LD L, RES 5, (IX+d)
                                    // Log(string.Format("LD L, RES 6, (IX + {0:X})", disp));
                                    L = Res_R(6, disp);
                                    PokeByte(offset, L);
                                    break;

                                case 0xB6:  //RES 6, (IX + d)
                                    // Log(string.Format("RES 6, (IX + {0:X})", disp));
                                    PokeByte(offset, Res_R(6, disp));
                                    break;

                                case 0xB7: //LD A, RES 5, (IX+d)
                                    // Log(string.Format("LD A, RES 6, (IX + {0:X})", disp));
                                    A = Res_R(6, disp);
                                    PokeByte(offset, A);
                                    break;

                                case 0xB8: //LD B, RES 7, (IX+d)
                                    // Log(string.Format("LD B, RES 7, (IX + {0:X})", disp));
                                    B = Res_R(7, disp);
                                    PokeByte(offset, B);
                                    break;

                                case 0xB9: //LD C, RES 7, (IX+d)
                                    // Log(string.Format("LD C, RES 7, (IX + {0:X})", disp));
                                    C = Res_R(7, disp);
                                    PokeByte(offset, C);
                                    break;

                                case 0xBA: //LD D, RES 7, (IX+d)
                                    // Log(string.Format("LD D, RES 7, (IX + {0:X})", disp));
                                    D = Res_R(7, disp);
                                    PokeByte(offset, D);
                                    break;

                                case 0xBB: //LD E, RES 7, (IX+d)
                                    // Log(string.Format("LD E, RES 7, (IX + {0:X})", disp));
                                    E = Res_R(7, disp);
                                    PokeByte(offset, E);
                                    break;

                                case 0xBC: //LD H, RES 7, (IX+d)
                                    // Log(string.Format("LD H, RES 7, (IX + {0:X})", disp));
                                    H = Res_R(7, disp);
                                    PokeByte(offset, H);
                                    break;

                                case 0xBD: //LD L, RES 7, (IX+d)
                                    // Log(string.Format("LD L, RES 7, (IX + {0:X})", disp));
                                    L = Res_R(7, disp);
                                    PokeByte(offset, L);
                                    break;

                                case 0xBE:  //RES 7, (IX + d)
                                    // Log(string.Format("RES 7, (IX + {0:X})", disp));
                                    PokeByte(offset, Res_R(7, disp));
                                    break;

                                case 0xBF: //LD A, RES 7, (IX+d)
                                    // Log(string.Format("LD A, RES 7, (IX + {0:X})", disp));
                                    A = Res_R(7, disp);
                                    PokeByte(offset, A);
                                    break;

                                case 0xC0: //LD B, SET 0, (IX+d)
                                    // Log(string.Format("LD B, SET 0, (IX + {0:X})", disp));
                                    B = Set_R(0, disp);
                                    PokeByte(offset, B);
                                    break;

                                case 0xC1: //LD C, SET 0, (IX+d)
                                    // Log(string.Format("LD C, SET 0, (IX + {0:X})", disp));
                                    C = Set_R(0, disp);
                                    PokeByte(offset, C);
                                    break;

                                case 0xC2: //LD D, SET 0, (IX+d)
                                    // Log(string.Format("LD D, SET 0, (IX + {0:X})", disp));
                                    D = Set_R(0, disp);
                                    PokeByte(offset, D);
                                    break;

                                case 0xC3: //LD E, SET 0, (IX+d)
                                    // Log(string.Format("LD E, SET 0, (IX + {0:X})", disp));
                                    E = Set_R(0, disp);
                                    PokeByte(offset, E);
                                    break;

                                case 0xC4: //LD H, SET 0, (IX+d)
                                    // Log(string.Format("LD H, SET 0, (IX + {0:X})", disp));
                                    H = Set_R(0, disp);
                                    PokeByte(offset, H);
                                    break;

                                case 0xC5: //LD L, SET 0, (IX+d)
                                    // Log(string.Format("LD L, SET 0, (IX + {0:X})", disp));
                                    L = Set_R(0, disp);
                                    PokeByte(offset, L);
                                    break;

                                case 0xC6:  //SET 0, (IX + d)
                                    // Log(string.Format("SET 0, (IX + {0:X})", disp));
                                    PokeByte(offset, Set_R(0, disp));
                                    break;

                                case 0xC7: //LD A, SET 0, (IX+d)
                                    // Log(string.Format("LD A, SET 0, (IX + {0:X})", disp));
                                    A = Set_R(0, disp);
                                    PokeByte(offset, A);
                                    break;

                                case 0xC8: //LD B, SET 1, (IX+d)
                                    // Log(string.Format("LD B, SET 1, (IX + {0:X})", disp));
                                    B = Set_R(1, disp);
                                    PokeByte(offset, B);
                                    break;

                                case 0xC9: //LD C, SET 0, (IX+d)
                                    // Log(string.Format("LD C, SET 1, (IX + {0:X})", disp));
                                    C = Set_R(1, disp);
                                    PokeByte(offset, C);
                                    break;

                                case 0xCA: //LD D, SET 1, (IX+d)
                                    // Log(string.Format("LD D, SET 1, (IX + {0:X})", disp));
                                    D = Set_R(1, disp);
                                    PokeByte(offset, D);
                                    break;

                                case 0xCB: //LD E, SET 1, (IX+d)
                                    // Log(string.Format("LD E, SET 1, (IX + {0:X})", disp));
                                    E = Set_R(1, disp);
                                    PokeByte(offset, E);
                                    break;

                                case 0xCC: //LD H, SET 1, (IX+d)
                                    // Log(string.Format("LD H, SET 1, (IX + {0:X})", disp));
                                    H = Set_R(1, disp);
                                    PokeByte(offset, H);
                                    break;

                                case 0xCD: //LD L, SET 1, (IX+d)
                                    // Log(string.Format("LD L, SET 1, (IX + {0:X})", disp));
                                    L = Set_R(1, disp);
                                    PokeByte(offset, L);
                                    break;

                                case 0xCE:  //SET 1, (IX + d)
                                    // Log(string.Format("SET 1, (IX + {0:X})", disp));
                                    PokeByte(offset, Set_R(1, disp));
                                    break;

                                case 0xCF: //LD A, SET 1, (IX+d)
                                    // Log(string.Format("LD A, SET 1, (IX + {0:X})", disp));
                                    A = Set_R(1, disp);
                                    PokeByte(offset, A);
                                    break;

                                case 0xD0: //LD B, SET 2, (IX+d)
                                    // Log(string.Format("LD B, SET 2, (IX + {0:X})", disp));
                                    B = Set_R(2, disp);
                                    PokeByte(offset, B);
                                    break;

                                case 0xD1: //LD C, SET 2, (IX+d)
                                    // Log(string.Format("LD C, SET 2, (IX + {0:X})", disp));
                                    C = Set_R(2, disp);
                                    PokeByte(offset, C);
                                    break;

                                case 0xD2: //LD D, SET 2, (IX+d)
                                    // Log(string.Format("LD D, SET 2, (IX + {0:X})", disp));
                                    D = Set_R(2, disp);
                                    PokeByte(offset, D);
                                    break;

                                case 0xD3: //LD E, SET 2, (IX+d)
                                    // Log(string.Format("LD E, SET 2, (IX + {0:X})", disp));
                                    E = Set_R(2, disp);
                                    PokeByte(offset, E);
                                    break;

                                case 0xD4: //LD H, SET 21, (IX+d)
                                    // Log(string.Format("LD H, SET 2, (IX + {0:X})", disp));
                                    H = Set_R(2, disp);
                                    PokeByte(offset, H);
                                    break;

                                case 0xD5: //LD L, SET 2, (IX+d)
                                    // Log(string.Format("LD L, SET 2, (IX + {0:X})", disp));
                                    L = Set_R(2, disp);
                                    PokeByte(offset, L);
                                    break;

                                case 0xD6:  //SET 2, (IX + d)
                                    // Log(string.Format("SET 2, (IX + {0:X})", disp));
                                    PokeByte(offset, Set_R(2, disp));
                                    break;

                                case 0xD7: //LD A, SET 2, (IX+d)
                                    // Log(string.Format("LD A, SET 2, (IX + {0:X})", disp));
                                    A = Set_R(2, disp);
                                    PokeByte(offset, A);
                                    break;

                                case 0xD8: //LD B, SET 3, (IX+d)
                                    // Log(string.Format("LD B, SET 3, (IX + {0:X})", disp));
                                    B = Set_R(3, disp);
                                    PokeByte(offset, B);
                                    break;

                                case 0xD9: //LD C, SET 3, (IX+d)
                                    // Log(string.Format("LD C, SET 3, (IX + {0:X})", disp));
                                    C = Set_R(3, disp);
                                    PokeByte(offset, C);
                                    break;

                                case 0xDA: //LD D, SET 3, (IX+d)
                                    // Log(string.Format("LD D, SET 3, (IX + {0:X})", disp));
                                    D = Set_R(3, disp);
                                    PokeByte(offset, D);
                                    break;

                                case 0xDB: //LD E, SET 3, (IX+d)
                                    // Log(string.Format("LD E, SET 3, (IX + {0:X})", disp));
                                    E = Set_R(3, disp);
                                    PokeByte(offset, E);
                                    break;

                                case 0xDC: //LD H, SET 21, (IX+d)
                                    // Log(string.Format("LD H, SET 3, (IX + {0:X})", disp));
                                    H = Set_R(3, disp);
                                    PokeByte(offset, H);
                                    break;

                                case 0xDD: //LD L, SET 3, (IX+d)
                                    // Log(string.Format("LD L, SET 3, (IX + {0:X})", disp));
                                    L = Set_R(3, disp);
                                    PokeByte(offset, L);
                                    break;

                                case 0xDE:  //SET 3, (IX + d)
                                    // Log(string.Format("SET 3, (IX + {0:X})", disp));
                                    PokeByte(offset, Set_R(3, disp));
                                    break;

                                case 0xDF: //LD A, SET 3, (IX+d)
                                    // Log(string.Format("LD A, SET 3, (IX + {0:X})", disp));
                                    A = Set_R(3, disp);
                                    PokeByte(offset, A);
                                    break;

                                case 0xE0: //LD B, SET 4, (IX+d)
                                    // Log(string.Format("LD B, SET 4, (IX + {0:X})", disp));
                                    B = Set_R(4, disp);
                                    PokeByte(offset, B);
                                    break;

                                case 0xE1: //LD C, SET 4, (IX+d)
                                    // Log(string.Format("LD C, SET 4, (IX + {0:X})", disp));
                                    C = Set_R(4, disp);
                                    PokeByte(offset, C);
                                    break;

                                case 0xE2: //LD D, SET 4, (IX+d)
                                    // Log(string.Format("LD D, SET 4, (IX + {0:X})", disp));
                                    D = Set_R(4, disp);
                                    PokeByte(offset, D);
                                    break;

                                case 0xE3: //LD E, SET 4, (IX+d)
                                    // Log(string.Format("LD E, SET 4, (IX + {0:X})", disp));
                                    E = Set_R(4, disp);
                                    PokeByte(offset, E);
                                    break;

                                case 0xE4: //LD H, SET 4, (IX+d)
                                    // Log(string.Format("LD H, SET 4, (IX + {0:X})", disp));
                                    H = Set_R(4, disp);
                                    PokeByte(offset, H);
                                    break;

                                case 0xE5: //LD L, SET 3, (IX+d)
                                    // Log(string.Format("LD L, SET 4, (IX + {0:X})", disp));
                                    L = Set_R(4, disp);
                                    PokeByte(offset, L);
                                    break;

                                case 0xE6:  //SET 4, (IX + d)
                                    // Log(string.Format("SET 4, (IX + {0:X})", disp));
                                    PokeByte(offset, Set_R(4, disp));
                                    break;

                                case 0xE7: //LD A, SET 4, (IX+d)
                                    // Log(string.Format("LD A, SET 4, (IX + {0:X})", disp));
                                    A = Set_R(4, disp);
                                    PokeByte(offset, A);
                                    break;

                                case 0xE8: //LD B, SET 5, (IX+d)
                                    // Log(string.Format("LD B, SET 5, (IX + {0:X})", disp));
                                    B = Set_R(5, disp);
                                    PokeByte(offset, B);
                                    break;

                                case 0xE9: //LD C, SET 5, (IX+d)
                                    // Log(string.Format("LD C, SET 5, (IX + {0:X})", disp));
                                    C = Set_R(5, disp);
                                    PokeByte(offset, C);
                                    break;

                                case 0xEA: //LD D, SET 5, (IX+d)
                                    // Log(string.Format("LD D, SET 5, (IX + {0:X})", disp));
                                    D = Set_R(5, disp);
                                    PokeByte(offset, D);
                                    break;

                                case 0xEB: //LD E, SET 5, (IX+d)
                                    // Log(string.Format("LD E, SET 5, (IX + {0:X})", disp));
                                    E = Set_R(5, disp);
                                    PokeByte(offset, E);
                                    break;

                                case 0xEC: //LD H, SET 5, (IX+d)
                                    // Log(string.Format("LD H, SET 5, (IX + {0:X})", disp));
                                    H = Set_R(5, disp);
                                    PokeByte(offset, H);
                                    break;

                                case 0xED: //LD L, SET 5, (IX+d)
                                    // Log(string.Format("LD L, SET 5, (IX + {0:X})", disp));
                                    L = Set_R(5, disp);
                                    PokeByte(offset, L);
                                    break;

                                case 0xEE:  //SET 5, (IX + d)
                                    // Log(string.Format("SET 5, (IX + {0:X})", disp));
                                    PokeByte(offset, Set_R(5, disp));
                                    break;

                                case 0xEF: //LD A, SET 5, (IX+d)
                                    // Log(string.Format("LD A, SET 5, (IX + {0:X})", disp));
                                    A = Set_R(5, disp);
                                    PokeByte(offset, A);
                                    break;

                                case 0xF0: //LD B, SET 6, (IX+d)
                                    // Log(string.Format("LD B, SET 6, (IX + {0:X})", disp));
                                    B = Set_R(6, disp);
                                    PokeByte(offset, B);
                                    break;

                                case 0xF1: //LD C, SET 6, (IX+d)
                                    // Log(string.Format("LD C, SET 6, (IX + {0:X})", disp));
                                    C = Set_R(6, disp);
                                    PokeByte(offset, C);
                                    break;

                                case 0xF2: //LD D, SET 6, (IX+d)
                                    // Log(string.Format("LD D, SET 6, (IX + {0:X})", disp));
                                    D = Set_R(6, disp);
                                    PokeByte(offset, D);
                                    break;

                                case 0xF3: //LD E, SET 6, (IX+d)
                                    // Log(string.Format("LD E, SET 6, (IX + {0:X})", disp));
                                    E = Set_R(6, disp);
                                    PokeByte(offset, E);
                                    break;

                                case 0xF4: //LD H, SET 6, (IX+d)
                                    // Log(string.Format("LD H, SET 6, (IX + {0:X})", disp));
                                    H = Set_R(6, disp);
                                    PokeByte(offset, H);
                                    break;

                                case 0xF5: //LD L, SET 6, (IX+d)
                                    // Log(string.Format("LD L, SET 6, (IX + {0:X})", disp));
                                    L = Set_R(6, disp);
                                    PokeByte(offset, L);
                                    break;

                                case 0xF6:  //SET 6, (IX + d)
                                    // Log(string.Format("SET 6, (IX + {0:X})", disp));
                                    PokeByte(offset, Set_R(6, disp));
                                    break;

                                case 0xF7: //LD A, SET 6, (IX+d)
                                    // Log(string.Format("LD A, SET 6, (IX + {0:X})", disp));
                                    A = Set_R(6, disp);
                                    PokeByte(offset, A);
                                    break;

                                case 0xF8: //LD B, SET 7, (IX+d)
                                    // Log(string.Format("LD B, SET 7, (IX + {0:X})", disp));
                                    B = Set_R(7, disp);
                                    PokeByte(offset, B);
                                    break;

                                case 0xF9: //LD C, SET 7, (IX+d)
                                    // Log(string.Format("LD C, SET 7, (IX + {0:X})", disp));
                                    C = Set_R(7, disp);
                                    PokeByte(offset, C);
                                    break;

                                case 0xFA: //LD D, SET 7, (IX+d)
                                    // Log(string.Format("LD D, SET 7, (IX + {0:X})", disp));
                                    D = Set_R(7, disp);
                                    PokeByte(offset, D);
                                    break;

                                case 0xFB: //LD E, SET 7, (IX+d)
                                    // Log(string.Format("LD E, SET 7, (IX + {0:X})", disp));
                                    E = Set_R(7, disp);
                                    PokeByte(offset, E);
                                    break;

                                case 0xFC: //LD H, SET 7, (IX+d)
                                    // Log(string.Format("LD H, SET 7, (IX + {0:X})", disp));
                                    H = Set_R(7, disp);
                                    PokeByte(offset, H);
                                    break;

                                case 0xFD: //LD L, SET 7, (IX+d)
                                    // Log(string.Format("LD L, SET 7, (IX + {0:X})", disp));
                                    L = Set_R(7, disp);
                                    PokeByte(offset, L);
                                    break;

                                case 0xFE:  //SET 7, (IX + d)
                                    // Log(string.Format("SET 7, (IX + {0:X})", disp));
                                    PokeByte(offset, Set_R(7, disp));
                                    break;

                                case 0xFF: //LD A, SET 7, (IX + D)
                                    A = Set_R(7, disp);
                                    PokeByte(offset, A);
                                    break;

                                default:
                                    String msg = "ERROR: Could not handle DDCB " + opcode.ToString();
                                    System.Windows.Forms.MessageBox.Show(msg, "Opcode handler",
                                                System.Windows.Forms.MessageBoxButtons.OKCancel, System.Windows.Forms.MessageBoxIcon.Error);
                                    break;
                            }
                            break;
#endregion

#region Pop/Push instructions
                        case 0xE1:  //POP IX
                            // Log("POP IX");
                            IX = PopStack();
                            break;

                        case 0xE5:  //PUSH IX
                            // Log("PUSH IX");
                            PushStack(IX);
                            break;
#endregion

#region Exchange instruction
                        case 0xE3:  //EX (SP), IX
                            // Log("EX (SP), IX");
                            //disp = IX;
                            addr = PeekWord(SP);
                            PokeByte((SP + 1) & 0xffff, IX >> 8);
                            PokeByte(SP, IX & 0xff);
                            IX = addr;
                            MemPtr = IX;
                            break;
#endregion

#region Jump instruction
                        case 0xE9:  //JP (IX)
                            // Log("JP (IX)");
                            PC = IX;
                            break;
#endregion

                        //  case 0xED:
                        //     MessageBox.Show("DD ED encountered!", "Opcode handler",
                        //                 MessageBoxButtons.OKCancel, MessageBoxIcon.Error);
                        //      break;

                        default:
                            //According to Sean's doc: http://z80.info/z80sean.txt
                            //If a DDxx or FDxx instruction is not listed, it should operate as
                            //without the DD or FD prefix, and the DD or FD prefix itself should
                            //operate as a NOP.
                            Execute();  //Try to excute it as a normal instruction then
                            break;
                    }
                    break;
#endregion

#region Opcodes with ED prefix
                case 0xED:
                    opcode = FetchInstruction();
                    if (opcode < 0x40) {
                        break;
                    } else
                        switch (opcode) {
                            case 0x40: //IN B, (C)
                                // Log("IN B, (C)");
                                B = In();
                                break;

                            case 0x41: //Out (C), B
                                // Log("OUT (C), B");
                                Out(BC, B);
                                break;

                            case 0x42:  //SBC HL, BC
                                // Log("SBC HL, BC");
                                //if (model == MachineModel._plus3)
                                //    totalTStates += 7;
                                //else
                                
                                MemPtr = HL + 1;
                                Sbc_RR(BC);
                                break;

                            case 0x43:  //LD (nn), BC
                                disp = PeekWord(PC);
                                // Log(String.Format("LD ({0:X}), BC", disp));
                                PokeWord(disp, BC);
                                MemPtr = disp + 1;
                                PC += 2;
                                break;

                            case 0x44:  //NEG
                                // Log("NEG");
                                temp = A;
                                A = 0;
                                Sub_R(temp); //Sets flags correctly for NEG as well!
                                break;

                            case 0x45:  //RETN
                                // Log("RET N");
                                PC = PopStack();
                                IFF1 = IFF2;
                                MemPtr = PC;
                                break;

                            case 0x46:  //IM0
                                // Log("IM 0");
                                interruptMode = 0;
                                break;

                            case 0x47:  //LD I, A
                                // Log("LD I, A");
                                I = A;
                                break;

                            case 0x48: //IN C, (C)
                                // Log("IN C, (C)");
                                C = In();
                                //tstates = 0;
                                break;

                            case 0x49: //Out (C), C
                                // Log("OUT (C), C");
                                Out(BC, C);
                                //tstates = 0;
                                break;

                            case 0x4A:  //ADC HL, BC
                                // Log("ADC HL, BC");
                                MemPtr = HL + 1;
                                Adc_RR(BC);
                                break;

                            case 0x4B:  //LD BC, (nn)
                                disp = PeekWord(PC);
                                // Log(String.Format("LD BC, ({0:X})", disp));
                                BC = PeekWord(disp);
                                MemPtr = disp + 1;
                                PC += 2;
                                break;

                            case 0x4C:  //NEG
                                // Log("NEG");
                                temp = A;
                                A = 0;
                                Sub_R(temp); //Sets flags correctly for NEG as well!
                                break;

                            case 0x4D:  //RETI
                                // Log("RETI");
                                PC = PopStack();
                                IFF1 = IFF2;
                                MemPtr = PC;
                                break;

                            case 0x4F:  //LD R, A
                                // Log("LD R, A");

                                _R = A;
                                break;

                            case 0x50: //IN D, (C)
                                // Log("IN D, (C)");
                                D = In();
                                //tstates = 0;
                                break;

                            case 0x51: //Out (C), D
                                // Log("OUT (C), D");
                                Out(BC, D);
                                break;

                            case 0x52:  //SBC HL, DE
                                // Log("SBC HL, DE");
                                //if (model == MachineModel._plus3)
                                //    totalTStates += 7;
                                //else
                                
                                MemPtr = HL + 1;
                                Sbc_RR(DE);
                                break;

                            case 0x53:  //LD (nn), DE
                                disp = PeekWord(PC);
                                // Log(String.Format("LD ({0:X}), DE", disp));
                                PokeWord(disp, DE);
                                MemPtr = disp + 1;
                                PC += 2;
                                break;

                            case 0x54:  //NEG
                                // Log("NEG");
                                temp = A;
                                A = 0;
                                Sub_R(temp); //Sets flags correctly for NEG as well!
                                break;

                            case 0x55:  //RETN
                                // Log("RETN");
                                PC = PopStack();
                                IFF1 = IFF2;
                                MemPtr = PC;
                                break;

                            case 0x56:  //IM1
                                // Log("IM 1");
                                interruptMode = 1;
                                break;

                            case 0x57:  //LD A, I
                                // Log("LD A, I");
                                A = I;

                                SetNeg(false);
                                SetHalf(false);
                                SetParity(IFF2);
                                SetSign((A & F_SIGN) != 0);
                                SetZero(A == 0);
                                SetF3((A & F_3) != 0);
                                SetF5((A & F_5) != 0);
                                break;

                            case 0x58: //IN E, (C)
                                // Log("IN E, (C)");
                                E = In();
                                //tstates = 0;
                                break;

                            case 0x59: //Out (C), E
                                // Log("OUT (C), E");
                                Out(BC, E);
                                tstates = 0;
                                break;

                            case 0x5A:  //ADC HL, DE
                                // Log("ADC HL, DE");
                                      MemPtr = HL + 1;
                                Adc_RR(DE);
                                break;

                            case 0x5B:  //LD DE, (nn)
                                disp = PeekWord(PC);
                                // Log(String.Format("LD DE, ({0:X})", disp));
                                DE = PeekWord(disp);
                                MemPtr = disp + 1;
                                PC += 2;
                                break;

                            case 0x5C:  //NEG
                                // Log("NEG");
                                temp = A;
                                A = 0;
                                Sub_R(temp); //Sets flags correctly for NEG as well!
                                break;

                            case 0x5D:  //RETN
                                // Log("RETN");
                                PC = PopStack();
                                IFF1 = IFF2;
                                MemPtr = PC;
                                break;

                            case 0x5E:  //IM2
                                // Log("IM 2");
                                interruptMode = 2;
                                break;

                            case 0x5F:  //LD A, R
                                // Log("LD A, R");
                                A = R;
                                SetNeg(false);
                                SetHalf(false);
                                SetParity(IFF2);
                                SetSign((A & F_SIGN) != 0);
                                SetZero(A == 0);
                                SetF3((A & F_3) != 0);
                                SetF5((A & F_5) != 0);
                                break;

                            case 0x60: //IN H, (C)
                                // Log("IN H, (C)");
                                H = In();
                                break;

                            case 0x61: //Out (C), H
                                // Log("OUT (C), H");
                                Out(BC, H);
                                break;

                            case 0x62:  //SBC HL, HL
                                // Log("SBC HL, HL");
                                //if (model == MachineModel._plus3)
                                //    totalTStates += 7;
                                //else
                                
                                MemPtr = HL + 1;
                                Sbc_RR(HL);
                                break;

                            case 0x63:  //LD (nn), HL
                                disp = PeekWord(PC);
                                // Log(String.Format("LD ({0:X}), HL", disp));
                                PokeWord(disp, HL);
                                MemPtr = disp + 1;
                                PC += 2;
                                break;

                            case 0x64:  //NEG
                                // Log("NEG");
                                temp = A;
                                A = 0;
                                Sub_R(temp); //Sets flags correctly for NEG as well!
                                break;

                            case 0x65:  //RETN
                                // Log("RETN");
                                PC = PopStack();
                                IFF1 = IFF2;
                                MemPtr = PC;
                                break;

                            case 0x67:  //RRD
                                // Log("RRD");
                                temp = A;
                                int data = PeekByte(HL);
                                A = (A & 0xf0) | (data & 0x0f);
                                data = (data >> 4) | (temp << 4);
                                
                                PokeByte(HL, data);
                                MemPtr = HL + 1;
                                SetSign((A & F_SIGN) != 0);
                                SetF3((A & F_3) != 0);
                                SetF5((A & F_5) != 0);
                                SetZero(A == 0);
                                // SetParity(GetParity(A));
                                SetParity(parity[A]);
                                SetHalf(false);
                                SetNeg(false);
                                break;

                            case 0x68: //IN L, (C)
                                // Log("IN L, (C)");
                                L = In();
                                break;

                            case 0x69: //Out (C), L
                                // Log("OUT (C), L");
                                Out(BC, L);
                                break;

                            case 0x6A:  //ADC HL, HL
                                // Log("ADC HL, HL");
                                //if (model == MachineModel._plus3)
                                //    totalTStates += 7;
                                //else
                                
                                MemPtr = HL + 1;
                                Adc_RR(HL);
                                break;

                            case 0x6B:  //LD HL, (nn)
                                disp = PeekWord(PC);
                                // Log(String.Format("LD HL, ({0:X})", disp));
                                HL = PeekWord(disp);
                                MemPtr = disp + 1;
                                PC += 2;
                                break;

                            case 0x6C:  //NEG
                                // Log("NEG");
                                temp = A;
                                A = 0;
                                Sub_R(temp); //Sets flags correctly for NEG as well!
                                break;

                            case 0x6D:  //RETN
                                // Log("RETN");
                                PC = PopStack();
                                IFF1 = IFF2;
                                MemPtr = PC;
                                break;

                            case 0x6F:  //RLD
                                // Log("RLD");
                                temp = A;
                                data = PeekByte(HL);
                                A = (A & 0xf0) | (data >> 4);
                                data = (data << 4) | (temp & 0x0f);
                                
                                PokeByte(HL, data & 0xff);
                                MemPtr = HL + 1;
                                SetSign((A & F_SIGN) != 0);
                                SetF3((A & F_3) != 0);
                                SetF5((A & F_5) != 0);
                                SetZero(A == 0);
                                // SetParity(GetParity(A)); // Not sure what to do here!
                                SetParity(parity[A]);
                                SetHalf(false);
                                SetNeg(false);
                                break;

                            case 0x70:  //IN (C)
                                // Log("IN (C)");
                                In();
                                //tstates = 0;
                                break;

                            case 0x71:
                                // Log("OUT (C), 0");
                                Out(BC, 0);
                                break;

                            case 0x72:  //SBC HL, SP
                                // Log("SBC HL, SP");
                                //if (model == MachineModel._plus3)
                                //    totalTStates += 7;
                                //else
                                
                                MemPtr = HL + 1;
                                Sbc_RR(SP);
                                break;

                            case 0x73:  //LD (nn), SP
                                disp = PeekWord(PC);
                                // Log(String.Format("LD ({0:X}), SP", disp));
                                PokeWord(disp, SP);
                                MemPtr = disp + 1;
                                PC += 2;
                                break;

                            case 0x74:  //NEG
                                // Log("NEG");
                                temp = A;
                                A = 0;
                                Sub_R(temp); //Sets flags correctly for NEG as well!
                                break;

                            case 0x75:  //RETN
                                // Log("RETN");
                                PC = PopStack();
                                IFF1 = IFF2;
                                MemPtr = PC;
                                break;

                            case 0x76:  //IM 1
                                // Log("IM 1");
                                interruptMode = 1;
                                break;

                            case 0x78:  //IN A, (C)
                                // Log("IN A, (C)");
                                MemPtr = BC + 1;
                                A = In();
                                break;

                            case 0x79: //Out (C), A
                                // Log("OUT (C), A");
                                MemPtr = BC + 1;
                                Out(BC, A);
                                break;

                            case 0x7A:  //ADC HL, SP
                                // Log("ADC HL, SP");
                                //if (model == MachineModel._plus3)
                                //    totalTStates += 7;
                                //else
                                
                                MemPtr = HL + 1;
                                Adc_RR(SP);
                                break;

                            case 0x7B:  //LD SP, (nn)
                                disp = PeekWord(PC);
                                // Log(String.Format("LD SP, ({0:X})", disp));
                                SP = PeekWord(disp);
                                MemPtr = disp + 1;
                                PC += 2;
                                break;

                            case 0x7C:  //NEG
                                // Log("NEG");
                                temp = A;
                                A = 0;
                                Sub_R(temp); //Sets flags correctly for NEG as well!
                                break;

                            case 0x7D:  //RETN
                                // Log("RETN");
                                PC = PopStack();
                                IFF1 = IFF2;
                                MemPtr = PC;
                                break;

                            case 0x7E:  //IM 2
                                // Log("IM 2");
                                interruptMode = 2;
                                break;

                            case 0xA0:  //LDI
                                // Log("LDI");
                                disp = PeekByte(HL);
                                PokeByte(DE, disp);
                                
                                SetF3(((disp + A) & F_3) != 0);
                                SetF5(((disp + A) & F_NEG) != 0);
                                HL++;
                                DE++;
                                BC--;
                                SetNeg(false);
                                SetHalf(false);
                                SetParity(BC != 0);
                                break;

                            case 0xA1:  //CPI
                                // Log("CPI");
                                disp = PeekByte(HL);
                                bool lastCarry = ((F & F_CARRY) != 0);
                                Cp_R(disp);
                                
                                HL++;
                                BC--;

                                MemPtr++;
                                SetCarry(lastCarry);
                                SetParity(BC != 0);
                                SetF3((((A - disp - ((F & F_HALF) >> 4)) & 0xff) & F_3) != 0);
                                SetF5((((A - disp - ((F & F_HALF) >> 4)) & 0xff) & F_NEG) != 0);
                                break;

                            case 0xA2:  //INI
                                // Log("INI");
                                
                                int result = In();
                                PokeByte(HL, result);
                                MemPtr = BC + 1;
                                B = Dec(B);
                                HL++;
                                SetNeg((result & F_SIGN) != 0);
                                SetCarry(((((C + 1) & 0xff) + result) > 0xff));
                                SetHalf((F & F_CARRY) != 0);

                                SetParity(parity[(((result + ((C + 1) & 0xff)) & 0x7) ^ B)]);
                                break;

                            case 0xA3:  //OUTI
                                
                                // Log("OUTI");

                                B = Dec(B);
                                MemPtr = BC + 1;
                                disp = PeekByte(HL);
                                Out(BC, disp);

                                HL++;
                                SetNeg((disp & F_SIGN) != 0);
                                SetCarry((disp + L) > 0xff);
                                SetHalf((F & F_CARRY) != 0);

                                SetParity(parity[(((disp + L) & 0x7) ^ B)]);
                                //SetZero(B == 0);
                                break;

                            case 0xA8:  //LDD
                                // Log("LDD");
                                disp = PeekByte(HL);
                                PokeByte(DE, disp);
                                
                                SetF3(((disp + A) & F_3) != 0);
                                SetF5(((disp + A) & F_NEG) != 0);
                                HL--;
                                DE--;
                                BC--;
                                SetNeg(false);
                                SetHalf(false);
                                SetParity(BC != 0);
                                break;

                            case 0xA9:  //CPD
                                // Log("CPD");
                                lastCarry = ((F & F_CARRY) != 0);
                                disp = PeekByte(HL);
                                Cp_R(disp);
                                
                                HL--;
                                BC--;
                                SetParity(BC != 0);
                                SetF3((((A - disp - ((F & F_HALF) >> 4)) & 0xff) & F_3) != 0);
                                SetF5((((A - disp - ((F & F_HALF) >> 4)) & 0xff) & F_NEG) != 0);
                                SetCarry(lastCarry);
                                MemPtr--;
                                break;

                            case 0xAA:  //IND
                                // Log("IND");
                                
                                result = In();
                                PokeByte(HL, result);
                                MemPtr = BC - 1;
                                B = Dec(B); ;
                                HL--;
                                SetNeg((result & F_SIGN) != 0);
                                SetCarry(((((C - 1) & 0xff) + result) > 0xff));
                                SetHalf((F & F_CARRY) != 0);

                                SetParity(parity[(((result + ((C - 1) & 0xff)) & 0x7) ^ B)]);
                                break;

                            case 0xAB:  //OUTD
                                // Log("OUTD");
                                

                                B = Dec(B);
                                MemPtr = BC - 1;

                                disp = PeekByte(HL);
                                Out(BC, disp);

                                HL--;

                                SetNeg((disp & F_SIGN) != 0);
                                SetCarry((disp + L) > 0xff);
                                SetHalf((F & F_CARRY) != 0);

                                SetParity(parity[(((disp + L) & 0x7) ^ B)]);
                                break;

                            case 0xB0:  //LDIR
                                // Log("LDIR");
                                disp = PeekByte(HL);
                                PokeByte(DE, disp);
                                SetF3(((disp + A) & F_3) != 0);
                                SetF5(((disp + A) & F_NEG) != 0);
                                SetNeg(false);
                                SetHalf(false);
                                if (BC != 1) {
                                    MemPtr = PC - 1; //points to B0 byte
                                }

                                BC--;
                                if (BC != 0) {
                                    PC -= 2;
                                }

                                SetParity(BC != 0);
                                HL++;
                                DE++;

                                break;

                            case 0xB1:  //CPIR
                                // Log("CPIR");
                                lastCarry = ((F & F_CARRY) != 0);
                                disp = PeekByte(HL);
                                Cp_R(disp);
                                
                                if ((BC == 1) || (A == disp)) {
                                    MemPtr++;
                                } else {
                                    MemPtr = PC - 1;
                                }
                                BC--;
                                SetCarry(lastCarry);
                                SetParity(BC != 0);
                                SetF3((((A - disp - ((F & F_HALF) >> 4)) & 0xff) & F_3) != 0);
                                SetF5((((A - disp - ((F & F_HALF) >> 4)) & 0xff) & F_NEG) != 0);
                                if ((BC != 0) && ((F & F_ZERO) == 0)) {
                                    
                                    PC -= 2;
                                }
                                HL++;

                                break;

                            case 0xB2:  //INIR
                                // Log("INIR");
                                
                                result = In();
                                PokeByte(HL, result);
                                MemPtr = BC + 1;
                                B = Dec(B); ;
                                HL++;
                                if (B != 0) {
                                    
                                    PC -= 2;
                                }

                                SetNeg((result & F_SIGN) != 0);
                                SetCarry(((((C + 1) & 0xff) + result) > 0xff));
                                SetHalf((F & F_CARRY) != 0);

                                SetParity(parity[(((result + ((C + 1) & 0xff)) & 0x7) ^ B)]);
                                break;

                            case 0xB3:  //OTIR
                                // Log("OTIR");
                                
                                B = Dec(B);
                                MemPtr = BC + 1;

                                disp = PeekByte(HL);
                                Out(BC, disp);
                                if (B != 0) {
                                    PC -= 2;
                                }

                                HL++;
                                SetNeg((disp & F_SIGN) != 0);
                                SetCarry((disp + L) > 0xff);
                                SetHalf((F & F_CARRY) != 0);

                                SetParity(parity[(((disp + L) & 0x7) ^ B)]);
                                break;

                            case 0xB8:  //LDDR
                                // Log("LDDR");
                                disp = PeekByte(HL);
                                PokeByte(DE, disp);
                                

                                SetF3(((disp + A) & F_3) != 0);
                                SetF5(((disp + A) & F_NEG) != 0);
                                SetNeg(false);
                                SetHalf(false);
                                if (BC != 1) {
                                    MemPtr = PC - 1;
                                }

                                BC--;
                                if (BC != 0) {
                                    
                                    PC -= 2;
                                }

                                SetParity(BC != 0);
                                HL--;
                                DE--;

                                break;

                            case 0xB9:  //CPDR
                                // Log("CPDR");
                                lastCarry = ((F & F_CARRY) != 0);
                                disp = PeekByte(HL);
                                Cp_R(disp);
                                
                                if ((BC == 1) || (A == disp)) {
                                    MemPtr--;
                                } else {
                                    MemPtr = PC - 1;
                                }

                                BC--;
                                SetCarry(lastCarry);
                                SetParity(BC != 0);
                                SetF3((((A - disp - ((F & F_HALF) >> 4)) & 0xff) & F_3) != 0);
                                SetF5((((A - disp - ((F & F_HALF) >> 4)) & 0xff) & F_NEG) != 0);
                                if ((BC != 0) && ((F & F_ZERO) == 0)) {
                                    
                                    PC -= 2;
                                }
                                HL--;
                                break;

                            case 0xBA:  //INDR
                                // Log("INDR");
                                
                                result = In();
                                PokeByte(HL, result);
                                MemPtr = BC - 1;
                                B = Dec(B);
                                if (B != 0) {
                                    
                                    PC -= 2;
                                }
                                HL--;
                                SetNeg((result & F_SIGN) != 0);
                                SetCarry(((((C - 1) & 0xff) + result) > 0xff));
                                SetHalf((F & F_CARRY) != 0);
                                SetParity(parity[(((result + ((C - 1) & 0xff)) & 0x7) ^ B)]);
                                break;

                            case 0xBB:  //OTDR
                                // Log("OTDR");
                                
                                B = Dec(B);
                                MemPtr = BC - 1;

                                disp = PeekByte(HL);
                                Out(BC, disp);

                                if (B != 0) {
                                    PC -= 2;
                                }

                                HL--;
                                SetNeg((disp & F_SIGN) != 0);
                                SetCarry((disp + L) > 0xff);
                                SetHalf((F & F_CARRY) != 0);

                                SetParity(parity[(((disp + L) & 0x7) ^ B)]);
                                break;

                            default:
                                //According to Sean's doc: http://z80.info/z80sean.txt
                                //If an EDxx instruction is not listed, it should operate as two NOPs.
                                break;  //Carry on to next instruction then
                        }
                    break;
#endregion

#region Opcodes with FD prefix (includes FDCB)
                case 0xFD:
                    switch (opcode = FetchInstruction()) {
#region Addition instructions
                        case 0x09:  //ADD IY, BC
                            // Log("ADD IY, BC");
                            
                            MemPtr = IY + 1;
                            IY = Add_RR(IY, BC);
                            break;

                        case 0x19:  //ADD IY, DE
                            // Log("ADD IY, DE");
                            
                            MemPtr = IY + 1;
                            IY = Add_RR(IY, DE);
                            break;

                        case 0x29:  //ADD IY, IY
                            // Log("ADD IY, IY");
                            
                            MemPtr = IY + 1;
                            IY = Add_RR(IY, IY);
                            break;

                        case 0x39:  //ADD IY, SP
                            // Log("ADD IY, SP");
                            
                            MemPtr = IY + 1;
                            IY = Add_RR(IY, SP);
                            break;

                        case 0x84:  //ADD A, IYH
                            // Log("ADD A, IYH");
                            Add_R(IYH);
                            break;

                        case 0x85:  //ADD A, IYL
                            // Log("ADD A, IYL");
                            Add_R(IYL);
                            break;

                        case 0x86:  //Add A, (IY+d)
                            disp = GetDisplacement(PeekByte(PC));
                            int offset = IY + disp; //The displacement required
                            // Log(string.Format("ADD A, (IY + {0:X})", disp));
                            //if (model == MachineModel._plus3)
                            //    totalTStates += 5;
                            //else
                            
                            Add_R(PeekByte(offset));
                            PC++;
                            MemPtr = offset;
                            break;

                        case 0x8C:  //ADC A, IYH
                            // Log("ADC A, IYH");
                            Adc_R(IYH);
                            break;

                        case 0x8D:  //ADC A, IYL
                            // Log("ADC A, IYL");
                            Adc_R(IYL);
                            break;

                        case 0x8E: //ADC A, (IY+d)
                            disp = GetDisplacement(PeekByte(PC));
                            offset = IY + disp; //The displacement required
                            // Log(string.Format("ADC A, (IY + {0:X})", disp));
                            //if (model == MachineModel._plus3)
                            //    totalTStates += 5;
                            //else
                            
                            Adc_R(PeekByte(offset));
                            PC++;
                            MemPtr = offset;
                            break;
#endregion

#region Subtraction instructions
                        case 0x94:  //SUB A, IYH
                            // Log("SUB A, IYH");
                            Sub_R(IYH);
                            break;

                        case 0x95:  //SUB A, IYL
                            // Log("SUB A, IYL");
                            Sub_R(IYL);
                            break;

                        case 0x96:  //SUB (IY + d)
                            disp = GetDisplacement(PeekByte(PC));
                            offset = IY + disp; //The displacement required
                            // Log(string.Format("SUB (IY + {0:X})", disp));
                            //if (model == MachineModel._plus3)
                            //    totalTStates += 5;
                            //else
                            
                            Sub_R(PeekByte(offset));
                            PC++;
                            MemPtr = offset;
                            break;

                        case 0x9C:  //SBC A, IYH
                            // Log("SBC A, IYH");
                            Sbc_R(IYH);
                            break;

                        case 0x9D:  //SBC A, IYL
                            // Log("SBC A, IYL");
                            Sbc_R(IYL);
                            break;

                        case 0x9E:  //SBC A, (IY + d)
                            disp = GetDisplacement(PeekByte(PC));
                            offset = IY + disp; //The displacement required
                            // Log(string.Format("SBC A, (IY + {0:X})", disp));
                            //if (model == MachineModel._plus3)
                            //    totalTStates += 5;
                            //else
                            
                            Sbc_R(PeekByte(offset));
                            PC++;
                            MemPtr = offset;
                            break;
#endregion

#region Increment/Decrements
                        case 0x23:  //INC IY
                            // Log("INC IY");
                            //if (model == MachineModel._plus3)
                            //    totalTStates += 2;
                            //else
                            
                            IY++;
                            break;

                        case 0x24:  //INC IYH
                            // Log("INC IYH");
                            IYH = Inc(IYH);
                            break;

                        case 0x25:  //DEC IYH
                            // Log("DEC IYH");
                            IYH = Dec(IYH);
                            break;

                        case 0x2B:  //DEC IY
                            // Log("DEC IY");
                            //if (model == MachineModel._plus3)
                            //    totalTStates += 2;
                            //else
                            
                            IY--;
                            break;

                        case 0x2C:  //INC IYL
                            // Log("INC IYL");
                            IYL = Inc(IYL);
                            break;

                        case 0x2D:  //DEC IYL
                            // Log("DEC IYL");
                            IYL = Dec(IYL);
                            break;

                        case 0x34:  //INC (IY + d)
                            disp = GetDisplacement(PeekByte(PC));
                            offset = IY + disp; //The displacement required
                            // Log(string.Format("INC (IY + {0:X})", disp));
                            
                            disp = Inc(PeekByte(offset));
                            
                            PokeByte(offset, disp);
                            PC++;
                            MemPtr = offset;
                            break;

                        case 0x35:  //DEC (IY + d)
                            disp = GetDisplacement(PeekByte(PC));
                            offset = IY + disp; //The displacement required
                            // Log(string.Format("DEC (IY + {0:X})", disp));
                            
                            disp = Dec(PeekByte(offset));
                            
                            PokeByte(offset, disp);
                            PC++;
                            MemPtr = offset;
                            break;
#endregion

#region Bitwise operators

                        case 0xA4:  //AND IYH
                            // Log("AND IYH");
                            And_R(IYH);
                            break;

                        case 0xA5:  //AND IYL
                            // Log("AND IYL");
                            And_R(IYL);
                            break;

                        case 0xA6:  //AND (IY + d)
                            disp = GetDisplacement(PeekByte(PC));
                            offset = IY + disp; //The displacement required
                            // Log(string.Format("AND (IY + {0:X})", disp));
                            // if (model == MachineModel._plus3)
                            //     totalTStates += 5;
                            // else
                            
                            And_R(PeekByte(offset));
                            PC++;
                            MemPtr = offset;
                            break;

                        case 0xAC:  //XOR IYH
                            // Log("XOR IYH");
                            Xor_R(IYH);
                            break;

                        case 0xAD:  //XOR IYL
                            // Log("XOR IYL");
                            Xor_R(IYL);
                            break;

                        case 0xAE:  //XOR (IY + d)
                            disp = GetDisplacement(PeekByte(PC));

                            offset = IY + disp; //The displacement required
                            // Log(string.Format("XOR (IY + {0:X})", disp));
                            //if (model == MachineModel._plus3)
                            //    totalTStates += 5;
                            //else
                            
                            Xor_R(PeekByte(offset));
                            PC++;
                            MemPtr = offset;
                            break;

                        case 0xB4:  //OR IYH
                            // Log("OR IYH");
                            Or_R(IYH);
                            break;

                        case 0xB5:  //OR IYL
                            // Log("OR IYL");
                            Or_R(IYL);
                            break;

                        case 0xB6:  //OR (IY + d)
                            disp = GetDisplacement(PeekByte(PC));

                            offset = IY + disp; //The displacement required
                            // Log(string.Format("OR (IY + {0:X})", disp));
                            //if (model == MachineModel._plus3)
                            //    totalTStates += 5;
                            //else
                            
                            Or_R(PeekByte(offset));
                            PC++;
                            MemPtr = offset;
                            break;
#endregion

#region Compare operator
                        case 0xBC:  //CP IYH
                            // Log("CP IYH");
                            Cp_R(IYH);
                            break;

                        case 0xBD:  //CP IYL
                            // Log("CP IYL");
                            Cp_R(IYL);
                            break;

                        case 0xBE:  //CP (IY + d)
                            disp = GetDisplacement(PeekByte(PC));

                            offset = IY + disp; //The displacement required
                            // Log(string.Format("CP (IY + {0:X})", disp));
                            //if (model == MachineModel._plus3)
                            //    totalTStates += 5;
                            //else
                            
                            Cp_R(PeekByte(offset));
                            PC++;
                            MemPtr = offset;
                            break;
#endregion

#region Load instructions
                        case 0x21:  //LD IY, nn
                            // Log(string.Format("LD IY, {0,-6:X}", PeekWord(PC)));
                            IY = PeekWord(PC);
                            PC += 2;
                            break;

                        case 0x22:  //LD (nn), IY
                            // Log(string.Format("LD ({0:X}), IY", PeekWord(PC)));
                            addr = PeekWord(PC);
                            PokeWord(addr, IY);
                            PC += 2;
                            MemPtr = addr + 1;
                            break;

                        case 0x26:  //LD IYH, n
                            // Log(string.Format("LD IYH, {0:X}", PeekByte(PC)));
                            IYH = PeekByte(PC);
                            PC++;
                            break;

                        case 0x2A:  //LD IY, (nn)
                            // Log(string.Format("LD IY, ({0:X})", PeekWord(PC)));
                            addr = PeekWord(PC);
                            IY = PeekWord(addr);
                            PC += 2;
                            MemPtr = addr + 1;
                            break;

                        case 0x2E:  //LD IYL, n
                            // Log(string.Format("LD IYL, {0:X}", PeekByte(PC)));
                            IYL = PeekByte(PC);
                            PC++;
                            break;

                        case 0x36:  //LD (IY + d), n
                            disp = GetDisplacement(PeekByte(PC));

                            offset = IY + disp; //The displacement required
                            // Log(string.Format("LD (IY + {0:X}), {1,-6:X}", disp, PeekByte(PC + 1)));
                            disp = PeekByte(PC + 1);
                            //if (model == MachineModel._plus3)
                            //    totalTStates += 2;
                            //else
                            
                            PokeByte(offset, disp);
                            PC += 2;
                            MemPtr = offset;
                            break;

                        case 0x44:  //LD B, IYH
                            // Log("LD B, IYH");
                            B = IYH;
                            break;

                        case 0x45:  //LD B, IYL
                            // Log("LD B, IYL");
                            B = IYL;
                            break;

                        case 0x46:  //LD B, (IY + d)
                            disp = GetDisplacement(PeekByte(PC));
                            offset = IY + disp; //The displacement required
                            // Log(string.Format("LD B, (IY + {0:X})", disp));
                            //if (model == MachineModel._plus3)
                            //    totalTStates += 5;
                            //else
                            

                            B = PeekByte(offset);
                            PC++;
                            MemPtr = offset;
                            break;

                        case 0x4C:  //LD C, IYH
                            // Log("LD C, IYH");
                            C = IYH;
                            break;

                        case 0x4D:  //LD C, IYL
                            // Log("LD C, IYL");
                            C = IYL;
                            break;

                        case 0x4E:  //LD C, (IY + d)
                            disp = GetDisplacement(PeekByte(PC));

                            offset = IY + disp; //The displacement required
                            // Log(string.Format("LD C, (IY + {0:X})", disp));
                            //if (model == MachineModel._plus3)
                            //    totalTStates += 5;
                            //else
                            
                            C = PeekByte(offset);
                            PC++;
                            MemPtr = offset;
                            break;

                        case 0x54:  //LD D, IYH
                            // Log("LD D, IYH");
                            //tstates += 4;
                            D = IYH;
                            break;

                        case 0x55:  //LD D, IYL
                            // Log("LD D, IYL");
                            //tstates += 4;
                            D = IYL;
                            break;

                        case 0x56:  //LD D, (IY + d)
                            disp = GetDisplacement(PeekByte(PC));

                            offset = IY + disp; //The displacement required
                            // Log(string.Format("LD D, (IY + {0:X})", disp));
                            //if (model == MachineModel._plus3)
                            //    totalTStates += 5;
                            //else
                            
                            D = PeekByte(offset);
                            PC++;
                            MemPtr = offset;
                            break;

                        case 0x5C:  //LD E, IYH
                            // Log("LD E, IYH");
                            //tstates += 4;
                            E = IYH;
                            break;

                        case 0x5D:  //LD E, IYL
                            // Log("LD E, IYL");
                            //tstates += 4;
                            E = IYL;
                            break;

                        case 0x5E:  //LD E, (IY + d)
                            disp = GetDisplacement(PeekByte(PC));

                            offset = IY + disp; //The displacement required
                            // Log(string.Format("LD E, (IY + {0:X})", disp));
                            //if (model == MachineModel._plus3)
                            //    totalTStates += 5;
                            //else
                            
                            E = PeekByte(offset);
                            PC++;
                            MemPtr = offset;
                            break;

                        case 0x60:  //LD IYH, B
                            // Log("LD IYH, B");
                            //tstates += 4;
                            IYH = B;
                            break;

                        case 0x61:  //LD IYH, C
                            // Log("LD IYH, C");
                            //tstates += 4;
                            IYH = C;
                            break;

                        case 0x62:  //LD IYH, D
                            // Log("LD IYH, D");
                            //tstates += 4;
                            IYH = D;
                            break;

                        case 0x63:  //LD IYH, E
                            // Log("LD IYH, E");
                            //tstates += 4;
                            IYH = E;
                            break;

                        case 0x64:  //LD IYH, IYH
                            // Log("LD IYH, IYH");
                            //tstates += 4;
                            IYH = IYH;
                            break;

                        case 0x65:  //LD IYH, IYL
                            // Log("LD IYH, IYL");
                            //tstates += 4;
                            IYH = IYL;
                            break;

                        case 0x66:  //LD H, (IY + d)
                            disp = GetDisplacement(PeekByte(PC));

                            offset = IY + disp; //The displacement required
                            // Log(string.Format("LD H, (IY + {0:X})", disp));
                            //if (model == MachineModel._plus3)
                            //    totalTStates += 5;
                            //else
                            
                            H = PeekByte(offset);
                            PC++;
                            MemPtr = offset;
                            break;

                        case 0x67:  //LD IYH, A
                            // Log("LD IYH, A");
                            //tstates += 4;
                            IYH = A;
                            break;

                        case 0x68:  //LD IYL, B
                            // Log("LD IYL, B");
                            //tstates += 4;
                            IYL = B;
                            break;

                        case 0x69:  //LD IYL, C
                            // Log("LD IYL, C");
                            //tstates += 4;
                            IYL = C;
                            break;

                        case 0x6A:  //LD IYL, D
                            // Log("LD IYL, D");
                            //tstates += 4;
                            IYL = D;
                            break;

                        case 0x6B:  //LD IYL, E
                            // Log("LD IYL, E");
                            //tstates += 4;
                            IYL = E;
                            break;

                        case 0x6C:  //LD IYL, IYH
                            // Log("LD IYL, IYH");
                            //tstates += 4;
                            IYL = IYH;
                            break;

                        case 0x6D:  //LD IYL, IYL
                            // Log("LD IYL, IYL");
                            //tstates += 4;
                            IYL = IYL;
                            break;

                        case 0x6E:  //LD L, (IY + d)
                            disp = GetDisplacement(PeekByte(PC));

                            offset = IY + disp; //The displacement required
                            // Log(string.Format("LD L, (IY + {0:X})", disp));
                            //if (model == MachineModel._plus3)
                            //    totalTStates += 5;
                            //else
                            
                            L = PeekByte(offset);
                            PC++;
                            MemPtr = offset;
                            break;

                        case 0x6F:  //LD IYL, A
                            // Log("LD IYL, A");
                            //tstates += 4;
                            IYL = A;
                            break;

                        case 0x70:  //LD (IY + d), B
                            disp = GetDisplacement(PeekByte(PC));

                            offset = IY + disp; //The displacement required
                            // Log(string.Format("LD (IY + {0:X}), B", disp));
                            //if (model == MachineModel._plus3)
                            //    totalTStates += 5;
                            //else
                            
                            PokeByte(offset, B);
                            PC++;
                            MemPtr = offset;
                            break;

                        case 0x71:  //LD (IY + d), C
                            disp = GetDisplacement(PeekByte(PC));

                            offset = IY + disp; //The displacement required
                            // Log(string.Format("LD (IY + {0:X}), C", disp));
                            //if (model == MachineModel._plus3)
                            //    totalTStates += 5;
                            //else
                            
                            PokeByte(offset, C);
                            PC++;
                            MemPtr = offset;
                            break;

                        case 0x72:  //LD (IY + d), D
                            disp = GetDisplacement(PeekByte(PC));

                            offset = IY + disp; //The displacement required
                            // Log(string.Format("LD (IY + {0:X}), D", disp));
                            //if (model == MachineModel._plus3)
                            //    totalTStates += 5;
                            //else
                            
                            PokeByte(offset, D);
                            PC++;
                            MemPtr = offset;
                            break;

                        case 0x73:  //LD (IY + d), E
                            disp = GetDisplacement(PeekByte(PC));

                            offset = IY + disp; //The displacement required
                            // Log(string.Format("LD (IY + {0:X}), E", disp));
                            //if (model == MachineModel._plus3)
                            //    totalTStates += 5;
                            //else
                            
                            PokeByte(offset, E);
                            PC++;
                            MemPtr = offset;
                            break;

                        case 0x74:  //LD (IY + d), H
                            disp = GetDisplacement(PeekByte(PC));

                            offset = IY + disp; //The displacement required
                            // Log(string.Format("LD (IY + {0:X}), H", disp));
                            //if (model == MachineModel._plus3)
                            //    totalTStates += 5;
                            //else
                            
                            PokeByte(offset, H);
                            PC++;
                            MemPtr = offset;
                            break;

                        case 0x75:  //LD (IY + d), L
                            disp = GetDisplacement(PeekByte(PC));

                            offset = IY + disp; //The displacement required
                            // Log(string.Format("LD (IY + {0:X}), L", disp));
                            //if (model == MachineModel._plus3)
                            //    totalTStates += 5;
                            //else
                            
                            PokeByte(offset, L);
                            PC++;
                            MemPtr = offset;
                            break;

                        case 0x77:  //LD (IY + d), A
                            disp = GetDisplacement(PeekByte(PC));

                            offset = IY + disp; //The displacement required
                            // Log(string.Format("LD (IY + {0:X}), A", disp));
                            //if (model == MachineModel._plus3)
                            //    totalTStates += 5;
                            //else
                            
                            PokeByte(offset, A);
                            PC++;
                            MemPtr = offset;
                            break;

                        case 0x7C:  //LD A, IYH
                            // Log("LD A, IYH");
                            A = IYH;
                            break;

                        case 0x7D:  //LD A, IYL
                            // Log("LD A, IYL");
                            A = IYL;
                            break;

                        case 0x7E:  //LD A, (IY + d)
                            disp = GetDisplacement(PeekByte(PC));

                            offset = IY + disp; //The displacement required
                            // Log(string.Format("LD A, (IY + {0:X})", disp));
                            //if (model == MachineModel._plus3)
                            //    totalTStates += 5;
                            //else
                            
                            A = PeekByte(offset);
                            PC++;
                            MemPtr = offset;
                            break;

                        case 0xF9:  //LD SP, IY
                            // Log("LD SP, IY");
                            
                            SP = IY;
                            break;
#endregion

#region All FDCB instructions
                        case 0xCB:
                            disp = GetDisplacement(PeekByte(PC));
                            offset = IY + disp; //The displacement required
                            PC++;
                            opcode = GetOpcode(PC);      //The opcode comes after the offset byte!                           
                            PC++;
                            disp = PeekByte(offset);
                            
                            // if ((opcode >= 0x40) && (opcode <= 0x7f))
                            MemPtr = offset;

                            switch (opcode) {
                                case 0x00: //LD B, RLC (IY+d)
                                    // Log(string.Format("LD B, RLC (IY + {0:X})", disp));
                                    B = Rlc_R(disp);
                                    PokeByte(offset, B);
                                    break;

                                case 0x01: //LD C, RLC (IY+d)
                                    // Log(string.Format("LD C, RLC (IY + {0:X})", disp));
                                    C = Rlc_R(disp);
                                    PokeByte(offset, C);
                                    break;

                                case 0x02: //LD D, RLC (IY+d)
                                    // Log(string.Format("LD D, RLC (IY + {0:X})", disp));
                                    D = Rlc_R(disp);
                                    PokeByte(offset, D);
                                    break;

                                case 0x03: //LD E, RLC (IY+d)
                                    // Log(string.Format("LD E, RLC (IY + {0:X})", disp));
                                    E = Rlc_R(disp);
                                    PokeByte(offset, E);
                                    break;

                                case 0x04: //LD H, RLC (IY+d)
                                    // Log(string.Format("LD H, RLC (IY + {0:X})", disp));
                                    H = Rlc_R(disp);
                                    PokeByte(offset, H);
                                    break;

                                case 0x05: //LD L, RLC (IY+d)
                                    // Log(string.Format("LD L, RLC (IY + {0:X})", disp));
                                    L = Rlc_R(disp);
                                    PokeByte(offset, L);
                                    break;

                                case 0x06:  //RLC (IY + d)
                                    // Log(string.Format("RLC (IY + {0:X})", disp));
                                    PokeByte(offset, Rlc_R(disp));
                                    break;

                                case 0x07: //LD A, RLC (IY+d)
                                    // Log(string.Format("LD A, RLC (IY + {0:X})", disp));
                                    A = Rlc_R(disp);
                                    PokeByte(offset, A);
                                    break;

                                case 0x08: //LD B, RRC (IY+d)
                                    // Log(string.Format("LD B, RRC (IY + {0:X})", disp));
                                    B = Rrc_R(disp);
                                    PokeByte(offset, B);
                                    break;

                                case 0x09: //LD C, RRC (IY+d)
                                    // Log(string.Format("LD C, RRC (IY + {0:X})", disp));
                                    C = Rrc_R(disp);
                                    PokeByte(offset, C);
                                    break;

                                case 0x0A: //LD D, RRC (IY+d)
                                    // Log(string.Format("LD D, RRC (IY + {0:X})", disp));
                                    D = Rrc_R(disp);
                                    PokeByte(offset, D);
                                    break;

                                case 0x0B: //LD E, RRC (IY+d)
                                    // Log(string.Format("LD E, RRC (IY + {0:X})", disp));
                                    E = Rrc_R(disp);
                                    PokeByte(offset, E);
                                    break;

                                case 0x0C: //LD H, RRC (IY+d)
                                    // Log(string.Format("LD H, RRC (IY + {0:X})", disp));
                                    H = Rrc_R(disp);
                                    PokeByte(offset, H);
                                    break;

                                case 0x0D: //LD L, RRC (IY+d)
                                    // Log(string.Format("LD L, RRC (IY + {0:X})", disp));
                                    L = Rrc_R(disp);
                                    PokeByte(offset, L);
                                    break;

                                case 0x0E:  //RRC (IY + d)
                                    // Log(string.Format("RRC (IY + {0:X})", disp));
                                    PokeByte(offset, Rrc_R(disp));
                                    break;

                                case 0x0F: //LD A, RRC (IY+d)
                                    // Log(string.Format("LD A, RRC (IY + {0:X})", disp));
                                    A = Rrc_R(disp);
                                    PokeByte(offset, A);
                                    break;

                                case 0x10: //LD B, RL (IY+d)
                                    // Log(string.Format("LD B, RL (IY + {0:X})", disp));
                                    B = Rl_R(disp);
                                    PokeByte(offset, B);
                                    break;

                                case 0x11: //LD C, RL (IY+d)
                                    // Log(string.Format("LD C, RL (IY + {0:X})", disp));
                                    C = Rl_R(disp);
                                    PokeByte(offset, C);
                                    break;

                                case 0x12: //LD D, RL (IY+d)
                                    // Log(string.Format("LD D, RL (IY + {0:X})", disp));
                                    D = Rl_R(disp);
                                    PokeByte(offset, D);
                                    break;

                                case 0x13: //LD E, RL (IY+d)
                                    // Log(string.Format("LD E, RL (IY + {0:X})", disp));
                                    E = Rl_R(disp);
                                    PokeByte(offset, E);
                                    break;

                                case 0x14: //LD H, RL (IY+d)
                                    // Log(string.Format("LD H, RL (IY + {0:X})", disp));
                                    H = Rl_R(disp);
                                    PokeByte(offset, H);
                                    break;

                                case 0x15: //LD L, RL (IY+d)
                                    // Log(string.Format("LD L, RL (IY + {0:X})", disp));
                                    L = Rl_R(disp);
                                    PokeByte(offset, L);
                                    break;

                                case 0x16:  //RL (IY + d)
                                    // Log(string.Format("RL (IY + {0:X})", disp));
                                    PokeByte(offset, Rl_R(disp));

                                    break;

                                case 0x17: //LD A, RL (IY+d)
                                    // Log(string.Format("LD A, RL (IY + {0:X})", disp));
                                    A = Rl_R(disp);
                                    PokeByte(offset, A);
                                    break;

                                case 0x18: //LD B, RR (IY+d)
                                    // Log(string.Format("LD B, RR (IY + {0:X})", disp));
                                    B = Rr_R(disp);
                                    PokeByte(offset, B);
                                    break;

                                case 0x19: //LD C, RR (IY+d)
                                    // Log(string.Format("LD C, RR (IY + {0:X})", disp));
                                    C = Rr_R(disp);
                                    PokeByte(offset, C);
                                    break;

                                case 0x1A: //LD D, RR (IY+d)
                                    // Log(string.Format("LD D, RR (IY + {0:X})", disp));
                                    D = Rr_R(disp);
                                    PokeByte(offset, D);
                                    break;

                                case 0x1B: //LD E, RR (IY+d)
                                    // Log(string.Format("LD E, RR (IY + {0:X})", disp));
                                    E = Rr_R(disp);
                                    PokeByte(offset, E);
                                    break;

                                case 0x1C: //LD H, RR (IY+d)
                                    // Log(string.Format("LD H, RR (IY + {0:X})", disp));
                                    H = Rr_R(disp);
                                    PokeByte(offset, H);
                                    break;

                                case 0x1D: //LD L, RRC (IY+d)
                                    // Log(string.Format("LD L, RR (IY + {0:X})", disp));
                                    L = Rr_R(disp);
                                    PokeByte(offset, L);
                                    break;

                                case 0x1E:  //RR (IY + d)
                                    // Log(string.Format("RR (IY + {0:X})", disp));
                                    PokeByte(offset, Rr_R(disp));
                                    break;

                                case 0x1F: //LD A, RRC (IY+d)
                                    // Log(string.Format("LD A, RR (IY + {0:X})", disp));
                                    A = Rr_R(disp);
                                    PokeByte(offset, A);
                                    break;

                                case 0x20: //LD B, SLA (IY+d)
                                    // Log(string.Format("LD B, SLA (IY + {0:X})", disp));
                                    B = Sla_R(disp);
                                    PokeByte(offset, B);
                                    break;

                                case 0x21: //LD C, SLA (IY+d)
                                    // Log(string.Format("LD C, SLA (IY + {0:X})", disp));
                                    C = Sla_R(disp);
                                    PokeByte(offset, C);
                                    break;

                                case 0x22: //LD D, SLA (IY+d)
                                    // Log(string.Format("LD D, SLA (IY + {0:X})", disp));
                                    D = Sla_R(disp);
                                    PokeByte(offset, D);
                                    break;

                                case 0x23: //LD E, SLA (IY+d)
                                    // Log(string.Format("LD E, SLA (IY + {0:X})", disp));
                                    E = Sla_R(disp);
                                    PokeByte(offset, E);
                                    break;

                                case 0x24: //LD H, SLA (IY+d)
                                    // Log(string.Format("LD H, SLA (IY + {0:X})", disp));
                                    H = Sla_R(disp);
                                    PokeByte(offset, H);
                                    break;

                                case 0x25: //LD L, SLA (IY+d)
                                    // Log(string.Format("LD L, SLA (IY + {0:X})", disp));
                                    L = Sla_R(disp);
                                    PokeByte(offset, L);
                                    break;

                                case 0x26:  //SLA (IY + d)
                                    // Log(string.Format("SLA (IY + {0:X})", disp));
                                    PokeByte(offset, Sla_R(disp));
                                    break;

                                case 0x27: //LD A, SLA (IY+d)
                                    // Log(string.Format("LD A, SLA (IY + {0:X})", disp));
                                    A = Sla_R(disp);
                                    PokeByte(offset, A);
                                    break;

                                case 0x28: //LD B, SRA (IY+d)
                                    // Log(string.Format("LD B, SRA (IY + {0:X})", disp));
                                    B = Sra_R(disp);
                                    PokeByte(offset, B);
                                    break;

                                case 0x29: //LD C, SRA (IY+d)
                                    // Log(string.Format("LD C, SRA (IY + {0:X})", disp));
                                    C = Sra_R(disp);
                                    PokeByte(offset, C);
                                    break;

                                case 0x2A: //LD D, SRA (IY+d)
                                    // Log(string.Format("LD D, SRA (IY + {0:X})", disp));
                                    D = Sra_R(disp);
                                    PokeByte(offset, D);
                                    break;

                                case 0x2B: //LD E, SRA (IY+d)
                                    // Log(string.Format("LD E, SRA (IY + {0:X})", disp));
                                    E = Sra_R(disp);
                                    PokeByte(offset, E);
                                    break;

                                case 0x2C: //LD H, SRA (IY+d)
                                    // Log(string.Format("LD H, SRA (IY + {0:X})", disp));
                                    H = Sra_R(disp);
                                    PokeByte(offset, H);
                                    break;

                                case 0x2D: //LD L, SRA (IY+d)
                                    // Log(string.Format("LD L, SRA (IY + {0:X})", disp));
                                    L = Sra_R(disp);
                                    PokeByte(offset, L);
                                    break;

                                case 0x2E:  //SRA (IY + d)
                                    // Log(string.Format("SRA (IY + {0:X})", disp));
                                    PokeByte(offset, Sra_R(disp));
                                    break;

                                case 0x2F: //LD A, SRA (IY+d)
                                    // Log(string.Format("LD A, SRA (IY + {0:X})", disp));
                                    A = Sra_R(disp);
                                    PokeByte(offset, A);
                                    break;

                                case 0x30: //LD B, SLL (IY+d)
                                    // Log(string.Format("LD B, SLL (IY + {0:X})", disp));
                                    B = Sll_R(disp);
                                    PokeByte(offset, B);
                                    break;

                                case 0x31: //LD C, SLL (IY+d)
                                    // Log(string.Format("LD C, SLL (IY + {0:X})", disp));
                                    C = Sll_R(disp);
                                    PokeByte(offset, C);
                                    break;

                                case 0x32: //LD D, SLL (IY+d)
                                    // Log(string.Format("LD D, SLL (IY + {0:X})", disp));
                                    D = Sll_R(disp);
                                    PokeByte(offset, D);
                                    break;

                                case 0x33: //LD E, SLL (IY+d)
                                    // Log(string.Format("LD E, SLL (IY + {0:X})", disp));
                                    E = Sll_R(disp);
                                    PokeByte(offset, E);
                                    break;

                                case 0x34: //LD H, SLL (IY+d)
                                    // Log(string.Format("LD H, SLL (IY + {0:X})", disp));
                                    H = Sll_R(disp);
                                    PokeByte(offset, H);
                                    break;

                                case 0x35: //LD L, SLL (IY+d)
                                    // Log(string.Format("LD L, SLL (IY + {0:X})", disp));
                                    L = Sll_R(disp);
                                    PokeByte(offset, L);
                                    break;

                                case 0x36:  //SLL (IY + d)
                                    // Log(string.Format("SLL (IY + {0:X})", disp));
                                    PokeByte(offset, Sll_R(disp));
                                    break;

                                case 0x37: //LD A, SLL (IY+d)
                                    // Log(string.Format("LD A, SLL (IY + {0:X})", disp));
                                    A = Sll_R(disp);
                                    PokeByte(offset, A);
                                    break;

                                case 0x38: //LD B, SRL (IY+d)
                                    // Log(string.Format("LD B, SRL (IY + {0:X})", disp));
                                    B = Srl_R(disp);
                                    PokeByte(offset, B);
                                    break;

                                case 0x39: //LD C, SRL (IY+d)
                                    // Log(string.Format("LD C, SRL (IY + {0:X})", disp));
                                    C = Srl_R(disp);
                                    PokeByte(offset, C);
                                    break;

                                case 0x3A: //LD D, SRL (IY+d)
                                    // Log(string.Format("LD D, SRL (IY + {0:X})", disp));
                                    D = Srl_R(disp);
                                    PokeByte(offset, D);
                                    break;

                                case 0x3B: //LD E, SRL (IY+d)
                                    // Log(string.Format("LD E, SRL (IY + {0:X})", disp));
                                    E = Srl_R(disp);
                                    PokeByte(offset, E);
                                    break;

                                case 0x3C: //LD H, SRL (IY+d)
                                    // Log(string.Format("LD H, SRL (IY + {0:X})", disp));
                                    H = Srl_R(disp);
                                    PokeByte(offset, H);
                                    break;

                                case 0x3D: //LD L, SRL (IY+d)
                                    // Log(string.Format("LD L, SRL (IY + {0:X})", disp));
                                    L = Srl_R(disp);
                                    PokeByte(offset, L);
                                    break;

                                case 0x3E:  //SRL (IY + d)
                                    // Log(string.Format("SRL (IY + {0:X})", disp));
                                    PokeByte(offset, Srl_R(disp));
                                    break;

                                case 0x3F: //LD A, SRL (IY+d)
                                    // Log(string.Format("LD A, SRL (IY + {0:X})", disp));
                                    A = Srl_R(disp);
                                    PokeByte(offset, A);
                                    break;

                                case 0x40:  //BIT 0, (IY + d)
                                case 0x41:  //BIT 0, (IY + d)
                                case 0x42:  //BIT 0, (IY + d)
                                case 0x43:  //BIT 0, (IY + d)
                                case 0x44:  //BIT 0, (IY + d)
                                case 0x45:  //BIT 0, (IY + d)
                                case 0x46:  //BIT 0, (IY + d)
                                case 0x47:  //BIT 0, (IY + d)
                                    // Log(string.Format("BIT 0, (IY + {0:X})", disp));
                                    Bit_R(0, disp);
                                    SetF3((MemPtr & MEMPTR_11) != 0);
                                    SetF5((MemPtr & MEMPTR_13) != 0);
                                    break;

                                case 0x48:  //BIT 1, (IY + d)
                                case 0x49:  //BIT 1, (IY + d)
                                case 0x4A:  //BIT 1, (IY + d)
                                case 0x4B:  //BIT 1, (IY + d)
                                case 0x4C:  //BIT 1, (IY + d)
                                case 0x4D:  //BIT 1, (IY + d)
                                case 0x4E:  //BIT 1, (IY + d)
                                case 0x4F:  //BIT 1, (IY + d)
                                    // Log(string.Format("BIT 1, (IY + {0:X})", disp));
                                    Bit_R(1, disp);
                                    SetF3((MemPtr & MEMPTR_11) != 0);
                                    SetF5((MemPtr & MEMPTR_13) != 0);
                                    break;

                                case 0x50:  //BIT 2, (IY + d)
                                case 0x51:  //BIT 2, (IY + d)
                                case 0x52:  //BIT 2, (IY + d)
                                case 0x53:  //BIT 2, (IY + d)
                                case 0x54:  //BIT 2, (IY + d)
                                case 0x55:  //BIT 2, (IY + d)
                                case 0x56:  //BIT 2, (IY + d)
                                case 0x57:  //BIT 2, (IY + d)
                                    // Log(string.Format("BIT 2, (IY + {0:X})", disp));
                                    Bit_R(2, disp);
                                    SetF3((MemPtr & MEMPTR_11) != 0);
                                    SetF5((MemPtr & MEMPTR_13) != 0);
                                    break;

                                case 0x58:  //BIT 3, (IY + d)
                                case 0x59:  //BIT 3, (IY + d)
                                case 0x5A:  //BIT 3, (IY + d)
                                case 0x5B:  //BIT 3, (IY + d)
                                case 0x5C:  //BIT 3, (IY + d)
                                case 0x5D:  //BIT 3, (IY + d)
                                case 0x5E:  //BIT 3, (IY + d)
                                case 0x5F:  //BIT 3, (IY + d)
                                    // Log(string.Format("BIT 3, (IY + {0:X})", disp));
                                    Bit_R(3, disp);
                                    SetF3((MemPtr & MEMPTR_11) != 0);
                                    SetF5((MemPtr & MEMPTR_13) != 0);
                                    break;

                                case 0x60:  //BIT 4, (IY + d)
                                case 0x61:  //BIT 4, (IY + d)
                                case 0x62:  //BIT 4, (IY + d)
                                case 0x63:  //BIT 4, (IY + d)
                                case 0x64:  //BIT 4, (IY + d)
                                case 0x65:  //BIT 4, (IY + d)
                                case 0x66:  //BIT 4, (IY + d)
                                case 0x67:  //BIT 4, (IY + d)
                                    // Log(string.Format("BIT 4, (IY + {0:X})", disp));
                                    Bit_R(4, disp);
                                    SetF3((MemPtr & MEMPTR_11) != 0);
                                    SetF5((MemPtr & MEMPTR_13) != 0);
                                    break;

                                case 0x68:  //BIT 5, (IY + d)
                                case 0x69:  //BIT 5, (IY + d)
                                case 0x6A:  //BIT 5, (IY + d)
                                case 0x6B:  //BIT 5, (IY + d)
                                case 0x6C:  //BIT 5, (IY + d)
                                case 0x6D:  //BIT 5, (IY + d)
                                case 0x6E:  //BIT 5, (IY + d)
                                case 0x6F:  //BIT 5, (IY + d)
                                    // Log(string.Format("BIT 5, (IY + {0:X})", disp));
                                    Bit_R(5, disp);
                                    SetF3((MemPtr & MEMPTR_11) != 0);
                                    SetF5((MemPtr & MEMPTR_13) != 0);
                                    break;

                                case 0x70://BIT 6, (IY + d)
                                case 0x71://BIT 6, (IY + d)
                                case 0x72://BIT 6, (IY + d)
                                case 0x73://BIT 6, (IY + d)
                                case 0x74://BIT 6, (IY + d)
                                case 0x75://BIT 6, (IY + d)
                                case 0x76://BIT 6, (IY + d)
                                case 0x77:  //BIT 6, (IY + d)
                                    // Log(string.Format("BIT 6, (IY + {0:X})", disp));
                                    Bit_R(6, disp);
                                    SetF3((MemPtr & MEMPTR_11) != 0);
                                    SetF5((MemPtr & MEMPTR_13) != 0);
                                    break;

                                case 0x78:  //BIT 7, (IY + d)
                                case 0x79:  //BIT 7, (IY + d)
                                case 0x7A:  //BIT 7, (IY + d)
                                case 0x7B:  //BIT 7, (IY + d)
                                case 0x7C:  //BIT 7, (IY + d)
                                case 0x7D:  //BIT 7, (IY + d)
                                case 0x7E:  //BIT 7, (IY + d)
                                case 0x7F:  //BIT 7, (IY + d)
                                    // Log(string.Format("BIT 7, (IY + {0:X})", disp));
                                    Bit_R(7, disp);
                                    SetF3((MemPtr & MEMPTR_11) != 0);
                                    SetF5((MemPtr & MEMPTR_13) != 0);
                                    break;

                                case 0x80: //LD B, RES 0, (IY+d)
                                    // Log(string.Format("LD B, RES 0, (IY + {0:X})", disp));
                                    B = Res_R(0, disp);
                                    PokeByte(offset, B);
                                    break;

                                case 0x81: //LD C, RES 0, (IY+d)
                                    // Log(string.Format("LD C, RES 0, (IY + {0:X})", disp));
                                    C = Res_R(0, disp);
                                    PokeByte(offset, C);
                                    break;

                                case 0x82: //LD D, RES 0, (IY+d)
                                    // Log(string.Format("LD D, RES 0, (IY + {0:X})", disp));
                                    D = Res_R(0, disp);
                                    PokeByte(offset, D);
                                    break;

                                case 0x83: //LD E, RES 0, (IY+d)
                                    // Log(string.Format("LD E, RES 0, (IY + {0:X})", disp));
                                    E = Res_R(0, disp);
                                    PokeByte(offset, E);
                                    break;

                                case 0x84: //LD H, RES 0, (IY+d)
                                    // Log(string.Format("LD H, RES 0, (IY + {0:X})", disp));
                                    H = Res_R(0, disp);
                                    PokeByte(offset, H);
                                    break;

                                case 0x85: //LD L, RES 0, (IY+d)
                                    // Log(string.Format("LD L, RES 0, (IY + {0:X})", disp));
                                    L = Res_R(0, disp);
                                    PokeByte(offset, L);
                                    break;

                                case 0x86:  //RES 0, (IY + d)
                                    // Log(string.Format("RES 0, (IY + {0:X})", disp));
                                    PokeByte(offset, Res_R(0, disp));
                                    break;

                                case 0x87: //LD A, RES 0, (IY+d)
                                    // Log(string.Format("LD A, RES 0, (IY + {0:X})", disp));
                                    A = Res_R(0, disp);
                                    PokeByte(offset, A);
                                    break;

                                case 0x88: //LD B, RES 1, (IY+d)
                                    // Log(string.Format("LD B, RES 1, (IY + {0:X})", disp));
                                    B = Res_R(1, disp);
                                    PokeByte(offset, B);
                                    break;

                                case 0x89: //LD C, RES 1, (IY+d)
                                    // Log(string.Format("LD C, RES 1, (IY + {0:X})", disp));
                                    C = Res_R(1, disp);
                                    PokeByte(offset, C);
                                    break;

                                case 0x8A: //LD D, RES 1, (IY+d)
                                    // Log(string.Format("LD D, RES 1, (IY + {0:X})", disp));
                                    D = Res_R(1, disp);
                                    PokeByte(offset, D);
                                    break;

                                case 0x8B: //LD E, RES 1, (IY+d)
                                    // Log(string.Format("LD E, RES 1, (IY + {0:X})", disp));
                                    E = Res_R(1, disp);
                                    PokeByte(offset, E);
                                    break;

                                case 0x8C: //LD H, RES 1, (IY+d)
                                    // Log(string.Format("LD H, RES 1, (IY + {0:X})", disp));
                                    H = Res_R(1, disp);
                                    PokeByte(offset, H);
                                    break;

                                case 0x8D: //LD L, RES 1, (IY+d)
                                    // Log(string.Format("LD L, RES 1, (IY + {0:X})", disp));
                                    L = Res_R(1, disp);
                                    PokeByte(offset, L);
                                    break;

                                case 0x8E:  //RES 1, (IY + d)
                                    // Log(string.Format("RES 1, (IY + {0:X})", disp));
                                    PokeByte(offset, Res_R(1, disp));
                                    break;

                                case 0x8F: //LD A, RES 1, (IY+d)
                                    // Log(string.Format("LD A, RES 1, (IY + {0:X})", disp));
                                    A = Res_R(1, disp);
                                    PokeByte(offset, A);
                                    break;

                                case 0x90: //LD B, RES 2, (IY+d)
                                    // Log(string.Format("LD B, RES 2, (IY + {0:X})", disp));
                                    B = Res_R(2, disp);
                                    PokeByte(offset, B);
                                    break;

                                case 0x91: //LD C, RES 2, (IY+d)
                                    // Log(string.Format("LD C, RES 2, (IY + {0:X})", disp));
                                    C = Res_R(2, disp);
                                    PokeByte(offset, C);
                                    break;

                                case 0x92: //LD D, RES 2, (IY+d)
                                    // Log(string.Format("LD D, RES 2, (IY + {0:X})", disp));
                                    D = Res_R(2, disp);
                                    PokeByte(offset, D);
                                    break;

                                case 0x93: //LD E, RES 2, (IY+d)
                                    // Log(string.Format("LD E, RES 2, (IY + {0:X})", disp));
                                    E = Res_R(2, disp);
                                    PokeByte(offset, E);
                                    break;

                                case 0x94: //LD H, RES 2, (IY+d)
                                    // Log(string.Format("LD H, RES 2, (IY + {0:X})", disp));
                                    H = Res_R(2, disp);
                                    PokeByte(offset, H);
                                    break;

                                case 0x95: //LD L, RES 2, (IY+d)
                                    // Log(string.Format("LD L, RES 2, (IY + {0:X})", disp));
                                    L = Res_R(2, disp);
                                    PokeByte(offset, L);
                                    break;

                                case 0x96:  //RES 2, (IY + d)
                                    // Log(string.Format("RES 2, (IY + {0:X})", disp));
                                    PokeByte(offset, Res_R(2, disp));
                                    break;

                                case 0x97: //LD A, RES 2, (IY+d)
                                    // Log(string.Format("LD A, RES 2, (IY + {0:X})", disp));
                                    A = Res_R(2, disp);
                                    PokeByte(offset, A);
                                    break;

                                case 0x98: //LD B, RES 3, (IY+d)
                                    // Log(string.Format("LD B, RES 3, (IY + {0:X})", disp));
                                    B = Res_R(3, disp);
                                    PokeByte(offset, B);
                                    break;

                                case 0x99: //LD C, RES 3, (IY+d)
                                    // Log(string.Format("LD C, RES 3, (IY + {0:X})", disp));
                                    C = Res_R(3, disp);
                                    PokeByte(offset, C);
                                    break;

                                case 0x9A: //LD D, RES 3, (IY+d)
                                    // Log(string.Format("LD D, RES 3, (IY + {0:X})", disp));
                                    D = Res_R(3, disp);
                                    PokeByte(offset, D);
                                    break;

                                case 0x9B: //LD E, RES 3, (IY+d)
                                    // Log(string.Format("LD E, RES 3, (IY + {0:X})", disp));
                                    E = Res_R(3, disp);
                                    PokeByte(offset, E);
                                    break;

                                case 0x9C: //LD H, RES 3, (IY+d)
                                    // Log(string.Format("LD H, RES 3, (IY + {0:X})", disp));
                                    H = Res_R(3, disp);
                                    PokeByte(offset, H);
                                    break;

                                case 0x9D: //LD L, RES 3, (IY+d)
                                    // Log(string.Format("LD L, RES 3, (IY + {0:X})", disp));
                                    L = Res_R(3, disp);
                                    PokeByte(offset, L);
                                    break;

                                case 0x9E:  //RES 3, (IY + d)
                                    // Log(string.Format("RES 3, (IY + {0:X})", disp));
                                    PokeByte(offset, Res_R(3, disp));
                                    break;

                                case 0x9F: //LD A, RES 3, (IY+d)
                                    // Log(string.Format("LD A, RES 3, (IY + {0:X})", disp));
                                    A = Res_R(3, disp);
                                    PokeByte(offset, A);
                                    break;

                                case 0xA0: //LD B, RES 4, (IY+d)
                                    // Log(string.Format("LD B, RES 4, (IY + {0:X})", disp));
                                    B = Res_R(4, disp);
                                    PokeByte(offset, B);
                                    break;

                                case 0xA1: //LD C, RES 4, (IY+d)
                                    // Log(string.Format("LD C, RES 4, (IY + {0:X})", disp));
                                    C = Res_R(4, disp);
                                    PokeByte(offset, C);
                                    break;

                                case 0xA2: //LD D, RES 4, (IY+d)
                                    // Log(string.Format("LD D, RES 4, (IY + {0:X})", disp));
                                    D = Res_R(4, disp);
                                    PokeByte(offset, D);
                                    break;

                                case 0xA3: //LD E, RES 4, (IY+d)
                                    // Log(string.Format("LD E, RES 4, (IY + {0:X})", disp));
                                    E = Res_R(4, disp);
                                    PokeByte(offset, E);
                                    break;

                                case 0xA4: //LD H, RES 4, (IY+d)
                                    // Log(string.Format("LD H, RES 4, (IY + {0:X})", disp));
                                    H = Res_R(4, disp);
                                    PokeByte(offset, H);
                                    break;

                                case 0xA5: //LD L, RES 4, (IY+d)
                                    // Log(string.Format("LD L, RES 4, (IY + {0:X})", disp));
                                    L = Res_R(4, disp);
                                    PokeByte(offset, L);
                                    break;

                                case 0xA6:  //RES 4, (IY + d)
                                    // Log(string.Format("RES 4, (IY + {0:X})", disp));
                                    PokeByte(offset, Res_R(4, disp));
                                    break;

                                case 0xA7: //LD A, RES 4, (IY+d)
                                    // Log(string.Format("LD A, RES 4, (IY + {0:X})", disp));
                                    A = Res_R(4, disp);
                                    PokeByte(offset, A);
                                    break;

                                case 0xA8: //LD B, RES 5, (IY+d)
                                    // Log(string.Format("LD B, RES 5, (IY + {0:X})", disp));
                                    B = Res_R(5, disp);
                                    PokeByte(offset, B);
                                    break;

                                case 0xA9: //LD C, RES 5, (IY+d)
                                    // Log(string.Format("LD C, RES 5, (IY + {0:X})", disp));
                                    C = Res_R(5, disp);
                                    PokeByte(offset, C);
                                    break;

                                case 0xAA: //LD D, RES 5, (IY+d)
                                    // Log(string.Format("LD D, RES 5, (IY + {0:X})", disp));
                                    D = Res_R(5, disp);
                                    PokeByte(offset, D);
                                    break;

                                case 0xAB: //LD E, RES 5, (IY+d)
                                    // Log(string.Format("LD E, RES 5, (IY + {0:X})", disp));
                                    E = Res_R(5, disp);
                                    PokeByte(offset, E);
                                    break;

                                case 0xAC: //LD H, RES 5, (IY+d)
                                    // Log(string.Format("LD H, RES 5, (IY + {0:X})", disp));
                                    H = Res_R(5, disp);
                                    PokeByte(offset, H);
                                    break;

                                case 0xAD: //LD L, RES 5, (IY+d)
                                    // Log(string.Format("LD L, RES 5, (IY + {0:X})", disp));
                                    L = Res_R(5, disp);
                                    PokeByte(offset, L);
                                    break;

                                case 0xAE:  //RES 5, (IY + d)
                                    // Log(string.Format("RES 5, (IY + {0:X})", disp));
                                    PokeByte(offset, Res_R(5, disp));
                                    break;

                                case 0xAF: //LD A, RES 5, (IY+d)
                                    // Log(string.Format("LD A, RES 5, (IY + {0:X})", disp));
                                    A = Res_R(5, disp);
                                    PokeByte(offset, A);
                                    break;

                                case 0xB0: //LD B, RES 6, (IY+d)
                                    // Log(string.Format("LD B, RES 6, (IY + {0:X})", disp));
                                    B = Res_R(6, disp);
                                    PokeByte(offset, B);
                                    break;

                                case 0xB1: //LD C, RES 6, (IY+d)
                                    // Log(string.Format("LD C, RES 6, (IY + {0:X})", disp));
                                    C = Res_R(6, disp);
                                    PokeByte(offset, C);
                                    break;

                                case 0xB2: //LD D, RES 6, (IY+d)
                                    // Log(string.Format("LD D, RES 6, (IY + {0:X})", disp));
                                    D = Res_R(5, disp);
                                    PokeByte(offset, D);
                                    break;

                                case 0xB3: //LD E, RES 6, (IY+d)
                                    // Log(string.Format("LD E, RES 6, (IY + {0:X})", disp));
                                    E = Res_R(6, disp);
                                    PokeByte(offset, E);
                                    break;

                                case 0xB4: //LD H, RES 5, (IY+d)
                                    // Log(string.Format("LD H, RES 6, (IY + {0:X})", disp));
                                    H = Res_R(6, disp);
                                    PokeByte(offset, H);
                                    break;

                                case 0xB5: //LD L, RES 5, (IY+d)
                                    // Log(string.Format("LD L, RES 6, (IY + {0:X})", disp));
                                    L = Res_R(6, disp);
                                    PokeByte(offset, L);
                                    break;

                                case 0xB6:  //RES 6, (IY + d)
                                    // Log(string.Format("RES 6, (IY + {0:X})", disp));
                                    PokeByte(offset, Res_R(6, disp));
                                    break;

                                case 0xB7: //LD A, RES 5, (IY+d)
                                    // Log(string.Format("LD A, RES 6, (IY + {0:X})", disp));
                                    A = Res_R(6, disp);
                                    PokeByte(offset, A);
                                    break;

                                case 0xB8: //LD B, RES 7, (IY+d)
                                    // Log(string.Format("LD B, RES 7, (IY + {0:X})", disp));
                                    B = Res_R(7, disp);
                                    PokeByte(offset, B);
                                    break;

                                case 0xB9: //LD C, RES 7, (IY+d)
                                    // Log(string.Format("LD C, RES 7, (IY + {0:X})", disp));
                                    C = Res_R(7, disp);
                                    PokeByte(offset, C);
                                    break;

                                case 0xBA: //LD D, RES 7, (IY+d)
                                    // Log(string.Format("LD D, RES 7, (IY + {0:X})", disp));
                                    D = Res_R(7, disp);
                                    PokeByte(offset, D);
                                    break;

                                case 0xBB: //LD E, RES 7, (IY+d)
                                    // Log(string.Format("LD E, RES 7, (IY + {0:X})", disp));
                                    E = Res_R(7, disp);
                                    PokeByte(offset, E);
                                    break;

                                case 0xBC: //LD H, RES 7, (IY+d)
                                    // Log(string.Format("LD H, RES 7, (IY + {0:X})", disp));
                                    H = Res_R(7, disp);
                                    PokeByte(offset, H);
                                    break;

                                case 0xBD: //LD L, RES 7, (IY+d)
                                    // Log(string.Format("LD L, RES 7, (IY + {0:X})", disp));
                                    L = Res_R(7, disp);
                                    PokeByte(offset, L);
                                    break;

                                case 0xBE:  //RES 7, (IY + d)
                                    // Log(string.Format("RES 7, (IY + {0:X})", disp));
                                    PokeByte(offset, Res_R(7, disp));
                                    break;

                                case 0xBF: //LD A, RES 7, (IY+d)
                                    // Log(string.Format("LD A, RES 7, (IY + {0:X})", disp));
                                    A = Res_R(7, disp);
                                    PokeByte(offset, A);
                                    break;

                                case 0xC0: //LD B, SET 0, (IY+d)
                                    // Log(string.Format("LD B, SET 0, (IY + {0:X})", disp));
                                    B = Set_R(0, disp);
                                    PokeByte(offset, B);
                                    break;

                                case 0xC1: //LD C, SET 0, (IY+d)
                                    // Log(string.Format("LD C, SET 0, (IY + {0:X})", disp));
                                    C = Set_R(0, disp);
                                    PokeByte(offset, C);
                                    break;

                                case 0xC2: //LD D, SET 0, (IY+d)
                                    // Log(string.Format("LD D, SET 0, (IY + {0:X})", disp));
                                    D = Set_R(0, disp);
                                    PokeByte(offset, D);
                                    break;

                                case 0xC3: //LD E, SET 0, (IY+d)
                                    // Log(string.Format("LD E, SET 0, (IY + {0:X})", disp));
                                    E = Set_R(0, disp);
                                    PokeByte(offset, E);
                                    break;

                                case 0xC4: //LD H, SET 0, (IY+d)
                                    // Log(string.Format("LD H, SET 0, (IY + {0:X})", disp));
                                    H = Set_R(0, disp);
                                    PokeByte(offset, H);
                                    break;

                                case 0xC5: //LD L, SET 0, (IY+d)
                                    // Log(string.Format("LD L, SET 0, (IY + {0:X})", disp));
                                    L = Set_R(0, disp);
                                    PokeByte(offset, L);
                                    break;

                                case 0xC6:  //SET 0, (IY + d)
                                    // Log(string.Format("SET 0, (IY + {0:X})", disp));
                                    PokeByte(offset, Set_R(0, disp));
                                    break;

                                case 0xC7: //LD A, SET 0, (IY+d)
                                    // Log(string.Format("LD A, SET 0, (IY + {0:X})", disp));
                                    A = Set_R(0, disp);
                                    PokeByte(offset, A);
                                    break;

                                case 0xC8: //LD B, SET 1, (IY+d)
                                    // Log(string.Format("LD B, SET 1, (IY + {0:X})", disp));
                                    B = Set_R(1, disp);
                                    PokeByte(offset, B);
                                    break;

                                case 0xC9: //LD C, SET 0, (IY+d)
                                    // Log(string.Format("LD C, SET 1, (IY + {0:X})", disp));
                                    C = Set_R(1, disp);
                                    PokeByte(offset, C);
                                    break;

                                case 0xCA: //LD D, SET 1, (IY+d)
                                    // Log(string.Format("LD D, SET 1, (IY + {0:X})", disp));
                                    D = Set_R(1, disp);
                                    PokeByte(offset, D);
                                    break;

                                case 0xCB: //LD E, SET 1, (IY+d)
                                    // Log(string.Format("LD E, SET 1, (IY + {0:X})", disp));
                                    E = Set_R(1, disp);
                                    PokeByte(offset, E);
                                    break;

                                case 0xCC: //LD H, SET 1, (IY+d)
                                    // Log(string.Format("LD H, SET 1, (IY + {0:X})", disp));
                                    H = Set_R(1, disp);
                                    PokeByte(offset, H);
                                    break;

                                case 0xCD: //LD L, SET 1, (IY+d)
                                    // Log(string.Format("LD L, SET 1, (IY + {0:X})", disp));
                                    L = Set_R(1, disp);
                                    PokeByte(offset, L);
                                    break;

                                case 0xCE:  //SET 1, (IY + d)
                                    // Log(string.Format("SET 1, (IY + {0:X})", disp));
                                    PokeByte(offset, Set_R(1, disp));
                                    break;

                                case 0xCF: //LD A, SET 1, (IY+d)
                                    // Log(string.Format("LD A, SET 1, (IY + {0:X})", disp));
                                    A = Set_R(1, disp);
                                    PokeByte(offset, A);
                                    break;

                                case 0xD0: //LD B, SET 2, (IY+d)
                                    // Log(string.Format("LD B, SET 2, (IY + {0:X})", disp));
                                    B = Set_R(2, disp);
                                    PokeByte(offset, B);
                                    break;

                                case 0xD1: //LD C, SET 2, (IY+d)
                                    // Log(string.Format("LD C, SET 2, (IY + {0:X})", disp));
                                    C = Set_R(2, disp);
                                    PokeByte(offset, C);
                                    break;

                                case 0xD2: //LD D, SET 2, (IY+d)
                                    // Log(string.Format("LD D, SET 2, (IY + {0:X})", disp));
                                    D = Set_R(2, disp);
                                    PokeByte(offset, D);
                                    break;

                                case 0xD3: //LD E, SET 2, (IY+d)
                                    // Log(string.Format("LD E, SET 2, (IY + {0:X})", disp));
                                    E = Set_R(2, disp);
                                    PokeByte(offset, E);
                                    break;

                                case 0xD4: //LD H, SET 21, (IY+d)
                                    // Log(string.Format("LD H, SET 2, (IY + {0:X})", disp));
                                    H = Set_R(2, disp);
                                    PokeByte(offset, H);
                                    break;

                                case 0xD5: //LD L, SET 2, (IY+d)
                                    // Log(string.Format("LD L, SET 2, (IY + {0:X})", disp));
                                    L = Set_R(2, disp);
                                    PokeByte(offset, L);
                                    break;

                                case 0xD6:  //SET 2, (IY + d)
                                    // Log(string.Format("SET 2, (IY + {0:X})", disp));
                                    PokeByte(offset, Set_R(2, disp));
                                    break;

                                case 0xD7: //LD A, SET 2, (IY+d)
                                    // Log(string.Format("LD A, SET 2, (IY + {0:X})", disp));
                                    A = Set_R(2, disp);
                                    PokeByte(offset, A);
                                    break;

                                case 0xD8: //LD B, SET 3, (IY+d)
                                    // Log(string.Format("LD B, SET 3, (IY + {0:X})", disp));
                                    B = Set_R(3, disp);
                                    PokeByte(offset, B);
                                    break;

                                case 0xD9: //LD C, SET 3, (IY+d)
                                    // Log(string.Format("LD C, SET 3, (IY + {0:X})", disp));
                                    C = Set_R(3, disp);
                                    PokeByte(offset, C);
                                    break;

                                case 0xDA: //LD D, SET 3, (IY+d)
                                    // Log(string.Format("LD D, SET 3, (IY + {0:X})", disp));
                                    D = Set_R(3, disp);
                                    PokeByte(offset, D);
                                    break;

                                case 0xDB: //LD E, SET 3, (IY+d)
                                    // Log(string.Format("LD E, SET 3, (IY + {0:X})", disp));
                                    E = Set_R(3, disp);
                                    PokeByte(offset, E);
                                    break;

                                case 0xDC: //LD H, SET 21, (IY+d)
                                    // Log(string.Format("LD H, SET 3, (IY + {0:X})", disp));
                                    H = Set_R(3, disp);
                                    PokeByte(offset, H);
                                    break;

                                case 0xDD: //LD L, SET 3, (IY+d)
                                    // Log(string.Format("LD L, SET 3, (IY + {0:X})", disp));
                                    L = Set_R(3, disp);
                                    PokeByte(offset, L);
                                    break;

                                case 0xDE:  //SET 3, (IY + d)
                                    // Log(string.Format("SET 3, (IY + {0:X})", disp));
                                    PokeByte(offset, Set_R(3, disp));
                                    break;

                                case 0xDF: //LD A, SET 3, (IY+d)
                                    // Log(string.Format("LD A, SET 3, (IY + {0:X})", disp));
                                    A = Set_R(3, disp);
                                    PokeByte(offset, A);
                                    break;

                                case 0xE0: //LD B, SET 4, (IY+d)
                                    // Log(string.Format("LD B, SET 4, (IY + {0:X})", disp));
                                    B = Set_R(4, disp);
                                    PokeByte(offset, B);
                                    break;

                                case 0xE1: //LD C, SET 4, (IY+d)
                                    // Log(string.Format("LD C, SET 4, (IY + {0:X})", disp));
                                    C = Set_R(4, disp);
                                    PokeByte(offset, C);
                                    break;

                                case 0xE2: //LD D, SET 4, (IY+d)
                                    // Log(string.Format("LD D, SET 4, (IY + {0:X})", disp));
                                    D = Set_R(4, disp);
                                    PokeByte(offset, D);
                                    break;

                                case 0xE3: //LD E, SET 4, (IY+d)
                                    // Log(string.Format("LD E, SET 4, (IY + {0:X})", disp));
                                    E = Set_R(4, disp);
                                    PokeByte(offset, E);
                                    break;

                                case 0xE4: //LD H, SET 4, (IY+d)
                                    // Log(string.Format("LD H, SET 4, (IY + {0:X})", disp));
                                    H = Set_R(4, disp);
                                    PokeByte(offset, H);
                                    break;

                                case 0xE5: //LD L, SET 3, (IY+d)
                                    // Log(string.Format("LD L, SET 4, (IY + {0:X})", disp));
                                    L = Set_R(4, disp);
                                    PokeByte(offset, L);
                                    break;

                                case 0xE6:  //SET 4, (IY + d)
                                    // Log(string.Format("SET 4, (IY + {0:X})", disp));
                                    PokeByte(offset, Set_R(4, disp));
                                    break;

                                case 0xE7: //LD A, SET 4, (IY+d)
                                    // Log(string.Format("LD A, SET 4, (IY + {0:X})", disp));
                                    A = Set_R(4, disp);
                                    PokeByte(offset, A);
                                    break;

                                case 0xE8: //LD B, SET 5, (IY+d)
                                    // Log(string.Format("LD B, SET 5, (IY + {0:X})", disp));
                                    B = Set_R(5, disp);
                                    PokeByte(offset, B);
                                    break;

                                case 0xE9: //LD C, SET 5, (IY+d)
                                    // Log(string.Format("LD C, SET 5, (IY + {0:X})", disp));
                                    C = Set_R(5, disp);
                                    PokeByte(offset, C);
                                    break;

                                case 0xEA: //LD D, SET 5, (IY+d)
                                    // Log(string.Format("LD D, SET 5, (IY + {0:X})", disp));
                                    D = Set_R(5, disp);
                                    PokeByte(offset, D);
                                    break;

                                case 0xEB: //LD E, SET 5, (IY+d)
                                    // Log(string.Format("LD E, SET 5, (IY + {0:X})", disp));
                                    E = Set_R(5, disp);
                                    PokeByte(offset, E);
                                    break;

                                case 0xEC: //LD H, SET 5, (IY+d)
                                    // Log(string.Format("LD H, SET 5, (IY + {0:X})", disp));
                                    H = Set_R(5, disp);
                                    PokeByte(offset, H);
                                    break;

                                case 0xED: //LD L, SET 5, (IY+d)
                                    // Log(string.Format("LD L, SET 5, (IY + {0:X})", disp));
                                    L = Set_R(5, disp);
                                    PokeByte(offset, L);
                                    break;

                                case 0xEE:  //SET 5, (IY + d)
                                    // Log(string.Format("SET 5, (IY + {0:X})", disp));
                                    PokeByte(offset, Set_R(5, disp));
                                    break;

                                case 0xEF: //LD A, SET 5, (IY+d)
                                    // Log(string.Format("LD A, SET 5, (IY + {0:X})", disp));
                                    A = Set_R(5, disp);
                                    PokeByte(offset, A);
                                    break;

                                case 0xF0: //LD B, SET 6, (IY+d)
                                    // Log(string.Format("LD B, SET 6, (IY + {0:X})", disp));
                                    B = Set_R(6, disp);
                                    PokeByte(offset, B);
                                    break;

                                case 0xF1: //LD C, SET 6, (IY+d)
                                    // Log(string.Format("LD C, SET 6, (IY + {0:X})", disp));
                                    C = Set_R(6, disp);
                                    PokeByte(offset, C);
                                    break;

                                case 0xF2: //LD D, SET 6, (IY+d)
                                    // Log(string.Format("LD D, SET 6, (IY + {0:X})", disp));
                                    D = Set_R(6, disp);
                                    PokeByte(offset, D);
                                    break;

                                case 0xF3: //LD E, SET 6, (IY+d)
                                    // Log(string.Format("LD E, SET 6, (IY + {0:X})", disp));
                                    E = Set_R(6, disp);
                                    PokeByte(offset, E);
                                    break;

                                case 0xF4: //LD H, SET 6, (IY+d)
                                    // Log(string.Format("LD H, SET 6, (IY + {0:X})", disp));
                                    H = Set_R(6, disp);
                                    PokeByte(offset, H);
                                    break;

                                case 0xF5: //LD L, SET 6, (IY+d)
                                    // Log(string.Format("LD L, SET 6, (IY + {0:X})", disp));
                                    L = Set_R(6, disp);
                                    PokeByte(offset, L);
                                    break;

                                case 0xF6:  //SET 6, (IY + d)
                                    // Log(string.Format("SET 6, (IY + {0:X})", disp));
                                    PokeByte(offset, Set_R(6, disp));
                                    break;

                                case 0xF7: //LD A, SET 6, (IY+d)
                                    // Log(string.Format("LD A, SET 6, (IY + {0:X})", disp));
                                    A = Set_R(6, disp);
                                    PokeByte(offset, A);
                                    break;

                                case 0xF8: //LD B, SET 7, (IY+d)
                                    // Log(string.Format("LD B, SET 7, (IY + {0:X})", disp));
                                    B = Set_R(7, disp);
                                    PokeByte(offset, B);
                                    break;

                                case 0xF9: //LD C, SET 7, (IY+d)
                                    // Log(string.Format("LD C, SET 7, (IY + {0:X})", disp));
                                    C = Set_R(7, disp);
                                    PokeByte(offset, C);
                                    break;

                                case 0xFA: //LD D, SET 7, (IY+d)
                                    // Log(string.Format("LD D, SET 7, (IY + {0:X})", disp));
                                    D = Set_R(7, disp);
                                    PokeByte(offset, D);
                                    break;

                                case 0xFB: //LD E, SET 7, (IY+d)
                                    // Log(string.Format("LD E, SET 7, (IY + {0:X})", disp));
                                    E = Set_R(7, disp);
                                    PokeByte(offset, E);
                                    break;

                                case 0xFC: //LD H, SET 7, (IY+d)
                                    // Log(string.Format("LD H, SET 7, (IY + {0:X})", disp));
                                    H = Set_R(7, disp);
                                    PokeByte(offset, H);
                                    break;

                                case 0xFD: //LD L, SET 7, (IY+d)
                                    // Log(string.Format("LD L, SET 7, (IY + {0:X})", disp));
                                    L = Set_R(7, disp);
                                    PokeByte(offset, L);
                                    break;

                                case 0xFE:  //SET 7, (IY + d)
                                    // Log(string.Format("SET 7, (IY + {0:X})", disp));
                                    PokeByte(offset, Set_R(7, disp));
                                    break;

                                case 0xFF: //LD A, SET 7, (IY + D)
                                    A = Set_R(7, disp);
                                    PokeByte(offset, A);
                                    break;

                                default:
                                    String msg = "ERROR: Could not handle FDCB " + opcode.ToString();
                                    System.Windows.Forms.MessageBox.Show(msg, "Opcode handler",
                                                System.Windows.Forms.MessageBoxButtons.OKCancel, System.Windows.Forms.MessageBoxIcon.Error);
                                    break;
                            }
                            break;
#endregion

#region Pop/Push instructions
                        case 0xE1:  //POP IY
                            // Log("POP IY");
                            IY = PopStack();
                            break;

                        case 0xE5:  //PUSH IY
                            // Log("PUSH IY");
                            
                            PushStack(IY);
                            break;
#endregion

#region Exchange instruction
                        case 0xE3:  //EX (SP), IY
                            {
                                // Log("EX (SP), IY");
                                addr = PeekWord(SP);
                                PokeByte((SP + 1) & 0xffff, IY >> 8);
                                PokeByte(SP, IY & 0xff);
                                IY = addr;
                                MemPtr = IY;
                                break;
                            }
#endregion

#region Jump instruction
                        case 0xE9:  //JP (IY)
                            // Log("JP (IY)");
                            PC = IY;
                            break;
#endregion

                        default:
                            //According to Sean's doc: http://z80.info/z80sean.txt
                            //If a DDxx or FDxx instruction is not listed, it should operate as
                            //without the DD or FD prefix, and the DD or FD prefix itself should
                            //operate as a NOP.
                            Execute();      //Try and execute it as a normal instruction then
                            break;
                    }
                    break;
#endregion
            }

        }

        //Processes an interrupt
        public void Interrupt() {
            //Disable interrupts
            IFF1 = false;
            IFF2 = false;

            if (HaltOn) {
                HaltOn = false;
                PC++;
            }

            int oldT = totalTStates;
            if (interruptMode < 2) //IM0 = IM1 for our purpose
            {
                //When interrupts are enabled we can be sure that the reset sequence is over.
                //However, it actually takes a few more frames before the mpfBorad reaches the copyright message,
                //so we have to wait a bit.
                if (!isResetOver)
                {
                    resetFrameCounter++;
                    if (resetFrameCounter > resetFrameTarget)
                    {
                        isResetOver = true;
                        resetFrameCounter = 0;
                    }
                }
                //Perform a RST 0x038
                PushStack(PC);
                totalTStates += 7;
                PC = 0x38;
                MemPtr = PC;
            } else    //IM 2
            {
                int ptr = (I << 8) | 0xff;
                PushStack(PC);
                PC = PeekWord(ptr);
                totalTStates += 7;
                MemPtr = PC;
            }
            int deltaT = totalTStates - oldT;
            timeToOutSound += deltaTStates;
            UpdateAudio(deltaT);

        }

    }

}