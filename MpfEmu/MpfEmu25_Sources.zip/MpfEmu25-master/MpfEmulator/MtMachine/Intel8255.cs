﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multitech
{
    class Intel8255
    {
        Byte A;         // WR,RD
        Byte B;         // WR,RD
        Byte C;         // WR,RD
        Byte CONTROL;   // Sólo WR
        Byte DIGIT;     // Puerto virtual 
        int LED_TONE_NEW=0;   // Valor que se acaba de escribir
        int LED_TONE_OLD=0;   // Valor anterior a la escritura
        Boolean LED_UPDATE= false;
        

        enum portMode {

            _in,            // Entrada
            _out,           // Salida
            _bi,            // Entrada / Salida
            _ctrl           // Control
        }

        portMode A_mode;
        portMode B_mode;
        portMode C_mode;


        Byte MODE;      // Modo del chip : 0,1 ,2

        public Intel8255() {

            reset();
            
        }

        public Byte ReadA() { return A; }
        public Byte ReadB() { return B; }
        public Byte ReadC() { return C; }
        public Byte ReadDIGIT() { return DIGIT; }
        public Boolean ledChanged() { return LED_UPDATE; }
        public int ledValue() { return LED_TONE_NEW; }

        public void WriteA(Byte n) { A = n; }
        public void WriteB(Byte n) { B = n; }
        public void WriteC(Byte n) {
            if (C_mode == portMode._out)
            {
                C = n;
                DIGIT = (byte)(C & 0b00111111); // Eliminamos PC7 y PC6
                // Comprobamos si se activa el led ( PC7 == 0)
                //LED_TONE_NEW = (byte)(C & 0b10000000);
                //LED_UPDATE = (LED_TONE_NEW != LED_TONE_OLD);
                //if (LED_UPDATE)
                //{
                //    LED_TONE_OLD = LED_TONE_NEW;
                //}
            }
            else { C = 0xff; }

        }


        public void reset() {
            MODE = 0;
            A = B = C = 0;
            A_mode = B_mode = C_mode = portMode._in;
            LED_UPDATE = false;
            LED_TONE_NEW = LED_TONE_OLD = 0;
            //DIGIT = 0x3F;
        }
        // Escribe en el registro de control
        public void WriteCONTROL(Byte n) {

            CONTROL = n;
            switch (CONTROL) {

                case 0x90:          // CONTROL WORD #8 . A entrada y B,C salidas
                    A_mode = portMode._in;
                    B_mode = portMode._out;
                    C_mode = portMode._out;
                    MODE = 1;
                    break;
                case 0x93:          // CONTROL WORD #1 . Todos los registros entradas
                default:            // RESET . Cualquier otra configuración es igual a reset
                    reset();                
                    break;
            }



        }

    }
}
