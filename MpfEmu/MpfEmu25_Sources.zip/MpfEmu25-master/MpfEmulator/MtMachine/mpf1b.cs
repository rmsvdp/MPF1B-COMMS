﻿using System;
using System.IO;
//using Peripherals;

namespace Multitech
{

    
    //Implements a mpf1b machine
    public class mpf1b : Multitech.zxmachine
    {

        Intel8255 i8255 = new Intel8255();      // Activar el i8255   
        
        public mpf1b(IntPtr handle, bool lateTimingModel)
            : base(handle, lateTimingModel) {
            model = MachineModel._mpf;
            InterruptPeriod = 32;
            FrameLength = 69888;
            clockSpeed = 1.79000;    // Frecuencia real del Microproffesor 1b
            CharRows = 24;
            CharCols = 32;
            ScreenWidth = 256;
            ScreenHeight = 192;
            BorderTopHeight = 48;
            BorderBottomHeight = 56;
            BorderLeftWidth = 48;
            BorderRightWidth = 48;
            DisplayStart = 16384;
            DisplayLength = 6144;
            AttributeStart = 22528;
            AttributeLength = 768;
            borderColour = 7;
            ScanLineWidth = BorderLeftWidth + ScreenWidth + BorderRightWidth;
            TstatesPerScanline = 224;
            TstateAtTop = BorderTopHeight * TstatesPerScanline;
            TstateAtBottom = BorderBottomHeight * TstatesPerScanline;
            tstateToDisp = new short[FrameLength];

            ScreenBuffer = new int[ScanLineWidth * BorderTopHeight //48 lines of border
                                              + ScanLineWidth * ScreenHeight //border + main + border of 192 lines
                                              + ScanLineWidth * BorderBottomHeight]; //56 lines of border

            keyBuffer = new bool[(int)keyCode.LAST];

            attr = new short[DisplayLength]; //6144 bytes of display memory will be mapped
            lastSoundOut = 0;
            soundOut = 0;
            averagedSound = 0;
            soundCounter = 0;
            Reset(true);
        }

        /*
         * Implementa funciones específicas de esta clase
         */ 
        public override void Reset(bool coldBoot) {

            base.isMpf = true;                          // Indicar al core que es un MPF1B
            base.Reset(coldBoot);
            // No hay paginación , cada página se corresponde con un slot de direccionamiento

            PageRDPtr[0] = ROMpage[0];
            PageRDPtr[1] = ROMpage[1];
            PageWRPtr[0] = JunkMemory[0];
            PageWRPtr[1] = JunkMemory[1];
            int j = 2;
            PageEnabled[0] = PageEnabled[1] = true;     // Rom de 4K
            for (int i = 0;i < 30; i++){
                PageRDPtr[j] = RAMpage[i];
                PageWRPtr[j] = RAMpage[i];
                PageEnabled[j] = false;                 // Deshabilitamos todo
                j++;
            }

            // Ahora se implementa el equipamiento de memoria de MPF1B
            PageEnabled[3] = true;      // $1800 a $1fff    Memoria RAM por defecto
            PageEnabled[4] = true;      // $2000 a $27ff    Expansión de 2K de RAM 6116
            i8255.reset();              // Resetear el i8255
            if (coldBoot) PokeByte(0x1fe5, 0); // Inicializa  POWERUP
            Random rand = new Random();
            // TODO - actulizar el display de leds de 7 segmentos
            screen = new byte[8192];        // Asignamos 8K para que no pete
            screenByteCtr = DisplayStart;
            ULAByteCtr = 0;
            ActualULAStart = 14340 - 24 - (TstatesPerScanline * BorderTopHeight) + LateTiming;
            lastTState = ActualULAStart;

        }
 
        public override int In(int port) {
            
            int result = 0xff;

            base.In(port);
            totalTStates++; //T2

            switch (port) {
                //---------------------------------- i8255 Ports
                case 0x00:  // A
                    result = 0xff; // Sin teclado
                    switch (i8255.ReadC()) {        // Capturo la fila
                        // Mapeo la fila con la que yo he construido con el teclado del PC
                        case 0b11111110:
                            result = keyLine[0];
                            break;
                        case 0b11111101:
                            result = keyLine[1];
                            //if (base.keyBuffer[(int)keyCode._6]) {
                            //    result = keyLine[1];
                            //}
                            break;
                        case 0b11111011:
                            result = keyLine[2];
                            break;
                        case 0b11110111:
                            result = keyLine[3];
                            break;
                        case 0b11101111:
                            result = keyLine[4];
                            break;
                        case 0b11011111:
                            result = keyLine[5];
                            break;
                        default:                 
                            break;
                    }    
                    break;
                case 0x01:  // B
                    result = i8255.ReadB();
                    break;
                case 0x02:  // C
                    result = i8255.ReadC();
                    break;
                case 0x03:  // Control
                    break;
                //---------------------------------- z80 CTC Ports
                case 0x40:  // CTC 0
                    break;
                case 0x41:  // CTC 1
                    break;
                case 0x42:  // CTC 2
                    break;
                case 0x43:  // CTC 3
                    break;
                //---------------------------------- z80 PIO Ports
                case 0x80:  // PIO DA
                    break;
                case 0x81:  // PIO DB
                    break;
                case 0x82:  // PIO CA
                    break;
                case 0x83:  // PIO CB
                    break;
            }
            totalTStates += 3;           
            //result = 0xff;// Resultado Dummy mientras se implementa

            // -- Tratamiento de los puertos
            base.In(port, result & 0xff);
            return (result & 0xff);
        }


        public override void Out(int port, int val) {
            base.Out(port, val);

            bool lowBitReset = ((port & 0x01) == 0);
            totalTStates++;
            int _digit = 0;
            int tempTStates = totalTStates;
            int highestTStates = totalTStates;

            switch (port)
            {
                //---------------------------------- i8255 Ports
                case 0x00:  // A                ----       KIN
                    i8255.WriteA((byte)val);
                    break;
                case 0x01:  // B                ----       SEG7
                    i8255.WriteB((byte)val);
                    break;
                case 0x02:  // C                ----       DIGIT
                    i8255.WriteC((byte)val);
                    //if (i8255.ledChanged())
                    //    if (i8255.ledValue() == 0x80) led_tone?.Invoke("ON");
                    //    else led_tone?.Invoke("OFF");
                    break;
                case 0x03:  // Control
                    i8255.WriteCONTROL((byte) val);
                    break;
                //---------------------------------- z80 CTC Ports
                case 0x40:  // CTC 0
                    break;
                case 0x41:  // CTC 1
                    break;
                case 0x42:  // CTC 2
                    break;
                case 0x43:  // CTC 3
                    break;
                //---------------------------------- z80 PIO Ports
                case 0x80:  // PIO DA
                    break;
                case 0x81:  // PIO DB
                    break;
                case 0x82:  // PIO CA
                    break;
                case 0x83:  // PIO CB
                    break;
            }
            totalTStates += 3;
            if (totalTStates > highestTStates)
                highestTStates = totalTStates;

            totalTStates = highestTStates;
        }

        public override bool LoadROM(string path, string file) {
            FileStream fs;
            String filename = path + file;

            //Check if we can find the ROM file!
            try {
                fs = new FileStream(filename, FileMode.Open, FileAccess.Read);
            } catch {
                return false;
            }

            fs = new FileStream(filename, FileMode.Open, FileAccess.Read);
            using (BinaryReader r = new BinaryReader(fs)) {
                // -- Esquema de ROM 4K ----------------------------------------
                byte[] buffer = new byte[4096];
                int bytesRead = r.Read(buffer, 0, 4096);
                if (bytesRead == 0)
                    return false; //something bad happened!

                for (int g = 0; g < 2; g++)
                    for (int f = 0; f < PAGE_SIZE; ++f) {
                        ROMpage[g][f] = (buffer[f + PAGE_SIZE * g]);
                    }
            }
            fs.Close();
            return true;
        }

    }
}