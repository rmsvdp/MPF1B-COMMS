﻿/*
*   Form1 : formulario principal
*   Application.LocalUserAppDataPath + "//"   genera la ruta relativa a la instalación 
*   de la aplicación
*/
#define ENABLE_WM_EXCHANGE

using System;
using System.Drawing;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Multitech;


namespace ZeroWin
{
    public partial class Form1 : Form
    {
#if ENABLE_WM_EXCHANGE

        [StructLayout(LayoutKind.Sequential)]
        private struct COPYDATASTRUCT
        {
            [MarshalAs(UnmanagedType.SysInt)]
            public IntPtr dwData;
            [MarshalAs(UnmanagedType.I4)]
            public int cbData;
            [MarshalAs(UnmanagedType.SysInt)]
            public IntPtr lpData;
        }
        [System.Runtime.InteropServices.DllImport("User32.dll")]
        private static extern bool SendMessage(IntPtr hWnd, int wMsg, IntPtr wParam, IntPtr lParam);

        [System.Runtime.InteropServices.DllImport("User32.dll")]
        private static extern bool PostMessage(IntPtr hWnd, int wMsg, IntPtr wParam, IntPtr lParam);

#if _DEBUG
const string WmCpyDta = "WmCpyDta_d.dll";
#else
        const string WmCpyDta = "WmCpyDta.dll";
#endif

        const int WM_COPYDATA = 0x004A;
        const int WM_USER = 0x8000;
        const int WM_KEYDOWN = 0x100;
        const int WM_KEYUP = 0x101;
        const int WM_SYSCOMMAND = 0x0112;
        const int WM_NCLBUTTONDBLCLK = 0x00A3; //double click on a title bar a.k.a. non-client area of the form
        const int WM_MAXIMIZE = 0xF030;

        IntPtr tempHandle;

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        private struct EMU_STATE
        {
            public int tstates;
            public short PC;
            public short SP;
            public short BC;
            public short DE;
            public short HL;
            public short AF;
            public short _BC;
            public short _DE;
            public short _HL;
            public short _AF;
            public short IX;
            public short IY;
            public byte I;
            public byte R;
            public byte IM;
        }
#endif

        enum EMULATOR_STATE
        {
            IDLE,
            PAUSED,
            RESET,
            PLAYING_RZX,
            RECORDING_RZX,
        }

        private EMULATOR_STATE state = EMULATOR_STATE.IDLE;
        private ZRenderer dxWindow;
        private MonitorRef debugger;
        private Options optionWindow;
        private AboutBox1 aboutWindow;
        private LoadBinary loadBinaryDialog;
        private Mpf1bLayout mpf1bKeyboard;
        public ZeroConfig config = new ZeroConfig();
        private PrecisionTimer timer = new PrecisionTimer();
        public Multitech.zxmachine zx;
        private const int VK_LSHIFT = 0xA0;
        private const int VK_RSHIFT = 0xA1;
        private const int VK_LCTRL = 0xA2;
        private const int VK_RCTRL = 0xA3;
        private const int VK_PRNTSCRN = 0x2C;
        private const int VK_LEFT = 0x25;
        private const int VK_UP = 0x26;
        private const int VK_RIGHT = 0x27;
        private const int VK_DOWN = 0x28;
        private const int VK_ALT = 0xA4;

        //private const string ZX_SPECTRUM_48K = "ZX Spectrum 48k";
        private const string MPF_1B = "Mpf 1b";

        private int frameCount = 0;
        private double lastTime = 0;
        private double frameTime = 0;
        private double totalFrameTime = 0;


        private bool isResizing = false;
        public bool invokeMonitor = false;
        public bool pauseEmulation = false;
        public bool tapeFastLoad = false;
        private Point oldWindowPosition = new Point();
        private int oldWindowSize = -1;
        public String recentFolder = ".";
        private String ZeroSessionSnapshotName = "_z0_session.szx";
      
        private bool romLoaded = false;
        private string[] diskArchivePath = { null, null, null, null };    //Any temp disk file created by the archiver from a .zip file
        private int borderAdjust = 0;

        // Disposición de lectura del teclado
        // El orden se corresponde con el Position Code
        // que devuelve la rutina SCAN1

        public enum keyCode
        {
            _3, _7, _B, _F, _X1, _X2,
            _2, _6, _A, _E, _X3, _X4,
            _1, _5, _9, _D, _STEP, _TPRD,
            _0, _4, _8, _C, _GO, _TPWR,
            _CBR, _PC, _REG, _ADDR, _DEL, _RELA,
            _SBR, _MINUS, _DATA, _PLUS, _INS, _MOVE,
            LAST
        };

        /* Correspondencia del teclado del PC con las teclas del MPF1
         * F1   GO          -       -
         * F2   STEP        +       +
         * F3   REG         S       TPWR
         * F4   PC          L       TPRD
         * F5   ADDR        R       RESET
         * F6   DATA        N.A     MONI
         * F7   CBR         N.A     INTR
         * F8   SBR         N.A     USER KEY
         * F9   RELA
         * F10  DEL
         * F11  INS
         * F12  MOVE
         * 
         */
        private const int SV_LAST_K = 23560; //last pressed key
        private const int SV_FLAGS = 23611;  //bit 5 of FLAGS is set to indicate keypress
        private bool commandLineLaunch = false;
        private byte[] AutoLoadTape48Keys = { 239, 34, 34, 13 }; //LOAD "" + Enter
        public TimeSpan TimeoutToHide { get; private set; }
        public DateTime LastMouseMove { get; private set; }
        public bool CursorIsHidden { get; private set; }



#if ENABLE_WM_EXCHANGE
        unsafe protected override void WndProc(ref Message message)
        {
            if (message.Msg == WM_SYSCOMMAND)
            {
                if (message.WParam == new IntPtr(WM_MAXIMIZE)) 
                {
                    GoFullscreen(true);
                    return;
                }
                else if (message.WParam == new IntPtr(0xF120)) //Restore?
                {
                    GoFullscreen(false);
                    return;
                }
            }
            else if  (message.Msg == WM_NCLBUTTONDBLCLK)
            {
                GoFullscreen(true);
                return;
            }
            else if (message.Msg == WM_COPYDATA)
            {
                COPYDATASTRUCT data = (COPYDATASTRUCT)
                    message.GetLParam(typeof(COPYDATASTRUCT));

                byte[] b = System.BitConverter.GetBytes((int)(data.dwData));
                string str = String.Format("{3}{2}{1}{0}", (char)b[0], (char)b[1], (char)b[2], (char)b[3]);

                if (str == "PAUS")
                {
                    if (!pauseEmulation)
                        PauseEmulation(true);

                    SendWMCOPYDATA("SUAP", message.WParam, (IntPtr)0, 0);
                }
                else if (str == "SNAP")
                {
                    string snapFile = Marshal.PtrToStringAnsi(data.lpData);
                    SendWMCOPYDATA("PANS", message.WParam, (IntPtr)0, 0);
                }
                else if (str == "STEP")
                {
                    tempHandle = message.WParam;

                    PostMessage(this.Handle, WM_USER + 2, message.WParam, data.dwData);
                }
            }
            else if (message.Msg == WM_USER + 2)
            {
                zx.externalSingleStep = true;
                zx.Run();
                zx.UpdateScreenBuffer(zx.FrameLength);
                ForceScreenUpdate();
                EMU_STATE emuState = new EMU_STATE();
                emuState.tstates = zx.totalTStates;
                emuState.PC = (short)zx.PC;
                emuState.SP = (short)zx.SP;
                emuState.IX = (short)zx.IX;
                emuState.IY = (short)zx.IY;
                emuState.HL = (short)zx.HL;
                emuState.DE = (short)zx.DE;
                emuState.BC = (short)zx.BC;
                emuState.AF = (short)zx.AF;
                emuState._HL = (short)zx._HL;
                emuState._DE = (short)zx._DE;
                emuState._BC = (short)zx._BC;
                emuState._AF = (short)zx._AF;
                emuState.I = (byte)zx.I;
                emuState.R = (byte)zx.R;
                emuState.IM = (byte)zx.interruptMode;

                IntPtr lpStruct = Marshal.AllocHGlobal(Marshal.SizeOf(emuState));
                Marshal.StructureToPtr(emuState, lpStruct, false);
                int emuStatSize = Marshal.SizeOf(emuState);
                SendWMCOPYDATA("PETS", tempHandle, lpStruct, emuStatSize);
                Marshal.FreeHGlobal(lpStruct);
                zx.externalSingleStep = false;
            }

            base.WndProc(ref message);

        }

        unsafe private void SendWMCOPYDATA(String s, IntPtr _hTarget, IntPtr _lpData, int _size)
        {
            byte[] carray = System.Text.ASCIIEncoding.UTF8.GetBytes(s);
            uint val = BitConverter.ToUInt32(carray, 0);

            IntPtr dwData = (IntPtr)val;

            COPYDATASTRUCT data = new COPYDATASTRUCT();
            data.dwData = dwData;
            data.cbData = _size;
            data.lpData = _lpData;

            IntPtr lpStruct = Marshal.AllocHGlobal(
                Marshal.SizeOf(data));

            Marshal.StructureToPtr(data, lpStruct, false);

            SendMessage(_hTarget, WM_COPYDATA, this.Handle, lpStruct);
            Marshal.FreeHGlobal(lpStruct);
        }
#endif



        public Form1()
        {
            InitializeComponent();
            toolTip1.Active = false;
            toolTip1.UseAnimation = false;
            toolTip1.UseFading = false;
            toolTip1.ShowAlways = false;          
            toolTip1.IsBalloon = true;//seems to stop the stutter when tooltip appears in fullscreen mode...
            this.Load += new System.EventHandler(this.Form1_Load);
            SetStyle(ControlStyles.UserPaint, true);
            SetStyle(ControlStyles.AllPaintingInWmPaint, true);
            SetStyle(ControlStyles.OptimizedDoubleBuffer, true);
            SetStyle(ControlStyles.Opaque, true);
            TimeoutToHide = TimeSpan.FromSeconds(5);
            panel1.SendToBack();
            this.Icon = ZeroWin.Properties.Resources.ZeroIcon;
        }

        protected override void OnActivated(EventArgs e)
        {
            base.OnActivated(e);
        }

        protected override void OnDeactivate(EventArgs e)
        {
            if (config.PauseOnFocusLost)
                if (!(AppHasFocus()))
                {
                    // pauseEmulation = true;
                }
            base.OnDeactivate(e);
        }

        public static class Native
        {
            [System.Runtime.InteropServices.StructLayout(System.Runtime.InteropServices.LayoutKind.Sequential)]
            public struct Message
            {
                public IntPtr hWnd;
                [System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.U4)]
                public int msg;
                public IntPtr wParam;
                public IntPtr lParam;
                [System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.U4)]
                public uint time;
                public System.Drawing.Point p;
            }
            [return: System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.Bool)]
            [System.Security.SuppressUnmanagedCodeSecurity, System.Runtime.InteropServices.DllImport("User32.dll", CharSet = System.Runtime.InteropServices.CharSet.Auto, SetLastError = true)]
            public static extern bool PeekMessage(out Message msg, IntPtr hWnd,
                [System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.U4)]
                uint messageFilterMin,
                [System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.U4)]
                uint messageFilterMax,
                [System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.U4)]
                uint flags);
            [System.Runtime.InteropServices.DllImport("User32.dll")]
            public static extern IntPtr GetForegroundWindow();
            [System.Runtime.InteropServices.DllImport("user32.dll", CharSet = System.Runtime.InteropServices.CharSet.Auto, ExactSpelling = true)]
            public static extern short GetAsyncKeyState([System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.I4)] int vkey);
        }
        private bool AppStillIdle
        {
            get
            {
                Native.Message msg;
                return !Native.PeekMessage(out msg, IntPtr.Zero, 0, 0, 0);
            }
        }
        public bool AppHasFocus()
        {
            if ((Native.GetForegroundWindow() == this.Handle) )//|| (Native.GetForegroundWindow() == tapeDeck.Handle))
                return true;
            else
                if ((debugger != null) && (!debugger.IsDisposed))
                    if (Native.GetForegroundWindow() == debugger.Handle)
                        return true;
            return false;
        }
        public void ForceScreenUpdate(bool doFullScreen = false)
        {
            if (doFullScreen)
                zx.UpdateScreenBuffer(zx.FrameLength);
            zx.needsPaint = true;
            System.Threading.Thread.Sleep(1);
        }
        private int GetMpfModelIndex(string MpfModel)
        {
            int modelIndex = 0;
            //switch (speccyModel)
            //{
            //    case ZX_SPECTRUM_48K:
            //        modelIndex = 0;
            //        break;

            //    case MPF_1B:
                    modelIndex = 1;
            //        break;
            //}
           return modelIndex;
        }

        public void AddKeywordToEditorBuffer(byte token)
        {
            zx.PokeByteNoContend(SV_LAST_K, token);
            zx.PokeByteNoContend(SV_FLAGS, zx.PeekByteNoContend(SV_FLAGS) | 0x20);
        }
        public void OnApplicationIdle(object sender, EventArgs e)
        {
            while (AppStillIdle && !pauseEmulation)
            {
                TimeSpan elapsed = DateTime.Now - LastMouseMove;
                if (config.FullScreen)
                {
                    if (!CursorIsHidden && (elapsed.TotalSeconds >= TimeoutToHide.TotalSeconds))
                    {
                        Cursor.Hide();
                        CursorIsHidden = true;
                        dxWindow.Focus();
                    }
                }
                lastTime = PrecisionTimer.TimeInMilliseconds();
                if (zx.doRun)      zx.Run();             
                frameTime = PrecisionTimer.TimeInMilliseconds() - lastTime;// timer.DurationInMilliseconds;
                frameCount++;
                totalFrameTime += frameTime;

                if (!config.EnableSound) //we'll try and synch to ~60Hz framerate (50Hz makes it run slightly slower than audio synch)
                {
                    if (frameTime < 19)// && !((zx.tapeIsPlaying && tapeFastLoad)))
                    {
                        double sleepTime = ((19 - frameTime));
                        System.Threading.Thread.Sleep((int)sleepTime);
                    }
                }

                if (config.EnableSound)
                    soundStatusLabel.Image = Properties.Resources.sound_high;
                else
                    soundStatusLabel.Image = Properties.Resources.sound_mute;

                if (!dxWindow.EnableFullScreen && totalFrameTime > 1000.0f)
                {
                       frameCount = 0;
                       totalFrameTime = 0;
                       statusLabelText.Text = "FPS: " + Math.Max(0, dxWindow.averageFPS);
                }
               
                System.Threading.Thread.Sleep(1);
                dxWindow.Invalidate();
            }
        }
        public string GetConfigData(StreamReader sr, string section, string data)
        {
            String readStr = "dummy";

            while (readStr != section)
            {
                if (sr.EndOfStream == true)
                {
                    System.Windows.Forms.MessageBox.Show("Invalid config file!", "Config file error", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Exclamation);
                    return "error";
                }
                readStr = sr.ReadLine();
            }

            while (true)
            {
                readStr = sr.ReadLine();
                if (readStr.IndexOf(data) >= 0)
                    break;
                if (sr.EndOfStream == true)
                {
                    System.Windows.Forms.MessageBox.Show("Invalid config file!", "Config file error", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Exclamation);
                    return "error";
                }
            }

            int startIndex = readStr.IndexOf("=") + 1;
            String dataString = readStr.Substring(startIndex, readStr.Length - startIndex);

            return dataString;
        }
        private bool LoadROM(String romName)
        {
            romName = "\\" + romName;
           
            //First try to load from the path saved in the config file
            romLoaded = zx.LoadROM(config.PathRoms, romName);
            //logger.Log("Booting the speccy ROM...");
            //Next try the application startup path (useful if running off USB)
            if (!romLoaded)
            {
                romLoaded = zx.LoadROM(Application.StartupPath + "\\roms\\", romName);

                //Aha! This worked so update the path in config file
                if (romLoaded)
                    config.PathRoms = Application.StartupPath + "\\roms\\";
            }
            while (!romLoaded)
            {
                System.Windows.Forms.MessageBox.Show("Zero couldn't find a valid ROM file.\nSelect a folder to look for ROMs.",
                            "ROM file missing!", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Exclamation);

                if (folderBrowserDialog1.ShowDialog() == DialogResult.OK)
                {
                    config.PathRoms = folderBrowserDialog1.SelectedPath;
                    romLoaded = zx.LoadROM(config.PathRoms, romName);
                }
                else
                {
                    System.Windows.Forms.MessageBox.Show("Unfortunately, Zero cannot work without a valid ROM file.\nIt will now exit.",
                            "Unable to continue!", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Exclamation);
                    break;
                }
            }

            return romLoaded;
        }


        //#r4#
        // --- Gestion de la pulsación y liberación de teclas--------
        // Correspondencia del teclado del PC con las teclas del MPF1
        /* 
                * F1   GO          -       -
                * F2   STEP        +       +
                * F3   REG         S       TPWR
                * F4   PC          L       TPRD
                * F5   ADDR        N.A     RESET
                * F6   DATA        N.A     MONI
                * F7   CBR         N.A     INTR
                * F8   SBR         N.A     USER KEY
                * F9   RELA
                * F10  DEL
                * F11  INS
                * F12  MOVE
                * 
         */
        //case Keys.Up:        //case Keys.Left:        //case Keys.Right:
        //case Keys.Down:        //case Keys.Back:        //case Keys.Tab:
        //case Keys.Escape:        //case Keys.ControlKey:
        protected override void OnKeyDown(KeyEventArgs keyEvent)
        {
            
            switch (keyEvent.KeyCode)
            {
                case Keys.A:                    zx.keyBuffer[(int)keyCode._A] = true;                    break;
                case Keys.B:                    zx.keyBuffer[(int)keyCode._B] = true;                    break;
                case Keys.C:                    zx.keyBuffer[(int)keyCode._C] = true;                    break;
                case Keys.D:                    zx.keyBuffer[(int)keyCode._D] = true;                    break;
                case Keys.E:                    zx.keyBuffer[(int)keyCode._E] = true;                    break;
                case Keys.F:                    zx.keyBuffer[(int)keyCode._F] = true;                    break;
                case Keys.L:                    zx.keyBuffer[(int)keyCode._TPRD] = true;                 break;
                case Keys.S:                    zx.keyBuffer[(int)keyCode._TPWR] = true;                 break;
                case Keys.D0:                   zx.keyBuffer[(int)keyCode._0] = true;                    break;
                case Keys.D1:                   zx.keyBuffer[(int)keyCode._1] = true;                    break;
                case Keys.D2:                   zx.keyBuffer[(int)keyCode._2] = true;                    break;
                case Keys.D3:                   zx.keyBuffer[(int)keyCode._3] = true;                    break;
                case Keys.D4:                   zx.keyBuffer[(int)keyCode._4] = true;                    break;
                case Keys.D5:                   zx.keyBuffer[(int)keyCode._5] = true;                    break;
                case Keys.D6:                   zx.keyBuffer[(int)keyCode._6] = true;                    break;
                case Keys.D7:                   zx.keyBuffer[(int)keyCode._7] = true;                    break;
                case Keys.D8:                   zx.keyBuffer[(int)keyCode._8] = true;                    break;
                case Keys.D9:                   zx.keyBuffer[(int)keyCode._9] = true;                    break;
                case Keys.OemMinus:             zx.keyBuffer[(int)keyCode._MINUS] = true;                break;
                case Keys.Oemplus:              zx.keyBuffer[(int)keyCode._PLUS] = true;                 break;
                case Keys.F1:                   zx.keyBuffer[(int)keyCode._GO] = true;                   break;
                case Keys.F2:                   zx.keyBuffer[(int)keyCode._STEP] = true;                 break;
                case Keys.F3:                   zx.keyBuffer[(int)keyCode._REG] = true;                  break;
                case Keys.F4:                   zx.keyBuffer[(int)keyCode._PC] = true;                   break;
                case Keys.F5:                   zx.keyBuffer[(int)keyCode._ADDR] = true;                 break;
                case Keys.F6:                   zx.keyBuffer[(int)keyCode._DATA] = true;                 break;
                case Keys.F7:                   zx.keyBuffer[(int)keyCode._CBR] = true;                  break;
                case Keys.F8:                   zx.keyBuffer[(int)keyCode._SBR] = true;                  break;
                case Keys.F9:                   zx.keyBuffer[(int)keyCode._RELA] = true;                 break;
                case Keys.F10:                  zx.keyBuffer[(int)keyCode._DEL] = true;                  break;
                case Keys.F11:                  zx.keyBuffer[(int)keyCode._INS] = true;                  break;
                case Keys.F12:                  zx.keyBuffer[(int)keyCode._MOVE] = true;                 break;
                // Teclas Especiales
                // RESET
                case Keys.R:                    Mpf_SoftReset();                                         break;
                // MONI
                case Keys.M:                    break;
                // INTR
                case Keys.I:                    break;
                // USER KEY
                case Keys.U:                    break;
                default:                        break;
            }
        }
        protected override void OnKeyUp(KeyEventArgs keyEvent)
        {

            switch (keyEvent.KeyCode)
            {
                case Keys.A:                    zx.keyBuffer[(int)keyCode._A] = false;                    break;
                case Keys.B:                    zx.keyBuffer[(int)keyCode._B] = false;                    break;
                case Keys.C:                    zx.keyBuffer[(int)keyCode._C] = false;                    break;
                case Keys.D:                    zx.keyBuffer[(int)keyCode._D] = false;                    break;
                case Keys.E:                    zx.keyBuffer[(int)keyCode._E] = false;                    break;
                case Keys.F:                    zx.keyBuffer[(int)keyCode._F] = false;                    break;
                case Keys.L:                    zx.keyBuffer[(int)keyCode._TPRD] = false;                 break;
                case Keys.S:                    zx.keyBuffer[(int)keyCode._TPWR] = false;                 break;
                case Keys.D0:                   zx.keyBuffer[(int)keyCode._0] = false;                    break;
                case Keys.D1:                   zx.keyBuffer[(int)keyCode._1] = false;                    break;
                case Keys.D2:                   zx.keyBuffer[(int)keyCode._2] = false;                    break;
                case Keys.D3:                   zx.keyBuffer[(int)keyCode._3] = false;                    break;
                case Keys.D4:                   zx.keyBuffer[(int)keyCode._4] = false;                    break;
                case Keys.D5:                   zx.keyBuffer[(int)keyCode._5] = false;                    break;
                case Keys.D6:                   zx.keyBuffer[(int)keyCode._6] = false;                    break;
                case Keys.D7:                   zx.keyBuffer[(int)keyCode._7] = false;                    break;
                case Keys.D8:                   zx.keyBuffer[(int)keyCode._8] = false;                    break;
                case Keys.D9:                   zx.keyBuffer[(int)keyCode._9] = false;                    break;
                case Keys.OemMinus:             zx.keyBuffer[(int)keyCode._MINUS] = false;                break;
                case Keys.Oemplus:              zx.keyBuffer[(int)keyCode._PLUS] = false;                 break;
                case Keys.F1:                   zx.keyBuffer[(int)keyCode._GO] = false;                   break;
                case Keys.F2:                   zx.keyBuffer[(int)keyCode._STEP] = false;                 break;
                case Keys.F3:                   zx.keyBuffer[(int)keyCode._REG] = false;                  break;
                case Keys.F4:                   zx.keyBuffer[(int)keyCode._PC] = false;                   break;
                case Keys.F5:                   zx.keyBuffer[(int)keyCode._ADDR] = false;                 break;
                case Keys.F6:                   zx.keyBuffer[(int)keyCode._DATA] = false;                 break;
                case Keys.F7:                   zx.keyBuffer[(int)keyCode._CBR] = false;                  break;
                case Keys.F8:                   zx.keyBuffer[(int)keyCode._SBR] = false;                  break;
                case Keys.F9:                   zx.keyBuffer[(int)keyCode._RELA] = false;                 break;
                case Keys.F10:                  zx.keyBuffer[(int)keyCode._DEL] = false;                  break;
                case Keys.F11:                  zx.keyBuffer[(int)keyCode._INS] = false;                  break;
                case Keys.F12:                  zx.keyBuffer[(int)keyCode._MOVE] = false;                 break;
                default:                        break;
            }

        }
        protected override void OnPaintBackground(PaintEventArgs e)        {
            //base.OnPaintBackground(e);
        }
        protected override void OnPaint(PaintEventArgs e)        {
            
            //dxWindow.Invalidate();
        }
        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            //Show the confirmation box only if it's not an invalid ROM exit event and not fullscreen
            if (config.ConfirmOnExit && romLoaded && !config.FullScreen)
            {
                if (System.Windows.Forms.MessageBox.Show("Are you sure you want to exit?",
                           "Confirm Exit", System.Windows.Forms.MessageBoxButtons.YesNo,
                           System.Windows.Forms.MessageBoxIcon.Question) == DialogResult.No)

                    e.Cancel = true;
            }
            base.OnFormClosing(e);
        }
        protected override void OnClosed(EventArgs e)
        {
            //logger.Log("Shutting down...", true);

            if ((config != null))                config.Save(); 
            if (dxWindow != null)                dxWindow.Shutdown();
            if (zx != null)                     zx.Shutdown();
            base.OnClosed(e);
        }
        private void Form1_Load(object sender, System.EventArgs e)
        {
            //logger.Log("Starting up...");
            this.BringToFront();
          //Load configuration
            config.ApplicationPath = Application.StartupPath;
            config.Load();
            romLoaded = false;
            recentFolder = config.PathGames;
            //logger.Log("Powering on the speccy...");
            // --- Cargamos de forma directa MPF_1B
            config.Model = MachineModel._mpf;
            zx = new mpf1b(this.Handle, config.UseLateTimings);
            // --- Manejador del display para actualizar en tiempo real
            zx.display += actualiza_display;
            // --- Manejadores de los leds TONE y HALT para actualizar en tiempo real
            zx.led_red += actualiza_led_red;
            zx.led_tone += actualiza_led_tone;
            //zx.Reset();           
            Mpf1bItem1.Checked = true;
            romLoaded = LoadROM(config.currentMpf1bRom);
            if (!romLoaded)
            {
                this.Close();
                return;
            }

            zx.SetSoundVolume(config.Volume / 100.0f);
            zx.SetEmulationSpeed(config.EmulationSpeed);
            try
            {
                //logger.Log("Initializing renderer...");
                dxWindow = new ZRenderer(this, panel1.Width, panel1.Height);
            }
            catch (System.TypeInitializationException dxex)
            {
                MessageBox.Show(dxex.InnerException.Message, "Wrong DirectX version.", MessageBoxButtons.OK);
                return;
            }
            if (config.UseDirectX)     directXToolStripMenuItem_Click(this, null);
            else                       gDIToolStripMenuItem_Click(this, null);
            this.Controls.Add(dxWindow);
            panel1.Enabled = false;
            panel1.Hide();
            panel1.SendToBack();
            dxWindow.BringToFront();
            dxWindow.Focus();
            dxWindow.ShowScanlines = interlaceToolStripMenuItem.Checked = config.EnableInterlacedOverlay;
            dxWindow.PixelSmoothing = config.EnablePixelSmoothing;
            pixelToolStripMenuItem.Checked = config.EnablePixelSmoothing;
            dxWindow.EnableVsync = config.EnableVSync;
            //logger.Log("Initializing render window...");
            config.WindowSize = 0;
            AdjustWindowSize();
            //if (config.FullScreen)   GoFullscreen(true);
            // Starts emulation !
            zx.Start();

        }

        public void actualiza_display(String valor) {
            ss0.Value = valor.Substring(0, 1);
            ss1.Value = valor.Substring(1, 1);
            ss2.Value = valor.Substring(2, 1);
            ss3.Value = valor.Substring(3, 1);
            ss4.Value = valor.Substring(4, 1);
            ss5.Value = valor.Substring(5, 1);
            // Los decimales van invertidos
            ss0.DecimalOn = zx.mpf_dots[5];
            ss1.DecimalOn = zx.mpf_dots[4];
            ss2.DecimalOn = zx.mpf_dots[3];
            ss3.DecimalOn = zx.mpf_dots[2];
            ss4.DecimalOn = zx.mpf_dots[1];
            ss5.DecimalOn = zx.mpf_dots[0];

            zx.dmp = false;                     // No pintar hasta el siguiente SCAN1
           
        }

        public void actualiza_led_tone(String valor) {

            if (valor == "OFF")
            {
                this.ledBeep.On = false;
            }
            else
            {
                this.ledBeep.On = true;
                this.Refresh(); 
            }
            this.Refresh();
            
         }

        public void actualiza_led_red(String valor)
        {
            if (valor == "OFF") this.ledHalt.On = false;
            else this.ledHalt.On = true;
            this.Refresh();
        }

        //Load file
        private void fileButton_Click(object sender, EventArgs e)
        {
            openFileMenuItem1_Click(sender, e);
        }
        private void directXToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //If directX isn't available, try initialising it one more time
            if (!dxWindow.DirectXReady)
                dxWindow.InitDirectX(dxWindow.Width, dxWindow.Height);

            //If we have directX available to us, switch to it.
            if (dxWindow.DirectXReady)
            {
                dxWindow.EnableDirectX = true;
                gDIToolStripMenuItem.Checked = false;
                directXToolStripMenuItem.Checked = true;
                dxWindow.Focus();
                config.UseDirectX = true;
                interlaceToolStripMenuItem.Enabled = true;
                if (interlaceToolStripMenuItem.Checked)
                    dxWindow.ShowScanlines = true;
                else
                    dxWindow.ShowScanlines = false;
            }
            else
            {
                System.Windows.Forms.MessageBox.Show("Zero was unable to switch to DirectX mode.\nIt will now continue in GDI mode.",
                           "DirectX Error", System.Windows.Forms.MessageBoxButtons.OK,
                           System.Windows.Forms.MessageBoxIcon.Exclamation);
                dxWindow.EnableDirectX = false;
                gDIToolStripMenuItem.Checked = true;
                directXToolStripMenuItem.Checked = false;
                dxWindow.Focus();
            }
        }
        private void gDIToolStripMenuItem_Click(object sender, EventArgs e)
        {
            dxWindow.EnableDirectX = false;
            directXToolStripMenuItem.Checked = false;
            gDIToolStripMenuItem.Checked = true;
            dxWindow.Focus();
            config.UseDirectX = false;
            interlaceToolStripMenuItem.Enabled = false;
        }
        private void kToolStripMenuItem_Click(object sender, EventArgs e)
        {
            zx.Reset(false);
            dxWindow.Focus();
        }
        private void kToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            dxWindow.Focus();
        }
        private void kToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            mpf1bToolStripMenuItem_Click(sender, e);
            dxWindow.Focus();
        }
        //100% window size
        private void size100ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (config.FullScreen)
                GoFullscreen(false);

            config.WindowSize = 0;
            AdjustWindowSize();
        }
        protected override bool ProcessDialogKey(Keys keyData)        {            return false;        }
        protected override bool ProcessCmdKey(ref System.Windows.Forms.Message m,System.Windows.Forms.Keys k)
        {
            // detect the pushing (Msg) of Enter Key (k)
            // then process the signal as usual
            return base.ProcessCmdKey(ref m, k);
        }
        //Monitor
        private void monitorButton_Click(object sender, EventArgs e)
        {
            ShouldExitFullscreen();

            if (debugger == null || debugger.IsDisposed)
            {
                //zx.doRun = false;
                debugger = new MonitorRef(this);

                debugger.SetState(MonitorRef.MonitorState.PAUSE);
                debugger.Show();
                //debugger.dbState = Monitor.MonitorState.STEPIN;
            }

            if (!debugger.Visible)
            {
                //zx.doRun = false;
                //debugger.dbState = Monitor.MonitorState.STEPIN;
                debugger.ReSyncWithZX();
                debugger.SetState(MonitorRef.MonitorState.PAUSE);
                debugger.Show();
            }
            debugger.BringToFront();
        }
        //Mpf_1b select
        public void mpf1bToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ChangeMpfModel(MachineModel._mpf);
            config.CurrentMPFModel = MPF_1B;
            Mpf1bItem1.Checked = true;

        }
        private void ChangeMpfModel(MachineModel _model)
        {
            zx.Pause();
            state = EMULATOR_STATE.IDLE;
            dxWindow.Suspend();
            if (debugger != null)
            {
                debugger.DeRegisterAllEvents();
                debugger.DeSyncWithZX();
            }
            zx.Shutdown();
            zx = null;
            System.GC.Collect();
            config.Model = _model;
            Directory.SetCurrentDirectory(Application.StartupPath);

            switch (config.Model)
            {
                case MachineModel._48k:
                case MachineModel._mpf:
                    config.Model = MachineModel._mpf;
                    zx = new mpf1b(this.Handle, config.UseLateTimings);
                    romLoaded = LoadROM(config.CurrentMpf1bROM);      
                    break;
            }
            if (!romLoaded)            {   this.Close();   return;   }
            zx.SetSoundVolume(config.Volume / 100.0f);
            zx.SetEmulationSpeed(config.EmulationSpeed);
            if (!config.EnableSound)       zx.MuteSound(true);
            if (debugger != null)      {  debugger.ReRegisterAllEvents(); debugger.ReSyncWithZX();  }
            dxWindow.Resume();
            dxWindow.Focus();
            zx.Resume();
        }
        //options button
        private void optionsButton_Click(object sender, EventArgs e)
        {
            if ((optionWindow == null) || (optionWindow.IsDisposed))
                optionWindow = new Options(this);
            bool oldPause = pauseEmulation;
            pauseEmulation = true;
            zx.Pause();
            PreOptionsWindowShow();
            if (optionWindow.ShowDialog(this) == DialogResult.OK)  { PostOptionsWindowShow(); }
            pauseEmulation = oldPause;
            zx.Resume();
            dxWindow.Focus();
        }
        private void PreOptionsWindowShow()
        {
            optionWindow.RomToUse48k = config.Current48kROM;
            optionWindow.RomToUse128k = config.CurrentMpf1bROM;
            optionWindow.MpfModel = GetMpfModelIndex(config.CurrentMPFModel);
            optionWindow.UseDirectX = config.UseDirectX;
            optionWindow.EmulationSpeed = config.EmulationSpeed;
            optionWindow.SpeakerSetup = config.StereoSoundOption;
            optionWindow.MaintainAspectRatioInFullScreen = config.MaintainAspectRatioInFullScreen;
            optionWindow.borderSize = config.BorderSize / 24;
            optionWindow.UseLateTimings = config.UseLateTimings;// (zx.LateTiming != 0 ? true : false);
            optionWindow.PauseOnFocusChange = config.PauseOnFocusLost;
            optionWindow.ConfirmOnExit = config.ConfirmOnExit;
            optionWindow.RomPath = config.PathRoms;
            optionWindow.ShowOnScreenLEDS = config.ShowOnscreenIndicators;
            optionWindow.RestoreLastState = config.RestoreLastStateOnStart;

            if (config.FullScreen)
                optionWindow.windowSize = 0;
            else
                optionWindow.windowSize = config.WindowSize / 50 + 1;
        }
        private void PostOptionsWindowShow()
        {

            config.UseLateTimings = (optionWindow.UseLateTimings);
            config.UseDirectX = optionWindow.UseDirectX;
            config.PathRoms = optionWindow.RomPath;
            config.StereoSoundOption = optionWindow.SpeakerSetup;
            config.RestoreLastStateOnStart = optionWindow.RestoreLastState;
            config.ShowOnscreenIndicators = optionWindow.ShowOnScreenLEDS;
            config.MaintainAspectRatioInFullScreen = optionWindow.MaintainAspectRatioInFullScreen;
            dxWindow.ShowScanlines = interlaceToolStripMenuItem.Checked = config.EnableInterlacedOverlay;

            //Remove any previous session info if user doesn't want restore function
            if (!config.RestoreLastStateOnStart)
            {
                if (File.Exists(ZeroSessionSnapshotName))
                    File.Delete(ZeroSessionSnapshotName);
            }

            if (config.UseDirectX)                directXToolStripMenuItem_Click(this, null);
            else                                  gDIToolStripMenuItem_Click(this, null);

            if (config.EmulationSpeed != optionWindow.EmulationSpeed)
            {
                config.EmulationSpeed = optionWindow.EmulationSpeed;
                zx.SetEmulationSpeed(config.EmulationSpeed);
            }
            if ((optionWindow.MpfModel != GetMpfModelIndex(config.CurrentMPFModel))
                 || config.Current48kROM != optionWindow.RomToUse48k
                 || config.currentMpf1bRom != optionWindow.RomToUse128k)
            {
                config.Current48kROM = optionWindow.RomToUse48k;
                config.currentMpf1bRom = optionWindow.RomToUse128k;
                switch (optionWindow.MpfModel)
                {
                    case 0:
                    case 1:
                        mpf1bToolStripMenuItem_Click(this, null);
                        break;
                }
            }

            zx.LateTiming = (config.UseLateTimings ? 1 : 0);
            config.ConfirmOnExit = optionWindow.ConfirmOnExit;
            config.PauseOnFocusLost = optionWindow.PauseOnFocusChange;
            optionWindow.Dispose();
            bool requiresResizeWindow = false;

            //Are we going windowed from fullscreen?
            if (optionWindow.windowSize != 0 && config.FullScreen)
            {
                config.WindowSize = (optionWindow.windowSize - 1) * 50;
                GoFullscreen(config.FullScreen);
            }
            else if (optionWindow.windowSize == 0 && !config.FullScreen) //or the other way
            {
                GoFullscreen(config.FullScreen);
            }
            else if (optionWindow.windowSize > 0 && (config.WindowSize != (optionWindow.windowSize - 1) * 50)) //or diff window size from previous
            {
                config.WindowSize = (optionWindow.windowSize - 1) * 50;
                requiresResizeWindow = true;
            }
            if (requiresResizeWindow)           AdjustWindowSize();
            dxWindow.PixelSmoothing = config.EnablePixelSmoothing;
        }
        //Need this to command the windows explorer shell to refresh icon cache
        [System.Runtime.InteropServices.DllImport("shell32.dll")]
        private static extern void SHChangeNotify(int eventId, int flags, IntPtr item1, IntPtr item2);
        
        private void aboutButton_Click(object sender, EventArgs e)
        {
            if ((aboutWindow == null) || (aboutWindow.IsDisposed))
                aboutWindow = new AboutBox1(this);
            aboutWindow.ShowDialog(this);
            dxWindow.Focus();
            aboutWindow.Dispose();
        }
        private void label1_Click(object sender, EventArgs e)   {  dxWindow.Focus();  }
        private void toolStripMenuItem5_Click(object sender, EventArgs e)
        {
            zx.Reset(false);
            dxWindow.Focus();
        }
        private void renderingToolStripMenuItem_Paint(object sender, PaintEventArgs e)        {        }
        //power off
        private void powerButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Mpf_SoftReset()
        {
            state = EMULATOR_STATE.IDLE;

            dxWindow.Suspend();

            if (debugger != null)
            {
                debugger.DeRegisterAllEvents();
                debugger.DeSyncWithZX();
            }
            zx.Reset(false);
            if (debugger != null)
            {
                debugger.ReRegisterAllEvents();
                debugger.ReSyncWithZX();
            }
            dxWindow.Resume();
            dxWindow.Focus();
        }

        private void hardResetToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            state = EMULATOR_STATE.IDLE;

            dxWindow.Suspend();

            if (debugger != null)
            {
                debugger.DeRegisterAllEvents();
                debugger.DeSyncWithZX();
            }
            zx.Reset(true);         
            if (debugger != null)
            {
                debugger.ReRegisterAllEvents();
                debugger.ReSyncWithZX();
            }
            dxWindow.Resume();
            dxWindow.Focus();
        }
        public void ShouldExitFullscreen()
        {
            if (dxWindow.EnableDirectX && config.FullScreen)
                GoFullscreen(false);
        }
        private void GoFullscreen(bool full)
        {
            config.FullScreen = full;
           
            if (full)
            {
                toolStrip1.Visible = false;
                statusStrip1.Visible = false;
                toolStripMenuItem5.Enabled = false;
                toolStripMenuItem1.Enabled = false;
                LastMouseMove = DateTime.Now;
                this.SuspendLayout();
                this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
                oldWindowPosition = this.Location;
                dxWindow.EnableFullScreen = true;
                oldWindowSize = config.WindowSize;
                config.WindowSize = 0;

                if (dxWindow.EnableDirectX)
                {
                    menuStrip1.Visible = false;
                    dxWindow.InitDirectX(Screen.FromControl(this).Bounds.Width, Screen.FromControl(this).Bounds.Height, false);
                }
                else
                {
                    this.Location = new Point(0, 0);
                    this.WindowState = FormWindowState.Maximized;
                    dxWindow.Location = new Point(0, 0);
                    dxWindow.SetSize(Screen.PrimaryScreen.Bounds.Width, Screen.PrimaryScreen.Bounds.Height);
                }

                if (!commandLineLaunch)
                {
                    Point cursorPos = Cursor.Position;
                    cursorPos.Y = this.PointToScreen(dxWindow.Location).Y;
                    Cursor.Position = cursorPos;
                }
                else
                {
                    Cursor.Hide();
                    CursorIsHidden = true;
                    Cursor.Position = new Point(0, Screen.PrimaryScreen.Bounds.Height);
                }
                this.ResumeLayout();
                dxWindow.Focus();
            }
            else
            {
                menuStrip1.Visible = true;
                toolStrip1.Visible = true;
                statusStrip1.Visible = true;
                toolStripMenuItem5.Enabled = true;
                toolStripMenuItem1.Enabled = true;
                this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Sizable;
                this.WindowState = FormWindowState.Normal;

                dxWindow.EnableFullScreen = false;
                this.Location = oldWindowPosition;
                config.WindowSize = oldWindowSize;
                AdjustWindowSize();

                if (CursorIsHidden)
                {
                    Cursor.Show();
                    CursorIsHidden = false;
                }
            }
        }
        private void fullScreenToolStripMenuItem_Click(object sender, EventArgs e)
        {
            GoFullscreen(!config.FullScreen);
        }
        private void PauseEmulation(bool val)
        {
            pauseEmulation = val;
            dxWindow.EmulationIsPaused = val;
            dxWindow.Invalidate();
            toolStripMenuItem6.Checked = val;
            toolStripButton4.Checked = val;

            if (pauseEmulation)
            {
                statusLabelText.Text = "Emulation Paused";
                zx.Pause();

            }
            else
            {
                statusLabelText.Text = "Ready";
                zx.Resume();
            }
        }
        private void pauseEmulationESCToolStripMenuItem_Click(object sender, EventArgs e)
        {
            PauseEmulation(!pauseEmulation);
        }
        private void quitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            powerButton_Click(this, null);
        }
        private void interlaceToolStripMenuItem_Click(object sender, EventArgs e)
        {
            dxWindow.ShowScanlines = interlaceToolStripMenuItem.Checked;
            config.EnableInterlacedOverlay = dxWindow.ShowScanlines;
        }
        private void loadBinaryMenuItem1_Click(object sender, EventArgs e)
        {
            loadBinaryDialog = new LoadBinary(this, true);
            loadBinaryDialog.Show();
        }
        private void saveBinaryMenuItem5_Click(object sender, EventArgs e)
        {
            loadBinaryDialog = new LoadBinary(this, false);
            loadBinaryDialog.Show();
        }
        public void openFileMenuItem1_Click(object sender, EventArgs e)        {
            // Load Binary
            loadBinaryMenuItem1_Click(sender, e);
        }
        //The app window, including the emulator window and all the buttons, panels et al
        private void AdjustWindowSize()
        {
            //fullScreenToolStripMenuItem.Checked = false;

            int _offsetX = zx.GetOriginOffsetX();
            int _offsetY = zx.GetOriginOffsetY();
            int speccyWidth = zx.GetTotalScreenWidth() - _offsetX;
            int speccyHeight = zx.GetTotalScreenHeight() - _offsetY;
            int dxWindowOffsetX = 10;
            int dxWindowOffsetY = toolStrip1.Location.Y + toolStrip1.Height;

            Rectangle screenRectangle = RectangleToScreen(this.ClientRectangle);

            int titleHeight = screenRectangle.Top - this.Top;
            int totalClientWidth = speccyWidth + dxWindowOffsetX;
            int totalClientHeight = speccyHeight + dxWindowOffsetY + statusStrip1.Height + titleHeight;
            int adjustWidth = (speccyWidth * config.WindowSize / 100);
            int adjustHeight = (speccyHeight * config.WindowSize / 100);

            borderAdjust = config.BorderSize + config.BorderSize * (config.WindowSize / 100);

            this.Size = new Size(totalClientWidth + adjustWidth - (2 * borderAdjust) + _offsetX * 2, totalClientHeight + adjustHeight - (2 * borderAdjust));
            dxWindow.Location = new Point(_offsetX - borderAdjust, dxWindowOffsetY - _offsetY - borderAdjust);
            dxWindow.SetSize(zx.GetTotalScreenWidth() + adjustWidth, zx.GetTotalScreenHeight() + adjustHeight);
            dxWindow.SendToBack();
            dxWindow.LEDIndicatorPosition = new Point(dxWindow.Location.X, dxWindow.Location.Y);
            dxWindow.Focus();
            dxWindow.Invalidate();

            Rectangle workingArea = Screen.GetWorkingArea(this);

            if ((totalClientWidth + (speccyWidth * (config.WindowSize + 50)) / 100 - (2 * borderAdjust) >= workingArea.Width) ||
                ((totalClientHeight + (speccyHeight * (config.WindowSize + 50)) / 100 - (2 * borderAdjust)) >= workingArea.Height))
            {
                toolStripMenuItem5.Enabled = false;
            }
            else
            {
                if (config.WindowSize >= 500)
                    toolStripMenuItem5.Enabled = false;
                else
                    toolStripMenuItem5.Enabled = true;
            }

            if (config.WindowSize == 0)
                toolStripMenuItem1.Enabled = false;
            else
                toolStripMenuItem1.Enabled = true;
        }
        private void toolStripMenuItem5_Click_1(object sender, EventArgs e)
        {
            if (!toolStripMenuItem5.Enabled)
            {
                MessageBox.Show("Emulator window cannot be resized beyond your monitor's maximum screen dimensions.", "Window Size", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            config.WindowSize += 50; //Increase window size by 50% of normal

            AdjustWindowSize();
        }
        private void panel4_Paint(object sender, PaintEventArgs e)
        {
            //e.Graphics.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.NearestNeighbor;
            //e.Graphics.DrawImage(panel4.BackgroundImage, panel4.Location.X, panel4.Location.Y, panel4.Width, panel4.Height);
        }
        private void panel5_Paint(object sender, PaintEventArgs e)
        {
            // e.Graphics.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.NearestNeighbor;
            // e.Graphics.DrawImage(ZiggyWin.Properties.Resources.rightPane11, panel5.Location.X, panel5.Location.Y, panel5.Width, panel5.Height);
        }
        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {
            if (!toolStripMenuItem1.Enabled)
                return;
            if (config.WindowSize > 0)
                config.WindowSize -= 50;

            AdjustWindowSize();
        }
        private Region GetRegion(Bitmap _img, Color color)
        {
            Color _matchColor = Color.FromArgb(color.R, color.G, color.B);
            System.Drawing.Region rgn = new Region();
            rgn.MakeEmpty();
            Rectangle rc = new Rectangle(0, 0, 0, 0);
            bool inimage = false;

            for (int y = 0; y < _img.Height; y++)
            {
                for (int x = 0; x < _img.Width; x++)
                {
                    Color imgPixel = _img.GetPixel(x, y);
                    if (!inimage)
                    {
                        if (imgPixel != _matchColor)
                        {
                            inimage = true;
                            rc.X = x;
                            rc.Y = y;
                            rc.Height = 1;
                        }
                    }
                    else
                    {
                        if (imgPixel == _matchColor)
                        {
                            inimage = false;
                            rc.Width = x - rc.X;
                            rgn.Union(rc);
                        }
                    }
                }

                if (inimage)
                {
                    inimage = false;
                    rc.Width = _img.Width - rc.X;
                    rgn.Union(rc);
                }
            }
            return rgn;
        }
        private void pictureBox1_Click(object sender, EventArgs e)
        {
            if ((aboutWindow == null) || (aboutWindow.IsDisposed))
                aboutWindow = new AboutBox1(this);
            aboutWindow.ShowDialog(this);
            dxWindow.Focus();
        }
        private void aboutZeroToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (aboutWindow == null)
                aboutWindow = new AboutBox1(this);
            aboutWindow.ShowDialog(this);
            dxWindow.Focus();
        }
        private void pixelToolStripMenuItem_Click(object sender, EventArgs e)
        {
            dxWindow.PixelSmoothing = pixelToolStripMenuItem.Checked;
            config.EnablePixelSmoothing = dxWindow.PixelSmoothing;
        }
        private void toolStripMenuItem3_Click(object sender, EventArgs e)
        {
            ShouldExitFullscreen();

            if (mpf1bKeyboard == null || mpf1bKeyboard.IsDisposed)
                mpf1bKeyboard = new Mpf1bLayout(this);

            mpf1bKeyboard.Show();
            mpf1bKeyboard.BringToFront();
        }
        private void insertBookmarkToolStripMenuItem_Click(object sender, EventArgs e)        {        }
        private void contextMenuStrip2_Opening(object sender, System.ComponentModel.CancelEventArgs e)        {        }
        private void toolStripSeparator13_Click(object sender, EventArgs e)        {        }
        private void soundStatusLabel_Click(object sender, EventArgs e)
        {
            zx.MuteSound(config.EnableSound);
            config.EnableSound = !config.EnableSound;
        }
        private void Form1_Resize(object sender, EventArgs e)
        {
            if (!config.FullScreen && isResizing)
                dxWindow.SetSize(panel1.Width, panel1.Height);
        }
        private void Form1_ResizeBegin(object sender, EventArgs e)        {  isResizing = true;        }
        private void Form1_ResizeEnd(object sender, EventArgs e)          {  isResizing = false;       }
        private void button1_Click(object sender, EventArgs e)
        {
            String keys = "row 0: " + Convert.ToString(zx.keyLine[0],2).PadLeft(8, '0') + " \n";
            keys = keys + "row 1: " + Convert.ToString(zx.keyLine[1], 2).PadLeft(8, '0') + " \n";
            keys = keys + "row 2: " + Convert.ToString(zx.keyLine[2], 2).PadLeft(8, '0') + " \n";
            keys = keys + "row 3: " + Convert.ToString(zx.keyLine[3], 2).PadLeft(8, '0') + " \n";
            keys = keys + "row 4: " + Convert.ToString(zx.keyLine[4], 2).PadLeft(8, '0') + " \n";
            keys = keys + "row 5: " + Convert.ToString(zx.keyLine[5], 2).PadLeft(8, '0') + " \n";
            MessageBox.Show(keys);
            ledBeep.On = true;
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            loadBinaryDialog = new LoadBinary(this, false);
            loadBinaryDialog.Show();
        }

        // Simula tecla RESET
        private void toolStripMenuItem3_Click_1(object sender, EventArgs e)
        {
            Mpf_SoftReset();
        }
    }
}