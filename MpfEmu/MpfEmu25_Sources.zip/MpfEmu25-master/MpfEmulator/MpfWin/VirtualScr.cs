﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
//using System.Threading.Tasks;
using System.Windows.Forms;
using Multitech;

namespace ZeroWin
{
    public partial class VirtualScr : Form
    {
        
        public VirtualScr(MonitorRef _monitor)
        {
            InitializeComponent();
            
        }

        public void RefreshData(Bitmap SnapCX,int BorderColor)   // Metodo para refrescar la pantalla con el bitmap generado
        {
            //int BorderColor;
            int[,] RGB = new int[8, 4] 
            {
                {0xFF,0x00,0x00,0x00}, // Negro
                {0xFF,0x00,0x00,0xC0}, // Azul
                {0xFF,0xC0,0x00,0x00}, // Rojo
                {0xFF,0xC0,0x00,0xC0}, // Magenta
                {0xFF,0x00,0xC0,0x00}, // Verde
                {0xFF,0x00,0xC0,0xC0}, // Cian
                {0xFF,0xC0,0xC0,0x00}, // Amarillo
                {0xFF,0xC0,0xC0,0xC0}, // Blanco
            };

            
            this.BackColor = System.Drawing.Color.FromArgb(RGB[BorderColor, 0], RGB[BorderColor, 1], RGB[BorderColor, 2], RGB[BorderColor, 3]);
            pictureBox1.Image = SnapCX;
            
            
        }

        private void VirtualScr_FormClosing(object sender, FormClosingEventArgs e)
        {
            MessageBox.Show("Closing Virtual Screen");
            pictureBox1= null;
        }

        private void VirtualScr_Load(object sender, EventArgs e)
        {

        }
    }


}