﻿using System;
using System.Windows.Forms;

namespace ZeroWin
{
    public partial class Options : Form
    {
        private Form1 zwRef;
        private int currentModelIndex = -1;
        private string current48kRom = "";
        private string current128kRom = "";
        private bool stereoSound = true;

        #region Accessors

         public int EmulationSpeed {
            get {
                return emulationSpeedTrackBar.Value;
            }
            set {
                emulationSpeedTrackBar.Value = value;
            }
        }

        public bool RestoreLastState {
            get { return lastStateCheckbox.Checked; }
            set { lastStateCheckbox.Checked = value; }
        }

        public bool ShowOnScreenLEDS {
            get { return onScreenLEDCheckbox.Checked; }
            set { onScreenLEDCheckbox.Checked = value; }
        }

        public int SpeakerSetup {
            get {
                if (!stereoRadioButton.Checked)
                    return 0;

                if (acbRadioButton.Checked)
                    return 1;

                return 2;
            }
            set {
                if (value == 0) {
                    stereoRadioButton.Checked = false;
                    monoRadioButton.Checked = true;
                } else {
                    stereoRadioButton.Checked = true;
                    monoRadioButton.Checked = false;

                    if (value == 1) {
                        acbRadioButton.Checked = true;
                        abcRadioButton.Checked = false;
                    } else {
                        acbRadioButton.Checked = false;
                        abcRadioButton.Checked = true;
                    }
                }
            }
        }

        public bool EnableStereoSound {
            get { return stereoSound; }
            set {
                stereoSound = value;
                stereoRadioButton.Checked = value;
                monoRadioButton.Checked = !value;
            }
        }

        public String RomPath {
            get { return romPathTextBox.Text; }
            set { romPathTextBox.Text = value; }
        }

        public String RomToUse48k {
            get { return current48kRom; }
            set { current48kRom = value; }
        }

        public String RomToUse128k {
            get { return current128kRom; }
            set { current128kRom = value; }
        }

        //public int MpfModel {
        //    get { return modelComboBox.SelectedIndex; }
        //    set { modelComboBox.SelectedIndex = value; }
        //}
        public int MpfModel = 1;

        //public bool InterlacedMode {
        //    get { return interlaceCheckBox.Checked; }
        //    set { interlaceCheckBox.Checked = value; }
        //}

        //public bool PixelSmoothing {
        //    get { return pixelSmoothingCheckBox.Checked; }
        //    set { pixelSmoothingCheckBox.Checked = value; }
        //}

        //public bool EnableVSync {
        //    get { return vsyncCheckbox.Checked; }
        //    set { vsyncCheckbox.Checked = value; }
        //}

        public bool UseDirectX {
            get {
                return directXRadioButton.Checked;
            }
            set {
                if (value == true) {
                    directXRadioButton.Checked = true;
                    gdiRadioButton.Checked = false;
                    interlaceCheckBox.Enabled = true;
                    pixelSmoothingCheckBox.Enabled = true;
                    vsyncCheckbox.Enabled = true;
                } else {
                    directXRadioButton.Checked = false;
                    gdiRadioButton.Checked = true;
                    interlaceCheckBox.Enabled = false;
                    pixelSmoothingCheckBox.Enabled = false;
                    vsyncCheckbox.Enabled = false;
                }
            }
        }

        public int borderSize {
            get { return borderSizeComboBox.SelectedIndex; }
            set { borderSizeComboBox.SelectedIndex = value; }
        }

        public int windowSize {
            get { return windowSizeComboBox.SelectedIndex; }
            set { windowSizeComboBox.SelectedIndex = value; }
        }

        public bool UseLateTimings {
            get { return timingCheckBox.Checked; }
            set { timingCheckBox.Checked = value; }
        }

        public bool PauseOnFocusChange {
            get { return pauseCheckBox.Checked; }
            set { pauseCheckBox.Checked = value; }
        }

        public bool ConfirmOnExit {
            get { return exitConfirmCheckBox.Checked; }
            set { exitConfirmCheckBox.Checked = value; }
        }

        public bool MaintainAspectRatioInFullScreen
        {
            get { return aspectRatioFullscreenCheckBox.Checked; }
            set { aspectRatioFullscreenCheckBox.Checked = value; }
        }

        #endregion Accessors

        public Options(Form1 parentRef) {
            InitializeComponent();
            // Set the default dialog font on each child control
            foreach (Control c in Controls) {
                c.Font = new System.Drawing.Font(System.Drawing.SystemFonts.MessageBoxFont.FontFamily, c.Font.Size);
            }
            zwRef = parentRef;
        }

        private void Options_Load(object sender, EventArgs e) {
            this.Location = new System.Drawing.Point(zwRef.Location.X + 20, zwRef.Location.Y + 20);
            if (UseDirectX) {
                interlaceCheckBox.Enabled = true;
                pixelSmoothingCheckBox.Enabled = true;
            } else {
                interlaceCheckBox.Enabled = false;
                pixelSmoothingCheckBox.Enabled = false;
            }
        }

        private void romBrowseButton_Click(object sender, EventArgs e) {
            openFileDialog1.InitialDirectory = RomPath;
            openFileDialog1.Title = "Choose a ROM";
            openFileDialog1.FileName = "";
            openFileDialog1.Filter = "All supported files|*.rom;";
            if (openFileDialog1.ShowDialog() == DialogResult.OK) {
                romTextBox.Text = openFileDialog1.SafeFileName;
                switch (currentModelIndex) {
                    case 0:
                        current48kRom = romTextBox.Text;
                        break;

                    case 1:
                        current128kRom = romTextBox.Text;
                        break;
                }
            }
        }
        private void romPathButton_Click(object sender, EventArgs e) {
            if (folderBrowserDialog1.ShowDialog() == DialogResult.OK) {
                String romInUse = "";
                switch (currentModelIndex) {
                    case 0:
                        romInUse = RomToUse48k;
                        break;

                    case 1:
                        romInUse = RomToUse128k;
                        break;
                }
                if (!System.IO.File.Exists(folderBrowserDialog1.SelectedPath + "\\" + romInUse)) {
                    System.Windows.Forms.MessageBox.Show("The current ROM couldn't be found in this path.\n\nEnsure this path is correct, or specify a new ROM \nin the Hardware section.",
                             "File Warning", System.Windows.Forms.MessageBoxButtons.OK,
                             System.Windows.Forms.MessageBoxIcon.Warning);
                }

                RomPath = folderBrowserDialog1.SelectedPath;
            }
        }

        private void defaultSettingsButton_Click(object sender, EventArgs e) {
            if (System.Windows.Forms.MessageBox.Show("This will cause you to lose all your current settings!\nAre you sure you want to revert to default settings?",
                          "Confirm settings reset", System.Windows.Forms.MessageBoxButtons.YesNo,
                          System.Windows.Forms.MessageBoxIcon.Question) == DialogResult.Yes) {

                #region old default method

              

                #endregion old default method

                ZeroConfig defCon = new ZeroConfig();
                RomToUse48k = defCon.Current48kROM;
                RomToUse128k = defCon.CurrentMpf1bROM;
                //Don't revert path to defaults, since there is no default path.
                //Instead try to use application start up path.
                RomPath = Application.StartupPath + "\\roms";
                string model = defCon.CurrentMPFModel;
                //switch (model) {
                //    case "ZX Spectrum 48k":
                //        MpfModel = 0;
                //        break;

                //    case "Mpf 1b":
                        MpfModel = 1;
                //        break;
                //}
                UseDirectX = defCon.UseDirectX;
                borderSize = defCon.BorderSize;
                PauseOnFocusChange = defCon.PauseOnFocusLost;
                ConfirmOnExit = defCon.ConfirmOnExit;
                UseLateTimings = defCon.UseLateTimings;
                RestoreLastState = defCon.RestoreLastStateOnStart;
                EmulationSpeed = defCon.EmulationSpeed;
                ShowOnScreenLEDS = defCon.ShowOnscreenIndicators;
            }
        }

        //private void modelComboBox_SelectedIndexChanged(object sender, EventArgs e) {
        //    switch (currentModelIndex) {
        //        case 0:
        //            current48kRom = romTextBox.Text;
        //            break;

        //        case 1:
        //            current128kRom = romTextBox.Text;
        //            break;
        //    }

        //    switch (modelComboBox.SelectedIndex) {
        //        case 0:
        //            romTextBox.Text = current48kRom;
        //            break;

        //        case 1:
        //            romTextBox.Text = current128kRom;
        //            break;
        //    }

        //    currentModelIndex = modelComboBox.SelectedIndex;
        //}

        private void checkBox3_CheckedChanged(object sender, EventArgs e) {        }

        private void stereoRadioButton_CheckedChanged(object sender, EventArgs e) {
            monoRadioButton.Checked = !stereoRadioButton.Checked;
        }

        private void monoRadioButton_CheckedChanged(object sender, EventArgs e) {
            stereoRadioButton.Checked = !monoRadioButton.Checked;
        }

        private void tabControl1_TabIndexChanged(object sender, EventArgs e) {        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e) {        }

        private void emulationSpeedTrackBar_Scroll(object sender, EventArgs e) {
            toolTip1.SetToolTip(emulationSpeedTrackBar, "Speed  " + emulationSpeedTrackBar.Value + "%");
        }

        private void lastStateCheckbox_CheckedChanged(object sender, EventArgs e) {
        }

        private void directXRadioButton_CheckedChanged(object sender, EventArgs e) {
            interlaceCheckBox.Enabled = true;
            pixelSmoothingCheckBox.Enabled = true;
            vsyncCheckbox.Enabled = true;
        }

        private void gdiRadioButton_CheckedChanged(object sender, EventArgs e) {
            interlaceCheckBox.Enabled = false;
            pixelSmoothingCheckBox.Enabled = false;
            vsyncCheckbox.Enabled = false;
        }

    }
}