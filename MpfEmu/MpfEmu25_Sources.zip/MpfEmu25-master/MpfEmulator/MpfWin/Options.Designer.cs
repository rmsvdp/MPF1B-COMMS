﻿namespace ZeroWin
{
    partial class Options
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Options));
            this.Debbuger = new System.Windows.Forms.TabControl();
            this.hwPage = new System.Windows.Forms.TabPage();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.timingCheckBox = new System.Windows.Forms.CheckBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.romBrowseButton = new System.Windows.Forms.Button();
            this.romTextBox = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.aspectRatioFullscreenCheckBox = new System.Windows.Forms.CheckBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.windowSizeComboBox = new System.Windows.Forms.ComboBox();
            this.borderSizeComboBox = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.vsyncCheckbox = new System.Windows.Forms.CheckBox();
            this.pixelSmoothingCheckBox = new System.Windows.Forms.CheckBox();
            this.interlaceCheckBox = new System.Windows.Forms.CheckBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.gdiRadioButton = new System.Windows.Forms.RadioButton();
            this.directXRadioButton = new System.Windows.Forms.RadioButton();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.abcRadioButton = new System.Windows.Forms.RadioButton();
            this.acbRadioButton = new System.Windows.Forms.RadioButton();
            this.label20 = new System.Windows.Forms.Label();
            this.pictureBox10 = new System.Windows.Forms.PictureBox();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.monoRadioButton = new System.Windows.Forms.RadioButton();
            this.stereoRadioButton = new System.Windows.Forms.RadioButton();
            this.pictureBox11 = new System.Windows.Forms.PictureBox();
            this.label19 = new System.Windows.Forms.Label();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.groupBox13 = new System.Windows.Forms.GroupBox();
            this.label33 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.emulationSpeedTrackBar = new System.Windows.Forms.TrackBar();
            this.label30 = new System.Windows.Forms.Label();
            this.pictureBox15 = new System.Windows.Forms.PictureBox();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.onScreenLEDCheckbox = new System.Windows.Forms.CheckBox();
            this.lastStateCheckbox = new System.Windows.Forms.CheckBox();
            this.Use128keCheckbox = new System.Windows.Forms.CheckBox();
            this.exitConfirmCheckBox = new System.Windows.Forms.CheckBox();
            this.pauseCheckBox = new System.Windows.Forms.CheckBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.gamePathButton = new System.Windows.Forms.Button();
            this.gamePathTextBox = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.label13 = new System.Windows.Forms.Label();
            this.romPathButton = new System.Windows.Forms.Button();
            this.romPathTextBox = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.tabControl2 = new System.Windows.Forms.TabControl();
            this.tabPage8 = new System.Windows.Forms.TabPage();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.label34 = new System.Windows.Forms.Label();
            this.mouseLabel = new System.Windows.Forms.Label();
            this.mouseTrackBar = new System.Windows.Forms.TrackBar();
            this.pictureBox13 = new System.Windows.Forms.PictureBox();
            this.mouseCheckBox = new System.Windows.Forms.CheckBox();
            this.label25 = new System.Windows.Forms.Label();
            this.tabPage9 = new System.Windows.Forms.TabPage();
            this.groupBox14 = new System.Windows.Forms.GroupBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.defaultSettingsButton = new System.Windows.Forms.Button();
            this.folderBrowserDialog1 = new System.Windows.Forms.FolderBrowserDialog();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.Debbuger.SuspendLayout();
            this.hwPage.SuspendLayout();
            this.groupBox6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.tabPage2.SuspendLayout();
            this.groupBox5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.tabPage4.SuspendLayout();
            this.groupBox11.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
            this.groupBox10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).BeginInit();
            this.tabPage1.SuspendLayout();
            this.groupBox13.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.emulationSpeedTrackBar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).BeginInit();
            this.groupBox7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            this.tabPage3.SuspendLayout();
            this.groupBox8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            this.tabPage5.SuspendLayout();
            this.tabControl2.SuspendLayout();
            this.tabPage6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.mouseTrackBar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).BeginInit();
            this.tabPage9.SuspendLayout();
            this.groupBox14.SuspendLayout();
            this.SuspendLayout();
            // 
            // Debbuger
            // 
            this.Debbuger.Controls.Add(this.hwPage);
            this.Debbuger.Controls.Add(this.tabPage2);
            this.Debbuger.Controls.Add(this.tabPage4);
            this.Debbuger.Controls.Add(this.tabPage1);
            this.Debbuger.Controls.Add(this.tabPage3);
            this.Debbuger.Controls.Add(this.tabPage5);
            this.Debbuger.Controls.Add(this.tabPage9);
            this.Debbuger.Location = new System.Drawing.Point(11, 11);
            this.Debbuger.Margin = new System.Windows.Forms.Padding(4);
            this.Debbuger.Name = "Debbuger";
            this.Debbuger.SelectedIndex = 0;
            this.Debbuger.Size = new System.Drawing.Size(555, 516);
            this.Debbuger.TabIndex = 0;
            this.Debbuger.TabIndexChanged += new System.EventHandler(this.tabControl1_TabIndexChanged);
            // 
            // hwPage
            // 
            this.hwPage.Controls.Add(this.groupBox6);
            this.hwPage.Controls.Add(this.groupBox1);
            this.hwPage.Location = new System.Drawing.Point(4, 25);
            this.hwPage.Margin = new System.Windows.Forms.Padding(4);
            this.hwPage.Name = "hwPage";
            this.hwPage.Padding = new System.Windows.Forms.Padding(4);
            this.hwPage.Size = new System.Drawing.Size(547, 487);
            this.hwPage.TabIndex = 0;
            this.hwPage.Text = "Hardware";
            this.hwPage.UseVisualStyleBackColor = true;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.label4);
            this.groupBox6.Controls.Add(this.pictureBox6);
            this.groupBox6.Controls.Add(this.timingCheckBox);
            this.groupBox6.Location = new System.Drawing.Point(12, 186);
            this.groupBox6.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox6.Size = new System.Drawing.Size(517, 155);
            this.groupBox6.TabIndex = 7;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Timing";
            // 
            // label4
            // 
            this.label4.Location = new System.Drawing.Point(80, 23);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(429, 64);
            this.label4.TabIndex = 4;
            this.label4.Text = resources.GetString("label4.Text");
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = global::ZeroWin.Properties.Resources.time;
            this.pictureBox6.Location = new System.Drawing.Point(8, 23);
            this.pictureBox6.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(55, 57);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox6.TabIndex = 3;
            this.pictureBox6.TabStop = false;
            // 
            // timingCheckBox
            // 
            this.timingCheckBox.AutoSize = true;
            this.timingCheckBox.Location = new System.Drawing.Point(84, 110);
            this.timingCheckBox.Margin = new System.Windows.Forms.Padding(4);
            this.timingCheckBox.Name = "timingCheckBox";
            this.timingCheckBox.Size = new System.Drawing.Size(279, 21);
            this.timingCheckBox.TabIndex = 2;
            this.timingCheckBox.Text = "Use late timing model (requires a reset)";
            this.timingCheckBox.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.romBrowseButton);
            this.groupBox1.Controls.Add(this.romTextBox);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.pictureBox1);
            this.groupBox1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.groupBox1.Location = new System.Drawing.Point(13, 14);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox1.Size = new System.Drawing.Size(516, 165);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Model";
            // 
            // romBrowseButton
            // 
            this.romBrowseButton.Location = new System.Drawing.Point(307, 50);
            this.romBrowseButton.Margin = new System.Windows.Forms.Padding(4);
            this.romBrowseButton.Name = "romBrowseButton";
            this.romBrowseButton.Size = new System.Drawing.Size(100, 28);
            this.romBrowseButton.TabIndex = 6;
            this.romBrowseButton.Text = "Browse...";
            this.romBrowseButton.UseVisualStyleBackColor = true;
            this.romBrowseButton.Click += new System.EventHandler(this.romBrowseButton_Click);
            // 
            // romTextBox
            // 
            this.romTextBox.Location = new System.Drawing.Point(141, 52);
            this.romTextBox.Margin = new System.Windows.Forms.Padding(4);
            this.romTextBox.Name = "romTextBox";
            this.romTextBox.Size = new System.Drawing.Size(156, 22);
            this.romTextBox.TabIndex = 5;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(81, 56);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(42, 17);
            this.label11.TabIndex = 4;
            this.label11.Text = "ROM:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(77, 27);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(163, 17);
            this.label5.TabIndex = 1;
            this.label5.Text = "Multitech Microprofessor I";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::ZeroWin.Properties.Resources.mpf_logo2_64_16c;
            this.pictureBox1.Location = new System.Drawing.Point(12, 22);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(49, 52);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.groupBox5);
            this.tabPage2.Controls.Add(this.groupBox3);
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage2.Size = new System.Drawing.Size(547, 487);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Display";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.aspectRatioFullscreenCheckBox);
            this.groupBox5.Controls.Add(this.label10);
            this.groupBox5.Controls.Add(this.label8);
            this.groupBox5.Controls.Add(this.windowSizeComboBox);
            this.groupBox5.Controls.Add(this.borderSizeComboBox);
            this.groupBox5.Controls.Add(this.label9);
            this.groupBox5.Controls.Add(this.pictureBox5);
            this.groupBox5.Location = new System.Drawing.Point(12, 143);
            this.groupBox5.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox5.Size = new System.Drawing.Size(517, 198);
            this.groupBox5.TabIndex = 9;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Size";
            // 
            // aspectRatioFullscreenCheckBox
            // 
            this.aspectRatioFullscreenCheckBox.AutoSize = true;
            this.aspectRatioFullscreenCheckBox.Checked = true;
            this.aspectRatioFullscreenCheckBox.CheckState = System.Windows.Forms.CheckState.Checked;
            this.aspectRatioFullscreenCheckBox.Location = new System.Drawing.Point(83, 154);
            this.aspectRatioFullscreenCheckBox.Margin = new System.Windows.Forms.Padding(4);
            this.aspectRatioFullscreenCheckBox.Name = "aspectRatioFullscreenCheckBox";
            this.aspectRatioFullscreenCheckBox.Size = new System.Drawing.Size(245, 21);
            this.aspectRatioFullscreenCheckBox.TabIndex = 8;
            this.aspectRatioFullscreenCheckBox.Text = "Maintain aspect ratio in full screen";
            this.toolTip1.SetToolTip(this.aspectRatioFullscreenCheckBox, resources.GetString("aspectRatioFullscreenCheckBox.ToolTip"));
            this.aspectRatioFullscreenCheckBox.UseVisualStyleBackColor = true;
            // 
            // label10
            // 
            this.label10.Location = new System.Drawing.Point(83, 26);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(419, 16);
            this.label10.TabIndex = 15;
            this.label10.Text = "The following settings change the display size of the emulator.";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(83, 66);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(92, 17);
            this.label8.TabIndex = 14;
            this.label8.Text = "Window Size:";
            // 
            // windowSizeComboBox
            // 
            this.windowSizeComboBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.windowSizeComboBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.windowSizeComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.windowSizeComboBox.FormattingEnabled = true;
            this.windowSizeComboBox.Items.AddRange(new object[] {
            "Full Screen",
            "100%",
            "150%",
            "200%",
            "250%",
            "300%",
            "350%",
            "400%",
            "450%",
            "500%"});
            this.windowSizeComboBox.Location = new System.Drawing.Point(236, 64);
            this.windowSizeComboBox.Margin = new System.Windows.Forms.Padding(4);
            this.windowSizeComboBox.Name = "windowSizeComboBox";
            this.windowSizeComboBox.Size = new System.Drawing.Size(164, 24);
            this.windowSizeComboBox.TabIndex = 13;
            // 
            // borderSizeComboBox
            // 
            this.borderSizeComboBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.borderSizeComboBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.borderSizeComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.borderSizeComboBox.FormattingEnabled = true;
            this.borderSizeComboBox.Items.AddRange(new object[] {
            "Full Border",
            "Medium Border",
            "Mini Border"});
            this.borderSizeComboBox.Location = new System.Drawing.Point(236, 107);
            this.borderSizeComboBox.Margin = new System.Windows.Forms.Padding(4);
            this.borderSizeComboBox.Name = "borderSizeComboBox";
            this.borderSizeComboBox.Size = new System.Drawing.Size(164, 24);
            this.borderSizeComboBox.TabIndex = 10;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(79, 111);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(150, 17);
            this.label9.TabIndex = 9;
            this.label9.Text = "Spectrum Border Size:";
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = global::ZeroWin.Properties.Resources.application_double;
            this.pictureBox5.Location = new System.Drawing.Point(8, 26);
            this.pictureBox5.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(53, 44);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox5.TabIndex = 8;
            this.pictureBox5.TabStop = false;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.vsyncCheckbox);
            this.groupBox3.Controls.Add(this.pixelSmoothingCheckBox);
            this.groupBox3.Controls.Add(this.interlaceCheckBox);
            this.groupBox3.Controls.Add(this.pictureBox3);
            this.groupBox3.Controls.Add(this.label2);
            this.groupBox3.Controls.Add(this.gdiRadioButton);
            this.groupBox3.Controls.Add(this.directXRadioButton);
            this.groupBox3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.groupBox3.Location = new System.Drawing.Point(12, 12);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox3.Size = new System.Drawing.Size(517, 123);
            this.groupBox3.TabIndex = 3;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Renderer";
            // 
            // vsyncCheckbox
            // 
            this.vsyncCheckbox.AutoSize = true;
            this.vsyncCheckbox.Location = new System.Drawing.Point(87, 86);
            this.vsyncCheckbox.Margin = new System.Windows.Forms.Padding(4);
            this.vsyncCheckbox.Name = "vsyncCheckbox";
            this.vsyncCheckbox.Size = new System.Drawing.Size(118, 21);
            this.vsyncCheckbox.TabIndex = 7;
            this.vsyncCheckbox.Text = "Enable VSync";
            this.toolTip1.SetToolTip(this.vsyncCheckbox, "If this option is enabled, the renderer will try update the display at your monit" +
        "ors refresh rate, which may or may not give smoother display.");
            this.vsyncCheckbox.UseVisualStyleBackColor = true;
            // 
            // pixelSmoothingCheckBox
            // 
            this.pixelSmoothingCheckBox.AutoSize = true;
            this.pixelSmoothingCheckBox.Location = new System.Drawing.Point(357, 86);
            this.pixelSmoothingCheckBox.Margin = new System.Windows.Forms.Padding(4);
            this.pixelSmoothingCheckBox.Name = "pixelSmoothingCheckBox";
            this.pixelSmoothingCheckBox.Size = new System.Drawing.Size(146, 21);
            this.pixelSmoothingCheckBox.TabIndex = 6;
            this.pixelSmoothingCheckBox.Text = "Reduce Pixellation";
            this.toolTip1.SetToolTip(this.pixelSmoothingCheckBox, "Smoothes out pixels on the screen but will reduce overall sharpness.");
            this.pixelSmoothingCheckBox.UseVisualStyleBackColor = true;
            // 
            // interlaceCheckBox
            // 
            this.interlaceCheckBox.AutoSize = true;
            this.interlaceCheckBox.Location = new System.Drawing.Point(216, 86);
            this.interlaceCheckBox.Margin = new System.Windows.Forms.Padding(4);
            this.interlaceCheckBox.Name = "interlaceCheckBox";
            this.interlaceCheckBox.Size = new System.Drawing.Size(129, 21);
            this.interlaceCheckBox.TabIndex = 5;
            this.interlaceCheckBox.Text = "Show Scanlines";
            this.toolTip1.SetToolTip(this.interlaceCheckBox, "Gives a TV like interlaced effect.");
            this.interlaceCheckBox.UseVisualStyleBackColor = true;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::ZeroWin.Properties.Resources.monitor;
            this.pictureBox3.Location = new System.Drawing.Point(8, 23);
            this.pictureBox3.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(53, 59);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox3.TabIndex = 4;
            this.pictureBox3.TabStop = false;
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(79, 21);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(423, 28);
            this.label2.TabIndex = 3;
            this.label2.Text = "Enhance your experience by way of these effects.";
            // 
            // gdiRadioButton
            // 
            this.gdiRadioButton.AutoSize = true;
            this.gdiRadioButton.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gdiRadioButton.Location = new System.Drawing.Point(188, 53);
            this.gdiRadioButton.Margin = new System.Windows.Forms.Padding(4);
            this.gdiRadioButton.Name = "gdiRadioButton";
            this.gdiRadioButton.Size = new System.Drawing.Size(52, 21);
            this.gdiRadioButton.TabIndex = 1;
            this.gdiRadioButton.Text = "GDI";
            this.gdiRadioButton.UseVisualStyleBackColor = true;
            this.gdiRadioButton.Visible = false;
            this.gdiRadioButton.CheckedChanged += new System.EventHandler(this.gdiRadioButton_CheckedChanged);
            // 
            // directXRadioButton
            // 
            this.directXRadioButton.AutoSize = true;
            this.directXRadioButton.Checked = true;
            this.directXRadioButton.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.directXRadioButton.Location = new System.Drawing.Point(87, 53);
            this.directXRadioButton.Margin = new System.Windows.Forms.Padding(4);
            this.directXRadioButton.Name = "directXRadioButton";
            this.directXRadioButton.Size = new System.Drawing.Size(73, 21);
            this.directXRadioButton.TabIndex = 2;
            this.directXRadioButton.TabStop = true;
            this.directXRadioButton.Text = "DirectX";
            this.directXRadioButton.UseVisualStyleBackColor = true;
            this.directXRadioButton.Visible = false;
            this.directXRadioButton.CheckedChanged += new System.EventHandler(this.directXRadioButton_CheckedChanged);
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.groupBox11);
            this.tabPage4.Controls.Add(this.groupBox10);
            this.tabPage4.Location = new System.Drawing.Point(4, 25);
            this.tabPage4.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage4.Size = new System.Drawing.Size(547, 487);
            this.tabPage4.TabIndex = 4;
            this.tabPage4.Text = "Sound";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.abcRadioButton);
            this.groupBox11.Controls.Add(this.acbRadioButton);
            this.groupBox11.Controls.Add(this.label20);
            this.groupBox11.Controls.Add(this.pictureBox10);
            this.groupBox11.Location = new System.Drawing.Point(16, 228);
            this.groupBox11.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox11.Size = new System.Drawing.Size(504, 145);
            this.groupBox11.TabIndex = 1;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "Speaker Setup";
            // 
            // abcRadioButton
            // 
            this.abcRadioButton.AutoSize = true;
            this.abcRadioButton.Location = new System.Drawing.Point(197, 101);
            this.abcRadioButton.Margin = new System.Windows.Forms.Padding(4);
            this.abcRadioButton.Name = "abcRadioButton";
            this.abcRadioButton.Size = new System.Drawing.Size(56, 21);
            this.abcRadioButton.TabIndex = 6;
            this.abcRadioButton.Text = "ABC";
            this.abcRadioButton.UseVisualStyleBackColor = true;
            // 
            // acbRadioButton
            // 
            this.acbRadioButton.AutoSize = true;
            this.acbRadioButton.Checked = true;
            this.acbRadioButton.Location = new System.Drawing.Point(81, 101);
            this.acbRadioButton.Margin = new System.Windows.Forms.Padding(4);
            this.acbRadioButton.Name = "acbRadioButton";
            this.acbRadioButton.Size = new System.Drawing.Size(56, 21);
            this.acbRadioButton.TabIndex = 5;
            this.acbRadioButton.TabStop = true;
            this.acbRadioButton.Text = "ACB";
            this.acbRadioButton.UseVisualStyleBackColor = true;
            // 
            // label20
            // 
            this.label20.Location = new System.Drawing.Point(77, 31);
            this.label20.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(419, 48);
            this.label20.TabIndex = 3;
            this.label20.Text = "Choose the speaker configuration for the three AY channels - A,B and C - in stere" +
    "o mode. Default is: A on left speaker, C on both speakers (center) and B on righ" +
    "t speaker.";
            // 
            // pictureBox10
            // 
            this.pictureBox10.Image = global::ZeroWin.Properties.Resources.soundIcon;
            this.pictureBox10.Location = new System.Drawing.Point(13, 31);
            this.pictureBox10.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox10.Name = "pictureBox10";
            this.pictureBox10.Size = new System.Drawing.Size(49, 49);
            this.pictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox10.TabIndex = 1;
            this.pictureBox10.TabStop = false;
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.monoRadioButton);
            this.groupBox10.Controls.Add(this.stereoRadioButton);
            this.groupBox10.Controls.Add(this.pictureBox11);
            this.groupBox10.Controls.Add(this.label19);
            this.groupBox10.Location = new System.Drawing.Point(16, 8);
            this.groupBox10.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox10.Size = new System.Drawing.Size(505, 193);
            this.groupBox10.TabIndex = 0;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "AY Sound";
            // 
            // monoRadioButton
            // 
            this.monoRadioButton.AutoSize = true;
            this.monoRadioButton.Location = new System.Drawing.Point(197, 101);
            this.monoRadioButton.Margin = new System.Windows.Forms.Padding(4);
            this.monoRadioButton.Name = "monoRadioButton";
            this.monoRadioButton.Size = new System.Drawing.Size(64, 21);
            this.monoRadioButton.TabIndex = 4;
            this.monoRadioButton.Text = "Mono";
            this.monoRadioButton.UseVisualStyleBackColor = true;
            this.monoRadioButton.CheckedChanged += new System.EventHandler(this.monoRadioButton_CheckedChanged);
            // 
            // stereoRadioButton
            // 
            this.stereoRadioButton.AutoSize = true;
            this.stereoRadioButton.Checked = true;
            this.stereoRadioButton.Location = new System.Drawing.Point(81, 101);
            this.stereoRadioButton.Margin = new System.Windows.Forms.Padding(4);
            this.stereoRadioButton.Name = "stereoRadioButton";
            this.stereoRadioButton.Size = new System.Drawing.Size(71, 21);
            this.stereoRadioButton.TabIndex = 3;
            this.stereoRadioButton.TabStop = true;
            this.stereoRadioButton.Text = "Stereo";
            this.stereoRadioButton.UseVisualStyleBackColor = true;
            this.stereoRadioButton.CheckedChanged += new System.EventHandler(this.stereoRadioButton_CheckedChanged);
            // 
            // pictureBox11
            // 
            this.pictureBox11.Image = global::ZeroWin.Properties.Resources.music;
            this.pictureBox11.Location = new System.Drawing.Point(13, 33);
            this.pictureBox11.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox11.Name = "pictureBox11";
            this.pictureBox11.Size = new System.Drawing.Size(49, 49);
            this.pictureBox11.TabIndex = 0;
            this.pictureBox11.TabStop = false;
            // 
            // label19
            // 
            this.label19.Location = new System.Drawing.Point(77, 33);
            this.label19.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(420, 48);
            this.label19.TabIndex = 2;
            this.label19.Text = "Zero can emulate AY sound in both mono and stereo modes. Choose \'Mono\' for a more" +
    " authentic experience or \'Stereo\' for a more amiable one.";
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.groupBox13);
            this.tabPage1.Controls.Add(this.groupBox7);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage1.Size = new System.Drawing.Size(547, 487);
            this.tabPage1.TabIndex = 2;
            this.tabPage1.Text = "Emulation";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // groupBox13
            // 
            this.groupBox13.Controls.Add(this.label33);
            this.groupBox13.Controls.Add(this.label32);
            this.groupBox13.Controls.Add(this.label31);
            this.groupBox13.Controls.Add(this.emulationSpeedTrackBar);
            this.groupBox13.Controls.Add(this.label30);
            this.groupBox13.Controls.Add(this.pictureBox15);
            this.groupBox13.Location = new System.Drawing.Point(13, 276);
            this.groupBox13.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox13.Size = new System.Drawing.Size(517, 190);
            this.groupBox13.TabIndex = 5;
            this.groupBox13.TabStop = false;
            this.groupBox13.Text = "Emulation Speed";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(163, 85);
            this.label33.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(47, 17);
            this.label33.TabIndex = 7;
            this.label33.Text = "|100%";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.BackColor = System.Drawing.Color.Transparent;
            this.label32.Location = new System.Drawing.Point(407, 86);
            this.label32.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(47, 17);
            this.label32.TabIndex = 6;
            this.label32.Text = "500%|";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(99, 86);
            this.label31.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(39, 17);
            this.label31.TabIndex = 5;
            this.label31.Text = "|10%";
            // 
            // emulationSpeedTrackBar
            // 
            this.emulationSpeedTrackBar.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.emulationSpeedTrackBar.LargeChange = 50;
            this.emulationSpeedTrackBar.Location = new System.Drawing.Point(87, 106);
            this.emulationSpeedTrackBar.Margin = new System.Windows.Forms.Padding(4);
            this.emulationSpeedTrackBar.Maximum = 500;
            this.emulationSpeedTrackBar.Minimum = 10;
            this.emulationSpeedTrackBar.Name = "emulationSpeedTrackBar";
            this.emulationSpeedTrackBar.Size = new System.Drawing.Size(379, 56);
            this.emulationSpeedTrackBar.SmallChange = 10;
            this.emulationSpeedTrackBar.TabIndex = 4;
            this.emulationSpeedTrackBar.TickFrequency = 10;
            this.emulationSpeedTrackBar.TickStyle = System.Windows.Forms.TickStyle.TopLeft;
            this.emulationSpeedTrackBar.Value = 100;
            this.emulationSpeedTrackBar.Scroll += new System.EventHandler(this.emulationSpeedTrackBar_Scroll);
            // 
            // label30
            // 
            this.label30.Location = new System.Drawing.Point(83, 23);
            this.label30.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(427, 48);
            this.label30.TabIndex = 3;
            this.label30.Text = "Drag the slider to change the emulation speed. Useful if you\'re playing 3D games " +
    "or graphic adventures like The Hobbit that run a touch slow on the speccy.";
            // 
            // pictureBox15
            // 
            this.pictureBox15.Image = global::ZeroWin.Properties.Resources.frequency;
            this.pictureBox15.Location = new System.Drawing.Point(8, 23);
            this.pictureBox15.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox15.Name = "pictureBox15";
            this.pictureBox15.Size = new System.Drawing.Size(59, 49);
            this.pictureBox15.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox15.TabIndex = 0;
            this.pictureBox15.TabStop = false;
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.onScreenLEDCheckbox);
            this.groupBox7.Controls.Add(this.lastStateCheckbox);
            this.groupBox7.Controls.Add(this.Use128keCheckbox);
            this.groupBox7.Controls.Add(this.exitConfirmCheckBox);
            this.groupBox7.Controls.Add(this.pauseCheckBox);
            this.groupBox7.Controls.Add(this.pictureBox7);
            this.groupBox7.Location = new System.Drawing.Point(8, 18);
            this.groupBox7.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox7.Size = new System.Drawing.Size(517, 235);
            this.groupBox7.TabIndex = 4;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Miscellaneous";
            // 
            // onScreenLEDCheckbox
            // 
            this.onScreenLEDCheckbox.AutoSize = true;
            this.onScreenLEDCheckbox.Checked = true;
            this.onScreenLEDCheckbox.CheckState = System.Windows.Forms.CheckState.Checked;
            this.onScreenLEDCheckbox.Location = new System.Drawing.Point(92, 112);
            this.onScreenLEDCheckbox.Margin = new System.Windows.Forms.Padding(4);
            this.onScreenLEDCheckbox.Name = "onScreenLEDCheckbox";
            this.onScreenLEDCheckbox.Size = new System.Drawing.Size(200, 21);
            this.onScreenLEDCheckbox.TabIndex = 5;
            this.onScreenLEDCheckbox.Text = "Show on screen indicators.";
            this.toolTip1.SetToolTip(this.onScreenLEDCheckbox, "If unchecked, this will turn off all on screen indicators including\r\nthe tape and" +
        " disk activity icons.");
            this.onScreenLEDCheckbox.UseVisualStyleBackColor = true;
            // 
            // lastStateCheckbox
            // 
            this.lastStateCheckbox.AutoSize = true;
            this.lastStateCheckbox.Location = new System.Drawing.Point(92, 84);
            this.lastStateCheckbox.Margin = new System.Windows.Forms.Padding(4);
            this.lastStateCheckbox.Name = "lastStateCheckbox";
            this.lastStateCheckbox.Size = new System.Drawing.Size(204, 21);
            this.lastStateCheckbox.TabIndex = 4;
            this.lastStateCheckbox.Text = "Restore session on startup.";
            this.toolTip1.SetToolTip(this.lastStateCheckbox, "If checked, Zero will revert to the state it was in when it exited.\r\nNow you can " +
        "turn off the emulator in the middle of your work or gaming\r\nsession and then hav" +
        "e it carry on from where you left off.");
            this.lastStateCheckbox.UseVisualStyleBackColor = true;
            this.lastStateCheckbox.CheckedChanged += new System.EventHandler(this.lastStateCheckbox_CheckedChanged);
            // 
            // Use128keCheckbox
            // 
            this.Use128keCheckbox.AutoSize = true;
            this.Use128keCheckbox.Checked = true;
            this.Use128keCheckbox.CheckState = System.Windows.Forms.CheckState.Checked;
            this.Use128keCheckbox.Location = new System.Drawing.Point(92, 27);
            this.Use128keCheckbox.Margin = new System.Windows.Forms.Padding(4);
            this.Use128keCheckbox.Name = "Use128keCheckbox";
            this.Use128keCheckbox.Size = new System.Drawing.Size(368, 21);
            this.Use128keCheckbox.TabIndex = 3;
            this.Use128keCheckbox.Text = "Use 128Ke when loading snapshots (best for games).";
            this.toolTip1.SetToolTip(this.Use128keCheckbox, resources.GetString("Use128keCheckbox.ToolTip"));
            this.Use128keCheckbox.UseVisualStyleBackColor = true;
            // 
            // exitConfirmCheckBox
            // 
            this.exitConfirmCheckBox.AutoSize = true;
            this.exitConfirmCheckBox.Checked = true;
            this.exitConfirmCheckBox.CheckState = System.Windows.Forms.CheckState.Checked;
            this.exitConfirmCheckBox.Location = new System.Drawing.Point(92, 139);
            this.exitConfirmCheckBox.Margin = new System.Windows.Forms.Padding(4);
            this.exitConfirmCheckBox.Name = "exitConfirmCheckBox";
            this.exitConfirmCheckBox.Size = new System.Drawing.Size(180, 21);
            this.exitConfirmCheckBox.TabIndex = 2;
            this.exitConfirmCheckBox.Text = "Ask before exiting Zero.";
            this.exitConfirmCheckBox.UseVisualStyleBackColor = true;
            // 
            // pauseCheckBox
            // 
            this.pauseCheckBox.AutoSize = true;
            this.pauseCheckBox.Checked = true;
            this.pauseCheckBox.CheckState = System.Windows.Forms.CheckState.Checked;
            this.pauseCheckBox.Location = new System.Drawing.Point(92, 55);
            this.pauseCheckBox.Margin = new System.Windows.Forms.Padding(4);
            this.pauseCheckBox.Name = "pauseCheckBox";
            this.pauseCheckBox.Size = new System.Drawing.Size(300, 21);
            this.pauseCheckBox.TabIndex = 1;
            this.pauseCheckBox.Text = "Pause emulation when window loses focus.";
            this.pauseCheckBox.UseVisualStyleBackColor = true;
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = global::ZeroWin.Properties.Resources.options;
            this.pictureBox7.Location = new System.Drawing.Point(8, 23);
            this.pictureBox7.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(59, 49);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox7.TabIndex = 0;
            this.pictureBox7.TabStop = false;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.groupBox8);
            this.tabPage3.Location = new System.Drawing.Point(4, 25);
            this.tabPage3.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage3.Size = new System.Drawing.Size(547, 487);
            this.tabPage3.TabIndex = 3;
            this.tabPage3.Text = "Files";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.gamePathButton);
            this.groupBox8.Controls.Add(this.gamePathTextBox);
            this.groupBox8.Controls.Add(this.label14);
            this.groupBox8.Controls.Add(this.pictureBox8);
            this.groupBox8.Controls.Add(this.label13);
            this.groupBox8.Controls.Add(this.romPathButton);
            this.groupBox8.Controls.Add(this.romPathTextBox);
            this.groupBox8.Controls.Add(this.label12);
            this.groupBox8.Location = new System.Drawing.Point(15, 12);
            this.groupBox8.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox8.Size = new System.Drawing.Size(516, 159);
            this.groupBox8.TabIndex = 0;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Folders";
            // 
            // gamePathButton
            // 
            this.gamePathButton.Location = new System.Drawing.Point(423, 107);
            this.gamePathButton.Margin = new System.Windows.Forms.Padding(4);
            this.gamePathButton.Name = "gamePathButton";
            this.gamePathButton.Size = new System.Drawing.Size(71, 28);
            this.gamePathButton.TabIndex = 14;
            this.gamePathButton.Text = "Browse...";
            this.gamePathButton.UseVisualStyleBackColor = true;
            // 
            // gamePathTextBox
            // 
            this.gamePathTextBox.Location = new System.Drawing.Point(161, 110);
            this.gamePathTextBox.Margin = new System.Windows.Forms.Padding(4);
            this.gamePathTextBox.Name = "gamePathTextBox";
            this.gamePathTextBox.ReadOnly = true;
            this.gamePathTextBox.Size = new System.Drawing.Size(236, 22);
            this.gamePathTextBox.TabIndex = 13;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(79, 113);
            this.label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(72, 17);
            this.label14.TabIndex = 12;
            this.label14.Text = "Programs:";
            // 
            // pictureBox8
            // 
            this.pictureBox8.Image = global::ZeroWin.Properties.Resources.folder_link;
            this.pictureBox8.Location = new System.Drawing.Point(19, 32);
            this.pictureBox8.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(45, 41);
            this.pictureBox8.TabIndex = 11;
            this.pictureBox8.TabStop = false;
            // 
            // label13
            // 
            this.label13.Location = new System.Drawing.Point(79, 32);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(415, 16);
            this.label13.TabIndex = 10;
            this.label13.Text = "Specify the path for the following types of files.";
            // 
            // romPathButton
            // 
            this.romPathButton.Location = new System.Drawing.Point(423, 64);
            this.romPathButton.Margin = new System.Windows.Forms.Padding(4);
            this.romPathButton.Name = "romPathButton";
            this.romPathButton.Size = new System.Drawing.Size(71, 28);
            this.romPathButton.TabIndex = 9;
            this.romPathButton.Text = "Browse...";
            this.romPathButton.UseVisualStyleBackColor = true;
            this.romPathButton.Click += new System.EventHandler(this.romPathButton_Click);
            // 
            // romPathTextBox
            // 
            this.romPathTextBox.Location = new System.Drawing.Point(161, 66);
            this.romPathTextBox.Margin = new System.Windows.Forms.Padding(4);
            this.romPathTextBox.Name = "romPathTextBox";
            this.romPathTextBox.ReadOnly = true;
            this.romPathTextBox.Size = new System.Drawing.Size(236, 22);
            this.romPathTextBox.TabIndex = 8;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(79, 70);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(50, 17);
            this.label12.TabIndex = 7;
            this.label12.Text = "ROMS:";
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.tabControl2);
            this.tabPage5.Location = new System.Drawing.Point(4, 25);
            this.tabPage5.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage5.Size = new System.Drawing.Size(547, 487);
            this.tabPage5.TabIndex = 5;
            this.tabPage5.Text = "Input Devices";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // tabControl2
            // 
            this.tabControl2.Appearance = System.Windows.Forms.TabAppearance.FlatButtons;
            this.tabControl2.Controls.Add(this.tabPage8);
            this.tabControl2.Controls.Add(this.tabPage6);
            this.tabControl2.Location = new System.Drawing.Point(4, 7);
            this.tabControl2.Margin = new System.Windows.Forms.Padding(4);
            this.tabControl2.Multiline = true;
            this.tabControl2.Name = "tabControl2";
            this.tabControl2.SelectedIndex = 0;
            this.tabControl2.Size = new System.Drawing.Size(532, 469);
            this.tabControl2.TabIndex = 14;
            // 
            // tabPage8
            // 
            this.tabPage8.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.tabPage8.Location = new System.Drawing.Point(4, 28);
            this.tabPage8.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage8.Name = "tabPage8";
            this.tabPage8.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage8.Size = new System.Drawing.Size(524, 437);
            this.tabPage8.TabIndex = 2;
            this.tabPage8.Text = "Keyboard";
            this.tabPage8.UseVisualStyleBackColor = true;
            // 
            // tabPage6
            // 
            this.tabPage6.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.tabPage6.Controls.Add(this.label34);
            this.tabPage6.Controls.Add(this.mouseLabel);
            this.tabPage6.Controls.Add(this.mouseTrackBar);
            this.tabPage6.Controls.Add(this.pictureBox13);
            this.tabPage6.Controls.Add(this.mouseCheckBox);
            this.tabPage6.Controls.Add(this.label25);
            this.tabPage6.Location = new System.Drawing.Point(4, 28);
            this.tabPage6.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage6.Size = new System.Drawing.Size(524, 437);
            this.tabPage6.TabIndex = 0;
            this.tabPage6.Text = "Mouse";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // label34
            // 
            this.label34.Location = new System.Drawing.Point(97, 78);
            this.label34.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(376, 32);
            this.label34.TabIndex = 14;
            this.label34.Text = "Note: press F6 to acquire the mouse in the emulator, and Alt+F6 to release it.";
            // 
            // mouseLabel
            // 
            this.mouseLabel.AutoSize = true;
            this.mouseLabel.Location = new System.Drawing.Point(97, 186);
            this.mouseLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.mouseLabel.Name = "mouseLabel";
            this.mouseLabel.Size = new System.Drawing.Size(75, 17);
            this.mouseLabel.TabIndex = 13;
            this.mouseLabel.Text = "Sensitivity:";
            // 
            // mouseTrackBar
            // 
            this.mouseTrackBar.AutoSize = false;
            this.mouseTrackBar.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.mouseTrackBar.Location = new System.Drawing.Point(188, 174);
            this.mouseTrackBar.Margin = new System.Windows.Forms.Padding(4);
            this.mouseTrackBar.Minimum = 1;
            this.mouseTrackBar.Name = "mouseTrackBar";
            this.mouseTrackBar.Size = new System.Drawing.Size(308, 39);
            this.mouseTrackBar.TabIndex = 12;
            this.mouseTrackBar.TickStyle = System.Windows.Forms.TickStyle.TopLeft;
            this.mouseTrackBar.Value = 3;
            // 
            // pictureBox13
            // 
            this.pictureBox13.Image = global::ZeroWin.Properties.Resources.mouse;
            this.pictureBox13.Location = new System.Drawing.Point(23, 34);
            this.pictureBox13.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox13.Name = "pictureBox13";
            this.pictureBox13.Size = new System.Drawing.Size(45, 42);
            this.pictureBox13.TabIndex = 9;
            this.pictureBox13.TabStop = false;
            // 
            // mouseCheckBox
            // 
            this.mouseCheckBox.AutoSize = true;
            this.mouseCheckBox.Location = new System.Drawing.Point(101, 133);
            this.mouseCheckBox.Margin = new System.Windows.Forms.Padding(4);
            this.mouseCheckBox.Name = "mouseCheckBox";
            this.mouseCheckBox.Size = new System.Drawing.Size(187, 21);
            this.mouseCheckBox.TabIndex = 11;
            this.mouseCheckBox.Text = "Enable Kempston Mouse";
            this.mouseCheckBox.UseVisualStyleBackColor = true;
            // 
            // label25
            // 
            this.label25.Location = new System.Drawing.Point(97, 34);
            this.label25.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(376, 32);
            this.label25.TabIndex = 10;
            this.label25.Text = "Zero can emulate a two button Kempston mouse using the mouse attached to your PC." +
    " ";
            // 
            // tabPage9
            // 
            this.tabPage9.Controls.Add(this.groupBox14);
            this.tabPage9.Location = new System.Drawing.Point(4, 25);
            this.tabPage9.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage9.Name = "tabPage9";
            this.tabPage9.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage9.Size = new System.Drawing.Size(547, 487);
            this.tabPage9.TabIndex = 6;
            this.tabPage9.Text = "Debugger";
            this.tabPage9.UseVisualStyleBackColor = true;
            // 
            // groupBox14
            // 
            this.groupBox14.Controls.Add(this.checkBox2);
            this.groupBox14.Controls.Add(this.checkBox1);
            this.groupBox14.Location = new System.Drawing.Point(25, 62);
            this.groupBox14.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox14.Name = "groupBox14";
            this.groupBox14.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox14.Size = new System.Drawing.Size(487, 108);
            this.groupBox14.TabIndex = 2;
            this.groupBox14.TabStop = false;
            this.groupBox14.Text = "Dissasembly ";
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Location = new System.Drawing.Point(17, 65);
            this.checkBox2.Margin = new System.Windows.Forms.Padding(4);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(235, 21);
            this.checkBox2.TabIndex = 1;
            this.checkBox2.Text = "Visualize Lables on Dissasembly";
            this.checkBox2.UseVisualStyleBackColor = true;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(17, 37);
            this.checkBox1.Margin = new System.Windows.Forms.Padding(4);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(144, 21);
            this.checkBox1.TabIndex = 0;
            this.checkBox1.Text = "Use Hex Numbers";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            this.button4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button4.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.button4.Location = new System.Drawing.Point(464, 539);
            this.button4.Margin = new System.Windows.Forms.Padding(4);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(100, 28);
            this.button4.TabIndex = 1;
            this.button4.Text = "Save";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // button5
            // 
            this.button5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button5.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.button5.Location = new System.Drawing.Point(352, 539);
            this.button5.Margin = new System.Windows.Forms.Padding(4);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(100, 28);
            this.button5.TabIndex = 2;
            this.button5.Text = "Cancel";
            this.button5.UseVisualStyleBackColor = true;
            // 
            // defaultSettingsButton
            // 
            this.defaultSettingsButton.Location = new System.Drawing.Point(11, 539);
            this.defaultSettingsButton.Margin = new System.Windows.Forms.Padding(4);
            this.defaultSettingsButton.Name = "defaultSettingsButton";
            this.defaultSettingsButton.Size = new System.Drawing.Size(185, 28);
            this.defaultSettingsButton.TabIndex = 3;
            this.defaultSettingsButton.Text = "Revert to defaults...";
            this.defaultSettingsButton.UseVisualStyleBackColor = true;
            this.defaultSettingsButton.Click += new System.EventHandler(this.defaultSettingsButton_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // Options
            // 
            this.AcceptButton = this.button4;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.SystemColors.ControlLight;
            this.CancelButton = this.button5;
            this.ClientSize = new System.Drawing.Size(576, 576);
            this.Controls.Add(this.defaultSettingsButton);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.Debbuger);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Options";
            this.ShowInTaskbar = false;
            this.Text = "Settings";
            this.Load += new System.EventHandler(this.Options_Load);
            this.Debbuger.ResumeLayout(false);
            this.hwPage.ResumeLayout(false);
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.tabPage4.ResumeLayout(false);
            this.groupBox11.ResumeLayout(false);
            this.groupBox11.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).EndInit();
            this.tabPage1.ResumeLayout(false);
            this.groupBox13.ResumeLayout(false);
            this.groupBox13.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.emulationSpeedTrackBar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).EndInit();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            this.tabPage5.ResumeLayout(false);
            this.tabControl2.ResumeLayout(false);
            this.tabPage6.ResumeLayout(false);
            this.tabPage6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.mouseTrackBar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).EndInit();
            this.tabPage9.ResumeLayout(false);
            this.groupBox14.ResumeLayout(false);
            this.groupBox14.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl Debbuger;
        private System.Windows.Forms.TabPage hwPage;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.RadioButton gdiRadioButton;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.RadioButton directXRadioButton;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.CheckBox exitConfirmCheckBox;
        private System.Windows.Forms.CheckBox pauseCheckBox;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.Button defaultSettingsButton;
        private System.Windows.Forms.ComboBox borderSizeComboBox;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.TextBox romTextBox;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button romBrowseButton;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button romPathButton;
        private System.Windows.Forms.TextBox romPathTextBox;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button gamePathButton;
        private System.Windows.Forms.TextBox gamePathTextBox;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog1;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.CheckBox interlaceCheckBox;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.CheckBox timingCheckBox;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.CheckBox Use128keCheckbox;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.PictureBox pictureBox13;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TrackBar mouseTrackBar;
        private System.Windows.Forms.CheckBox mouseCheckBox;
        private System.Windows.Forms.Label mouseLabel;
        private System.Windows.Forms.TabControl tabControl2;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.TabPage tabPage8;
        private System.Windows.Forms.GroupBox groupBox13;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.PictureBox pictureBox15;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.TrackBar emulationSpeedTrackBar;
        private System.Windows.Forms.CheckBox lastStateCheckbox;
        private System.Windows.Forms.CheckBox onScreenLEDCheckbox;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox windowSizeComboBox;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.CheckBox pixelSmoothingCheckBox;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.CheckBox vsyncCheckbox;
        private System.Windows.Forms.CheckBox aspectRatioFullscreenCheckBox;
        private System.Windows.Forms.TabPage tabPage9;
        private System.Windows.Forms.GroupBox groupBox14;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.RadioButton abcRadioButton;
        private System.Windows.Forms.RadioButton acbRadioButton;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.PictureBox pictureBox10;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.RadioButton monoRadioButton;
        private System.Windows.Forms.RadioButton stereoRadioButton;
        private System.Windows.Forms.PictureBox pictureBox11;
        private System.Windows.Forms.Label label19;
    }
}