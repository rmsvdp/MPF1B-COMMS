﻿using System.Windows.Forms;
using System.Collections.Generic;
using System;

namespace ZeroWin
{
    internal static class Program
    {
        public static bool useLabels = false;     //#RMS# <060616>
                                                  // Diccionario global, para desenmablado con etiquetas personalizadas
        public static bool Beam_Enabled = false;  // Flag para simular el haz sobre la pantalla virtual
        public static Dictionary<int, String> CLabels_RMS = new Dictionary<int, string>() {
            // se pueden añadir más entradas,el desemsamblador cambia el valor de la
            // dirección por el literal si ponemos {60000,"Start"} y el ensamblador 
            // encuentra CALL 60000 ,lo mostrará como CALL Start
            // CodeLabels.cs contiene el form y el código para la creación de etiquetas
            // de usuario, permitiendo incorporar ficheros .map de IDA Pro

            // Etiquetas predefinidas del Sistema
            
            {23552, "KSTATE"}, {23560, "LAST K"}, {23561, "REPDEL"}, {23562, "REPPER"},
            {23563, "DEFADD"}, {23565, "K DATA"}, {23566, "TVDATA"}, {23568, "STRMS"},
            {23606, "CHARS"}, {23608, "RASP"}, {23609, "PIP"}, {23610, "ERR NR"},
            {23611, "FLAGS"}, {23612, "TV FLAG"}, {23613, "ERR SP"}, {23615, "LIST SP"},
            {23617, "MODE"}, {23618, "NEWPPC"}, {23620, "NSPPC"}, {23621, "PPC"},
            {23623, "SUBPPC"}, {23624, "BORDERCR"}, {23625, "E PPC"}, {23627, "VARS"},
            {23629, "DEST"}, {23631, "CHANS"}, {23633, "CURCHL"}, {23635, "PROG"},
            {23637, "NXTLIN"}, {23639, "DATAADD"}, {23641, "E LINE"}, {23643, "K CUR"},
            {23645, "CH ADD"}, {23647, "X PTR"}, {23649, "WORKSP"}, {23651, "STKBOT"},
            {23653, "STKEND"}, {23655, "BREG"}, {23656, "MEM"}, {23658, "FLAGS2"},
            {23659, "DF SZ"}, {23660, "S TOP"}, {23662, "OLDPPC"}, {23664, "OSPPC"},
            {23665, "FLAGX"}, {23666, "STRLEN"}, {23668, "T ADDR"}, {23670, "SEED"},
            {23672, "FRAMES"}, {23675, "UDG"}, {23677, "COORDS"}, {23679, "P POSN"},
            {23680, "PR CC"}, {23682, "ECHO E"}, {23684, "DF CC"}, {23686, "DFCCL"},
            {23688, "S POSN"}, {23690, "SPOSNL"}, {23692, "SCR CT"}, {23693, "ATTR P"},
            {23694, "MASK P"}, {23695, "ATTR T"}, {23696, "MASK T"}, {23697, "P FLAG"},
            {23698, "MEMBOT"}, {23728, "NMIADD"}, {23730, "RAMTOP"}, {23732, "P RAMT"}
        };

        // ***********************************

        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [System.STAThread]
        private static void Main() {


            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            Form1 formA = new Form1();
            Application.Idle += new System.EventHandler(formA.OnApplicationIdle);
            Application.Run(formA);


        } // main
    }
}