﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Threading;

namespace ZeroWin
{
    public partial class CodeLabels : Form
    {
        private MonitorRef monitor = null;
        public CodeLabels(MonitorRef _monitor)
        {
            InitializeComponent();
            monitor = _monitor;
            // Set the view to show details.
            listView1.View = View.Details;
            // Allow the user to edit item text.
            listView1.LabelEdit = false;
            // Allow the user to rearrange columns.
            listView1.AllowColumnReorder = true;
            // Display check boxes.
            listView1.CheckBoxes = false;
            // Select the item and subitems when selection is made.
            listView1.FullRowSelect = true;
            // Display grid lines.
            listView1.GridLines = true;
            // Sort the items in the list in ascending order.
            listView1.Sorting = SortOrder.Ascending;
        }
        public int ListViewIndex;
        public int ItemSelector= -1;
        TextReader Rf;
    // Dictionary Operations
    // ----------------------------------------------------------------------
        void UploadCustomLabels()
            {
                int DictKey;
                string DictLabel;

                progressBar1.Visible = true;
                progressBar1.Maximum = (int)(listView1.Items.Count);
                progressBar1.Value = 0;
                for (int i = 0; i < listView1.Items.Count; i++)
                {
                    DictKey = Convert.ToInt32(listView1.Items[i].SubItems[0].Text.ToString(),16);
                    DictLabel = listView1.Items[i].SubItems[1].Text.ToString();
                    Program.CLabels_RMS.Add(DictKey, DictLabel);
                    progressBar1.Value = i+1;
                    this.Refresh();
                }
                progressBar1.Visible = false;
                monitor.Refresh();  // Refresh DissAsembly on Monitor form
            }
    // ListView Operations
    // ----------------------------------------------------------------------
        void ADD_Label(string item_1,string item_2)
            {
                string[] arr = new string[2];
                ListViewItem itm; //add items to ListView
                arr[0] = item_1;
                arr[1] = item_2;
                itm = new ListViewItem(arr);
                listView1.Items.Add(itm);
            }
        void GET_label()
            {
           
                if (listView1.SelectedItems != null)
                {
                    ItemSelector = listView1.FocusedItem.Index;
                    if (ItemSelector >= 0)
                    {
                        label3.Text = ItemSelector.ToString();
                        textBoxAddress.Text = listView1.Items[ItemSelector].SubItems[0].Text;
                        textBoxLabel.Text = listView1.Items[ItemSelector].SubItems[1].Text;
                    }
                    else
                    {
                        label3.Text = "";
                    }   
                }
            }
        void UPD_Label()
            {
                if (ItemSelector>=0)
                {
                
                    listView1.Items[ItemSelector].SubItems[0].Text = textBoxAddress.Text;
                    listView1.Items[ItemSelector].SubItems[1].Text = textBoxLabel.Text;
                }
            }
        void DEL_Label(int i)
            {
                if (i >= 0)
                {
                   listView1.Items[i].Remove();
                }
            }
        void CleanControl()
            {
                int NumItems;

                NumItems = listView1.Items.Count-1;
                progressBar1.Visible = true;
                progressBar1.Maximum = (int)(NumItems);
                progressBar1.Value = 0;

                for (int j = NumItems; j >= 0; j--)
                {
                    DEL_Label(j);
                    progressBar1.Value = j;
                    this.Refresh();

                }
                progressBar1.Visible = false;
            }
        void ImportLabelsFromFile()
            {
                string mapline;
                string LabelKey;
                string LabelName;
                long Rf_size;
                int Rf_read = 0;
                int Rf_NumLabels = 0;
                string Rf_name = "dynamite.map";
                FileInfo test_Rf;
                OpenFileDialog openFileDialog1 = new OpenFileDialog();
                string Rf_selection = "KO";

                // Set filter options and filter index.
                openFileDialog1.Filter = "IDA Pro (*.map)|*.map|All Files (*.*)|*.*";
                openFileDialog1.FilterIndex = 1;
                openFileDialog1.Multiselect = false;

                // Call the ShowDialog method to show the dialog box.
                Rf_selection = openFileDialog1.ShowDialog().ToString();

                if (Rf_selection == "OK")
                {
                    Rf_name = openFileDialog1.FileName;
                    test_Rf = new FileInfo(Rf_name);
                    Rf_size = test_Rf.Length;

                    if (Rf_size != 0)

                    {
                        progressBar1.Visible = true;
                        progressBar1.Maximum = (int)(Rf_size);
                        progressBar1.Value = 0;
                    }
                    Rf = new StreamReader(Rf_name);
                    while ((mapline = Rf.ReadLine()) != null)
                    {
                        if (mapline != "") { Rf_read = Rf_read + mapline.Length + 2; }
                        else Rf_read = Rf_read + 2;

                        if (mapline != "" && mapline.ElementAt(1) == '0') // Discard header
                        {
                            // Parse line
                            LabelKey = mapline.Substring(6, 4);
                            LabelName = mapline.Substring(16);
                            // MessageBox.Show(LabelKey + "/" + LabelName);
                            // Add 2 ListView
                            ADD_Label(LabelKey, LabelName);
                            Rf_NumLabels++;
                            //Thread.Sleep(10);
                        }
                        // gauge update
                        if (progressBar1.Visible) progressBar1.Value = Rf_read;
                        this.Refresh();
                    }
                    progressBar1.Value = 0;
                    progressBar1.Visible = false;
                    Rf.Close();
                    MessageBox.Show(Rf_NumLabels.ToString() + "  Labels imported!");
                }
                else
                {
                    MessageBox.Show("No action taken!");
                }

            }
        void listView1_SelectedIndexChanged(object sender, EventArgs e)
            {
               GET_label();
            }
    // Button Events
    // ----------------------------------------------------------------------
    // Add to list current editing label
        private void button2_Click(object sender, EventArgs e)
            {
                ADD_Label(textBoxAddress.Text,textBoxLabel.Text);
            }
    // Update Current editing label
        private void button3_Click(object sender, EventArgs e)
            {
                UPD_Label();
            }
    // Delete Current label
        private void button4_Click(object sender, EventArgs e)
            {
                DEL_Label(ItemSelector);
            }
    // Import labels from IDA pro files *.map
        private void button1_Click(object sender, EventArgs e)
            {
                ImportLabelsFromFile();
            }
    // Clean custom labels in form
        private void button6_Click(object sender, EventArgs e)
            {
                CleanControl();
            }
    // Add to Debugger
        private void button5_Click(object sender, EventArgs e)
        {
            UploadCustomLabels();
        }
    }
    }
