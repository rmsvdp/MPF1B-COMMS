﻿using System.Drawing;

namespace ZeroWin
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.folderBrowserDialog1 = new System.Windows.Forms.FolderBrowserDialog();
            this.panel1 = new System.Windows.Forms.Panel();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator11 = new System.Windows.Forms.ToolStripSeparator();
            this.loadBinaryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveBinaryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator18 = new System.Windows.Forms.ToolStripSeparator();
            this.machineToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.resetToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem6 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator13 = new System.Windows.Forms.ToolStripSeparator();
            this.Mpf1bItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.viewToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.renderingToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.directXToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gDIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.interlaceToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pixelToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.windowSizeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem5 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.debuggerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kKeyboardHelperToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutZeroToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator17 = new System.Windows.Forms.ToolStripSeparator();
            this.preferencesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton2 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator14 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton6 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton4 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator15 = new System.Windows.Forms.ToolStripSeparator();
            this.keyboard48Button = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton7 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton5 = new System.Windows.Forms.ToolStripButton();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.statusLabelText = new System.Windows.Forms.ToolStripStatusLabel();
            this.soundStatusLabel = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripSeparator8 = new System.Windows.Forms.ToolStripSeparator();
            this.button1 = new System.Windows.Forms.Button();
            this.ledHalt = new Bulb.LedBulb();
            this.ledBeep = new Bulb.LedBulb();
            this.ss0 = new Multitech.SevenSegment();
            this.ss1 = new Multitech.SevenSegment();
            this.ss2 = new Multitech.SevenSegment();
            this.ss3 = new Multitech.SevenSegment();
            this.ss4 = new Multitech.SevenSegment();
            this.ss5 = new Multitech.SevenSegment();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.menuStrip1.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // panel1
            // 
            resources.ApplyResources(this.panel1, "panel1");
            this.panel1.BackColor = System.Drawing.Color.DimGray;
            this.panel1.CausesValidation = false;
            this.panel1.Name = "panel1";
            // 
            // toolTip1
            // 
            this.toolTip1.UseAnimation = false;
            this.toolTip1.UseFading = false;
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.SystemColors.MenuBar;
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.machineToolStripMenuItem,
            this.viewToolStripMenuItem,
            this.toolsToolStripMenuItem});
            resources.ApplyResources(this.menuStrip1, "menuStrip1");
            this.menuStrip1.Name = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripSeparator11,
            this.loadBinaryToolStripMenuItem,
            this.saveBinaryToolStripMenuItem,
            this.toolStripSeparator18});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            resources.ApplyResources(this.fileToolStripMenuItem, "fileToolStripMenuItem");
            // 
            // toolStripSeparator11
            // 
            this.toolStripSeparator11.Name = "toolStripSeparator11";
            resources.ApplyResources(this.toolStripSeparator11, "toolStripSeparator11");
            // 
            // loadBinaryToolStripMenuItem
            // 
            this.loadBinaryToolStripMenuItem.Name = "loadBinaryToolStripMenuItem";
            resources.ApplyResources(this.loadBinaryToolStripMenuItem, "loadBinaryToolStripMenuItem");
            this.loadBinaryToolStripMenuItem.Click += new System.EventHandler(this.loadBinaryMenuItem1_Click);
            // 
            // saveBinaryToolStripMenuItem
            // 
            this.saveBinaryToolStripMenuItem.Name = "saveBinaryToolStripMenuItem";
            resources.ApplyResources(this.saveBinaryToolStripMenuItem, "saveBinaryToolStripMenuItem");
            this.saveBinaryToolStripMenuItem.Click += new System.EventHandler(this.saveBinaryMenuItem5_Click);
            // 
            // toolStripSeparator18
            // 
            this.toolStripSeparator18.Name = "toolStripSeparator18";
            resources.ApplyResources(this.toolStripSeparator18, "toolStripSeparator18");
            // 
            // machineToolStripMenuItem
            // 
            this.machineToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem3,
            this.resetToolStripMenuItem,
            this.toolStripMenuItem6,
            this.toolStripSeparator13,
            this.Mpf1bItem1});
            this.machineToolStripMenuItem.Name = "machineToolStripMenuItem";
            resources.ApplyResources(this.machineToolStripMenuItem, "machineToolStripMenuItem");
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Image = global::ZeroWin.Properties.Resources.refresh_16xLG;
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            resources.ApplyResources(this.toolStripMenuItem3, "toolStripMenuItem3");
            this.toolStripMenuItem3.Click += new System.EventHandler(this.toolStripMenuItem3_Click_1);
            // 
            // resetToolStripMenuItem
            // 
            this.resetToolStripMenuItem.Image = global::ZeroWin.Properties.Resources.power_on_off;
            this.resetToolStripMenuItem.Name = "resetToolStripMenuItem";
            resources.ApplyResources(this.resetToolStripMenuItem, "resetToolStripMenuItem");
            this.resetToolStripMenuItem.Click += new System.EventHandler(this.hardResetToolStripMenuItem1_Click);
            // 
            // toolStripMenuItem6
            // 
            this.toolStripMenuItem6.CheckOnClick = true;
            this.toolStripMenuItem6.Image = global::ZeroWin.Properties.Resources.Symbols_Pause_32xLG;
            this.toolStripMenuItem6.Name = "toolStripMenuItem6";
            resources.ApplyResources(this.toolStripMenuItem6, "toolStripMenuItem6");
            this.toolStripMenuItem6.Click += new System.EventHandler(this.pauseEmulationESCToolStripMenuItem_Click);
            // 
            // toolStripSeparator13
            // 
            this.toolStripSeparator13.Name = "toolStripSeparator13";
            resources.ApplyResources(this.toolStripSeparator13, "toolStripSeparator13");
            this.toolStripSeparator13.Click += new System.EventHandler(this.toolStripSeparator13_Click);
            // 
            // Mpf1bItem1
            // 
            this.Mpf1bItem1.Name = "Mpf1bItem1";
            resources.ApplyResources(this.Mpf1bItem1, "Mpf1bItem1");
            this.Mpf1bItem1.Click += new System.EventHandler(this.mpf1bToolStripMenuItem_Click);
            // 
            // viewToolStripMenuItem
            // 
            this.viewToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.renderingToolStripMenuItem,
            this.windowSizeToolStripMenuItem});
            this.viewToolStripMenuItem.Name = "viewToolStripMenuItem";
            resources.ApplyResources(this.viewToolStripMenuItem, "viewToolStripMenuItem");
            // 
            // renderingToolStripMenuItem
            // 
            this.renderingToolStripMenuItem.BackColor = System.Drawing.SystemColors.Control;
            this.renderingToolStripMenuItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.renderingToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.directXToolStripMenuItem,
            this.gDIToolStripMenuItem,
            this.toolStripSeparator3,
            this.interlaceToolStripMenuItem,
            this.pixelToolStripMenuItem});
            this.renderingToolStripMenuItem.ForeColor = System.Drawing.SystemColors.ControlText;
            this.renderingToolStripMenuItem.Name = "renderingToolStripMenuItem";
            resources.ApplyResources(this.renderingToolStripMenuItem, "renderingToolStripMenuItem");
            // 
            // directXToolStripMenuItem
            // 
            this.directXToolStripMenuItem.Checked = true;
            this.directXToolStripMenuItem.CheckOnClick = true;
            this.directXToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked;
            this.directXToolStripMenuItem.Name = "directXToolStripMenuItem";
            resources.ApplyResources(this.directXToolStripMenuItem, "directXToolStripMenuItem");
            this.directXToolStripMenuItem.Click += new System.EventHandler(this.directXToolStripMenuItem_Click);
            // 
            // gDIToolStripMenuItem
            // 
            this.gDIToolStripMenuItem.CheckOnClick = true;
            this.gDIToolStripMenuItem.Name = "gDIToolStripMenuItem";
            resources.ApplyResources(this.gDIToolStripMenuItem, "gDIToolStripMenuItem");
            this.gDIToolStripMenuItem.Click += new System.EventHandler(this.gDIToolStripMenuItem_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            resources.ApplyResources(this.toolStripSeparator3, "toolStripSeparator3");
            // 
            // interlaceToolStripMenuItem
            // 
            this.interlaceToolStripMenuItem.CheckOnClick = true;
            this.interlaceToolStripMenuItem.Name = "interlaceToolStripMenuItem";
            resources.ApplyResources(this.interlaceToolStripMenuItem, "interlaceToolStripMenuItem");
            this.interlaceToolStripMenuItem.Click += new System.EventHandler(this.interlaceToolStripMenuItem_Click);
            // 
            // pixelToolStripMenuItem
            // 
            this.pixelToolStripMenuItem.CheckOnClick = true;
            this.pixelToolStripMenuItem.Name = "pixelToolStripMenuItem";
            resources.ApplyResources(this.pixelToolStripMenuItem, "pixelToolStripMenuItem");
            this.pixelToolStripMenuItem.Click += new System.EventHandler(this.pixelToolStripMenuItem_Click);
            // 
            // windowSizeToolStripMenuItem
            // 
            this.windowSizeToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem2,
            this.toolStripMenuItem5,
            this.toolStripMenuItem1});
            this.windowSizeToolStripMenuItem.Name = "windowSizeToolStripMenuItem";
            resources.ApplyResources(this.windowSizeToolStripMenuItem, "windowSizeToolStripMenuItem");
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            resources.ApplyResources(this.toolStripMenuItem2, "toolStripMenuItem2");
            this.toolStripMenuItem2.Click += new System.EventHandler(this.size100ToolStripMenuItem_Click);
            // 
            // toolStripMenuItem5
            // 
            this.toolStripMenuItem5.Name = "toolStripMenuItem5";
            resources.ApplyResources(this.toolStripMenuItem5, "toolStripMenuItem5");
            this.toolStripMenuItem5.Click += new System.EventHandler(this.toolStripMenuItem5_Click_1);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            resources.ApplyResources(this.toolStripMenuItem1, "toolStripMenuItem1");
            this.toolStripMenuItem1.Click += new System.EventHandler(this.toolStripMenuItem1_Click);
            // 
            // toolsToolStripMenuItem
            // 
            this.toolsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.debuggerToolStripMenuItem,
            this.kKeyboardHelperToolStripMenuItem,
            this.aboutZeroToolStripMenuItem,
            this.toolStripSeparator17,
            this.preferencesToolStripMenuItem});
            this.toolsToolStripMenuItem.Name = "toolsToolStripMenuItem";
            resources.ApplyResources(this.toolsToolStripMenuItem, "toolsToolStripMenuItem");
            // 
            // debuggerToolStripMenuItem
            // 
            this.debuggerToolStripMenuItem.Image = global::ZeroWin.Properties.Resources.DisassemblyWindow_6536;
            this.debuggerToolStripMenuItem.Name = "debuggerToolStripMenuItem";
            resources.ApplyResources(this.debuggerToolStripMenuItem, "debuggerToolStripMenuItem");
            this.debuggerToolStripMenuItem.Click += new System.EventHandler(this.monitorButton_Click);
            // 
            // kKeyboardHelperToolStripMenuItem
            // 
            this.kKeyboardHelperToolStripMenuItem.Image = global::ZeroWin.Properties.Resources.zx_mini_kb;
            this.kKeyboardHelperToolStripMenuItem.Name = "kKeyboardHelperToolStripMenuItem";
            resources.ApplyResources(this.kKeyboardHelperToolStripMenuItem, "kKeyboardHelperToolStripMenuItem");
            this.kKeyboardHelperToolStripMenuItem.Click += new System.EventHandler(this.toolStripMenuItem3_Click);
            // 
            // aboutZeroToolStripMenuItem
            // 
            this.aboutZeroToolStripMenuItem.Image = global::ZeroWin.Properties.Resources.info;
            this.aboutZeroToolStripMenuItem.Name = "aboutZeroToolStripMenuItem";
            resources.ApplyResources(this.aboutZeroToolStripMenuItem, "aboutZeroToolStripMenuItem");
            this.aboutZeroToolStripMenuItem.Click += new System.EventHandler(this.aboutButton_Click);
            // 
            // toolStripSeparator17
            // 
            this.toolStripSeparator17.Name = "toolStripSeparator17";
            resources.ApplyResources(this.toolStripSeparator17, "toolStripSeparator17");
            // 
            // preferencesToolStripMenuItem
            // 
            this.preferencesToolStripMenuItem.Image = global::ZeroWin.Properties.Resources.gear_16xLG;
            this.preferencesToolStripMenuItem.Name = "preferencesToolStripMenuItem";
            resources.ApplyResources(this.preferencesToolStripMenuItem, "preferencesToolStripMenuItem");
            this.preferencesToolStripMenuItem.Click += new System.EventHandler(this.optionsButton_Click);
            // 
            // toolStrip1
            // 
            this.toolStrip1.BackColor = System.Drawing.SystemColors.Control;
            this.toolStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.toolStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton1,
            this.toolStripButton2,
            this.toolStripSeparator14,
            this.toolStripButton6,
            this.toolStripButton4,
            this.toolStripSeparator15,
            this.keyboard48Button,
            this.toolStripButton7,
            this.toolStripSeparator1,
            this.toolStripButton5});
            this.toolStrip1.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.HorizontalStackWithOverflow;
            resources.ApplyResources(this.toolStrip1, "toolStrip1");
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.System;
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton1.Image = global::ZeroWin.Properties.Resources.folder_Open_16xLG;
            resources.ApplyResources(this.toolStripButton1, "toolStripButton1");
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Click += new System.EventHandler(this.openFileMenuItem1_Click);
            // 
            // toolStripButton2
            // 
            this.toolStripButton2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton2.Image = global::ZeroWin.Properties.Resources.save_16xLG;
            resources.ApplyResources(this.toolStripButton2, "toolStripButton2");
            this.toolStripButton2.Name = "toolStripButton2";
            this.toolStripButton2.Click += new System.EventHandler(this.toolStripButton2_Click);
            // 
            // toolStripSeparator14
            // 
            this.toolStripSeparator14.Name = "toolStripSeparator14";
            resources.ApplyResources(this.toolStripSeparator14, "toolStripSeparator14");
            // 
            // toolStripButton6
            // 
            this.toolStripButton6.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton6.Image = global::ZeroWin.Properties.Resources.power_on_off;
            resources.ApplyResources(this.toolStripButton6, "toolStripButton6");
            this.toolStripButton6.Name = "toolStripButton6";
            this.toolStripButton6.Click += new System.EventHandler(this.hardResetToolStripMenuItem1_Click);
            // 
            // toolStripButton4
            // 
            this.toolStripButton4.CheckOnClick = true;
            this.toolStripButton4.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton4.Image = global::ZeroWin.Properties.Resources.Symbols_Pause_16xLG;
            resources.ApplyResources(this.toolStripButton4, "toolStripButton4");
            this.toolStripButton4.Name = "toolStripButton4";
            this.toolStripButton4.Click += new System.EventHandler(this.pauseEmulationESCToolStripMenuItem_Click);
            // 
            // toolStripSeparator15
            // 
            this.toolStripSeparator15.Name = "toolStripSeparator15";
            resources.ApplyResources(this.toolStripSeparator15, "toolStripSeparator15");
            // 
            // keyboard48Button
            // 
            this.keyboard48Button.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.keyboard48Button.Image = global::ZeroWin.Properties.Resources.keyboard_16x16;
            resources.ApplyResources(this.keyboard48Button, "keyboard48Button");
            this.keyboard48Button.Name = "keyboard48Button";
            this.keyboard48Button.Click += new System.EventHandler(this.toolStripMenuItem3_Click);
            // 
            // toolStripButton7
            // 
            this.toolStripButton7.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton7.Image = global::ZeroWin.Properties.Resources.DisassemblyWindow_6536;
            resources.ApplyResources(this.toolStripButton7, "toolStripButton7");
            this.toolStripButton7.Name = "toolStripButton7";
            this.toolStripButton7.Click += new System.EventHandler(this.monitorButton_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            resources.ApplyResources(this.toolStripSeparator1, "toolStripSeparator1");
            // 
            // toolStripButton5
            // 
            this.toolStripButton5.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton5.Image = global::ZeroWin.Properties.Resources.gear_16xLG;
            resources.ApplyResources(this.toolStripButton5, "toolStripButton5");
            this.toolStripButton5.Name = "toolStripButton5";
            this.toolStripButton5.Click += new System.EventHandler(this.optionsButton_Click);
            // 
            // statusStrip1
            // 
            this.statusStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.statusLabelText,
            this.soundStatusLabel,
            this.toolStripStatusLabel1});
            resources.ApplyResources(this.statusStrip1, "statusStrip1");
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.ShowItemToolTips = true;
            this.statusStrip1.SizingGrip = false;
            // 
            // statusLabelText
            // 
            resources.ApplyResources(this.statusLabelText, "statusLabelText");
            this.statusLabelText.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.statusLabelText.BorderStyle = System.Windows.Forms.Border3DStyle.Adjust;
            this.statusLabelText.Name = "statusLabelText";
            this.statusLabelText.Spring = true;
            // 
            // soundStatusLabel
            // 
            this.soundStatusLabel.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.soundStatusLabel.BorderStyle = System.Windows.Forms.Border3DStyle.Adjust;
            this.soundStatusLabel.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.soundStatusLabel.Image = global::ZeroWin.Properties.Resources.sound_high;
            this.soundStatusLabel.Name = "soundStatusLabel";
            resources.ApplyResources(this.soundStatusLabel, "soundStatusLabel");
            this.soundStatusLabel.Click += new System.EventHandler(this.soundStatusLabel_Click);
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            resources.ApplyResources(this.toolStripStatusLabel1, "toolStripStatusLabel1");
            // 
            // toolStripSeparator8
            // 
            this.toolStripSeparator8.Name = "toolStripSeparator8";
            resources.ApplyResources(this.toolStripSeparator8, "toolStripSeparator8");
            // 
            // button1
            // 
            resources.ApplyResources(this.button1, "button1");
            this.button1.Name = "button1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // ledHalt
            // 
            this.ledHalt.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ledHalt.Color = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.ledHalt.DarkDarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            resources.ApplyResources(this.ledHalt, "ledHalt");
            this.ledHalt.Name = "ledHalt";
            this.ledHalt.On = false;
            // 
            // ledBeep
            // 
            this.ledBeep.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ledBeep.Color = System.Drawing.Color.GreenYellow;
            this.ledBeep.DarkDarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            resources.ApplyResources(this.ledBeep, "ledBeep");
            this.ledBeep.Name = "ledBeep";
            this.ledBeep.On = false;
            // 
            // ss0
            // 
            this.ss0.ColonOn = false;
            this.ss0.ColonShow = false;
            this.ss0.ColorBackground = System.Drawing.Color.Black;
            this.ss0.ColorDark = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.ss0.ColorLight = System.Drawing.Color.Red;
            this.ss0.CustomPattern = 8;
            this.ss0.DecimalOn = false;
            this.ss0.DecimalShow = true;
            this.ss0.ElementWidth = 10;
            this.ss0.ItalicFactor = 0F;
            resources.ApplyResources(this.ss0, "ss0");
            this.ss0.Name = "ss0";
            this.ss0.TabStop = false;
            this.ss0.Value = "-";
            // 
            // ss1
            // 
            this.ss1.ColonOn = false;
            this.ss1.ColonShow = false;
            this.ss1.ColorBackground = System.Drawing.Color.Black;
            this.ss1.ColorDark = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.ss1.ColorLight = System.Drawing.Color.Red;
            this.ss1.CustomPattern = 8;
            this.ss1.DecimalOn = false;
            this.ss1.DecimalShow = true;
            this.ss1.ElementWidth = 10;
            this.ss1.ItalicFactor = 0F;
            resources.ApplyResources(this.ss1, "ss1");
            this.ss1.Name = "ss1";
            this.ss1.TabStop = false;
            this.ss1.Value = "-";
            // 
            // ss2
            // 
            this.ss2.ColonOn = false;
            this.ss2.ColonShow = false;
            this.ss2.ColorBackground = System.Drawing.Color.Black;
            this.ss2.ColorDark = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.ss2.ColorLight = System.Drawing.Color.Red;
            this.ss2.CustomPattern = 8;
            this.ss2.DecimalOn = false;
            this.ss2.DecimalShow = true;
            this.ss2.ElementWidth = 10;
            this.ss2.ItalicFactor = 0F;
            resources.ApplyResources(this.ss2, "ss2");
            this.ss2.Name = "ss2";
            this.ss2.TabStop = false;
            this.ss2.Value = "-";
            // 
            // ss3
            // 
            this.ss3.ColonOn = false;
            this.ss3.ColonShow = false;
            this.ss3.ColorBackground = System.Drawing.Color.Black;
            this.ss3.ColorDark = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.ss3.ColorLight = System.Drawing.Color.Red;
            this.ss3.CustomPattern = 8;
            this.ss3.DecimalOn = false;
            this.ss3.DecimalShow = true;
            this.ss3.ElementWidth = 10;
            this.ss3.ItalicFactor = 0F;
            resources.ApplyResources(this.ss3, "ss3");
            this.ss3.Name = "ss3";
            this.ss3.TabStop = false;
            this.ss3.Value = "-";
            // 
            // ss4
            // 
            this.ss4.ColonOn = false;
            this.ss4.ColonShow = false;
            this.ss4.ColorBackground = System.Drawing.Color.Black;
            this.ss4.ColorDark = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.ss4.ColorLight = System.Drawing.Color.Red;
            this.ss4.CustomPattern = 8;
            this.ss4.DecimalOn = false;
            this.ss4.DecimalShow = true;
            this.ss4.ElementWidth = 10;
            this.ss4.ItalicFactor = 0F;
            resources.ApplyResources(this.ss4, "ss4");
            this.ss4.Name = "ss4";
            this.ss4.TabStop = false;
            this.ss4.Value = "-";
            // 
            // ss5
            // 
            this.ss5.ColonOn = false;
            this.ss5.ColonShow = false;
            this.ss5.ColorBackground = System.Drawing.Color.Black;
            this.ss5.ColorDark = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.ss5.ColorLight = System.Drawing.Color.Red;
            this.ss5.CustomPattern = 8;
            this.ss5.DecimalOn = false;
            this.ss5.DecimalShow = true;
            this.ss5.ElementWidth = 10;
            this.ss5.ItalicFactor = 0F;
            resources.ApplyResources(this.ss5, "ss5");
            this.ss5.Name = "ss5";
            this.ss5.TabStop = false;
            this.ss5.Value = "-";
            // 
            // label1
            // 
            resources.ApplyResources(this.label1, "label1");
            this.label1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label1.Name = "label1";
            // 
            // label2
            // 
            resources.ApplyResources(this.label2, "label2");
            this.label2.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label2.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label2.Name = "label2";
            // 
            // Form1
            // 
            this.AllowDrop = true;
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.SystemColors.Control;
            resources.ApplyResources(this, "$this");
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.ledHalt);
            this.Controls.Add(this.ledBeep);
            this.Controls.Add(this.ss0);
            this.Controls.Add(this.ss1);
            this.Controls.Add(this.ss2);
            this.Controls.Add(this.ss3);
            this.Controls.Add(this.ss4);
            this.Controls.Add(this.ss5);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.panel1);
            this.DoubleBuffered = true;
            this.KeyPreview = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.ResizeBegin += new System.EventHandler(this.Form1_ResizeBegin);
            this.ResizeEnd += new System.EventHandler(this.Form1_ResizeEnd);
            this.Resize += new System.EventHandler(this.Form1_Resize);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator11;
        private System.Windows.Forms.ToolStripMenuItem loadBinaryToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveBinaryToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem machineToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem resetToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator13;
        private System.Windows.Forms.ToolStripMenuItem Mpf1bItem1;
        private System.Windows.Forms.ToolStripMenuItem viewToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem windowSizeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem6;
        private System.Windows.Forms.ToolStripMenuItem toolsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem debuggerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem kKeyboardHelperToolStripMenuItem;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.ToolStripButton toolStripButton2;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator14;
        private System.Windows.Forms.ToolStripButton toolStripButton4;
        private System.Windows.Forms.ToolStripButton toolStripButton5;
        private System.Windows.Forms.ToolStripButton toolStripButton6;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator15;
        private System.Windows.Forms.ToolStripButton toolStripButton7;
        private System.Windows.Forms.ToolStripMenuItem renderingToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem directXToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gDIToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripMenuItem interlaceToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pixelToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem5;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem aboutZeroToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator17;
        private System.Windows.Forms.ToolStripMenuItem preferencesToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator18;
        private System.Windows.Forms.ToolStripStatusLabel statusLabelText;
        private System.Windows.Forms.ToolStripStatusLabel soundStatusLabel;
        private System.Windows.Forms.ToolStripButton keyboard48Button;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator8;
        private System.Windows.Forms.Button button1;
        private Multitech.SevenSegment ss5;
        private Multitech.SevenSegment ss4;
        private Multitech.SevenSegment ss3;
        private Multitech.SevenSegment ss2;
        private Multitech.SevenSegment ss1;
        private Multitech.SevenSegment ss0;
        private Bulb.LedBulb ledHalt;
        private Bulb.LedBulb ledBeep;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem3;
    }
}

