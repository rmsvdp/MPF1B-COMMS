﻿namespace ZeroWin
{
    public class ZeroConfig
    {
        #region properties

        private string applicationPath = "";

        public string ApplicationPath {
            get { return applicationPath; }
            set { applicationPath = value; }
        }

        private bool showInterlace = false;

        public bool EnableInterlacedOverlay {
            get { return showInterlace; }
            set { showInterlace = value; }
        }

        private Multitech.MachineModel model = Multitech.MachineModel._mpf;

        public Multitech.MachineModel Model {
            get { return model; }
            set { model = value; }
        }

        private int volume = 50;

        public int Volume {
            get { return volume; }
            set { volume = value; }
        }

        private bool mute = false;

        public bool MuteSound {
            get { return mute; }
            set { mute = value; }
        }

        //Speaker setup: 0 = Mono, 1 = ACB, 2 = ABC
        private int stereoSoundOption = 1;

        public int StereoSoundOption {
            get { return stereoSoundOption; }
            set { stereoSoundOption = value; }
        }

        private int windowSize = 0;

        public int WindowSize {
            get { return windowSize; }
            set { windowSize = value; }
        }

        private int fullScreenWidth = 800;

        public int FullScreenWidth {
            get { return fullScreenWidth; }
            set { fullScreenWidth = value; }
        }
        private int fullScreenHeight = 600;

        public int FullScreenHeight {
            get { return fullScreenHeight; }
            set { fullScreenHeight = value; }
        }

        private bool fullScreenFormat16 = false;

        public bool FullScreenFormat16 {
            get { return fullScreenFormat16; }
            set { fullScreenFormat16 = value; }
        }

        private bool fullScreen = false;

        public bool FullScreen {
            get { return fullScreen; }
            set { fullScreen = value; }
        }

        //private int interpolationMode = 0;
        private string romPath = @"\roms\";

        public string PathRoms {
            get { return romPath; }
            set { romPath = value; }
        }

        private string gamePath = @"\programs\";

        public string PathGames {
            get { return gamePath; }
            set { gamePath = value; }
        }

        private string gameSavePath = @"\saves\";

        public string PathGameSaves {
            get { return gameSavePath; }
            set { gameSavePath = value; }
        }

        private string screenshotPath = @"\screenshots\";

        public string PathScreenshots {
            get { return screenshotPath; }
            set { screenshotPath = value; }
        }

        //private string gameCheatPath = @"\cheats\";

        //public string PathCheats {
        //    get { return gameCheatPath; }
        //    set { gameCheatPath = value; }
        //}

        private string gameInfoPath = @"\info\";

        public string PathInfos {
            get { return gameInfoPath; }
            set { gameInfoPath = value; }
        }

        private string current48kRom = @"48k.rom";

        public string Current48kROM {
            get { return current48kRom; }
            set { current48kRom = value; }
        }

        public string currentMpf1bRom = @"mpf1b.rom"; // Copiamos la misma ROM

        public string CurrentMpf1bROM {
            get { return currentMpf1bRom; }
            set { currentMpf1bRom = value; }
        }

        public string currentModel = "mpf1b";

        public string CurrentMPFModel {
            get { return currentModel; }
            set { currentModel = value; }
        }

        private string paletteMode = "Normal";

        public string PaletteMode {
            get { return paletteMode; }
            set { paletteMode = value; }
        }

        private int emulationSpeed = 100;

        public int EmulationSpeed {
            get { return emulationSpeed; }
            set { emulationSpeed = value; }
        }

        private bool lateTiming = false;

        public bool UseLateTimings {
            get { return lateTiming; }
            set { lateTiming = value; }
        }

        //private bool issue2keyboard = false;

        private bool useDirectX = true;

        public bool UseDirectX {
            get { return useDirectX; }
            set { useDirectX = value; }
        }

         private bool pauseOnFocusChange = true;

        public bool PauseOnFocusLost {
            get { return pauseOnFocusChange; }
            set { pauseOnFocusChange = value; }
        }

        private bool confirmOnExit = true;

        public bool ConfirmOnExit {
            get { return confirmOnExit; }
            set { confirmOnExit = value; }
        }

        private bool soundOn = true;

        public bool EnableSound {
            get { return soundOn; }
            set { soundOn = value; }
        }

        private bool fullSpeed = false;

        public bool FullSpeedEmulation {
            get { return fullSpeed; }
            set { fullSpeed = value; }
        }

        private int borderWidthAdjust = 0;

        public int BorderSize {
            get { return borderWidthAdjust; }
            set { borderWidthAdjust = value; }
        }

        private bool onscreenLED = true;

        public bool ShowOnscreenIndicators {
            get { return onscreenLED; }
            set { onscreenLED = value; }
        }

        private bool restoreLastStateOnStart = false;

        public bool RestoreLastStateOnStart {
            get { return restoreLastStateOnStart; }
            set { restoreLastStateOnStart = value; }
        }

        private bool pixelSmoothing = false;

        public bool EnablePixelSmoothing {
            get { return pixelSmoothing; }
            set { pixelSmoothing = value; }
        }

        private bool enableVsync = false;

        public bool EnableVSync {
            get { return enableVsync; }
            set { enableVsync = value; }
        }

        private bool maintainAspectRatioInFullScreen = true;

        public bool MaintainAspectRatioInFullScreen
        {
            get { return maintainAspectRatioInFullScreen; }
            set { maintainAspectRatioInFullScreen = value; }
        }

        #endregion properties

        public void Load() {
            current48kRom = "48k.rom";          // Properties.Settings.Default.ROM48k;
            currentMpf1bRom = "mpf1b.rom";   // Properties.Settings.Default.ROMMPF1B;
            romPath = Properties.Settings.Default.PathROM;
            gamePath = Properties.Settings.Default.PathPrograms;
            if (gamePath == "") {  gamePath = System.Windows.Forms.Application.StartupPath + "\\programs";  }
            screenshotPath = Properties.Settings.Default.PathScreenshots;
            currentModel = Properties.Settings.Default.Model;
            useDirectX = Properties.Settings.Default.UseDirectX;
            fullScreen = Properties.Settings.Default.StartFullscreen;
            maintainAspectRatioInFullScreen = Properties.Settings.Default.MaintainAspectRatioInFullScreen;
            windowSize = (int)Properties.Settings.Default.WindowSize;
            fullScreenWidth = Properties.Settings.Default.FullScreenWidth;
            fullScreenHeight = Properties.Settings.Default.FullScreenHeight;
            fullScreenFormat16 = Properties.Settings.Default.FullScreenFormat16;
            windowSize = (int)Properties.Settings.Default.WindowSize;
            paletteMode = Properties.Settings.Default.Palette;
            borderWidthAdjust = (int)Properties.Settings.Default.BorderSize;
            volume = Properties.Settings.Default.Volume;
            mute = Properties.Settings.Default.Mute;
            stereoSoundOption = Properties.Settings.Default.SpeakerSetup;
            pauseOnFocusChange = Properties.Settings.Default.PauseOnFocusChange;
            onscreenLED = Properties.Settings.Default.ShowOnScreenLEDs;
            restoreLastStateOnStart = Properties.Settings.Default.RestoreLastStateOnStart;
            confirmOnExit = Properties.Settings.Default.ConfirmOnExit;
            lateTiming = Properties.Settings.Default.TimingModel;
            emulationSpeed = Properties.Settings.Default.EmulationSpeed;

        }

        public void Save() {
            Properties.Settings.Default.ROM48k = current48kRom;
            Properties.Settings.Default.ROMMPF1B = currentMpf1bRom;
            Properties.Settings.Default.PathROM = romPath;
            Properties.Settings.Default.PathPrograms = gamePath;
            Properties.Settings.Default.PathScreenshots = screenshotPath;
            Properties.Settings.Default.Model = currentModel;
            Properties.Settings.Default.UseDirectX = useDirectX;
            Properties.Settings.Default.EnableVSync = enableVsync;
            Properties.Settings.Default.StartFullscreen = fullScreen;
            Properties.Settings.Default.MaintainAspectRatioInFullScreen = maintainAspectRatioInFullScreen;
            Properties.Settings.Default.WindowSize = (byte)windowSize;
            Properties.Settings.Default.FullScreenWidth = fullScreenWidth;
            Properties.Settings.Default.FullScreenHeight = fullScreenHeight;
            Properties.Settings.Default.FullScreenFormat16 = fullScreenFormat16;
            Properties.Settings.Default.Palette = paletteMode;
            Properties.Settings.Default.BorderSize = (byte)borderWidthAdjust;
            Properties.Settings.Default.Volume = (byte)volume;
            Properties.Settings.Default.Mute = mute;
            Properties.Settings.Default.SpeakerSetup = (byte)stereoSoundOption;
            Properties.Settings.Default.PauseOnFocusChange = pauseOnFocusChange;
            Properties.Settings.Default.ShowOnScreenLEDs = onscreenLED;
            Properties.Settings.Default.RestoreLastStateOnStart = restoreLastStateOnStart;
            Properties.Settings.Default.ConfirmOnExit = confirmOnExit;
            Properties.Settings.Default.TimingModel = lateTiming;
            Properties.Settings.Default.EmulationSpeed = emulationSpeed;
            Properties.Settings.Default.Save();
        }

    }
}