﻿namespace ZeroWin
{
    partial class MonitorRef
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MonitorRef));
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.toolStrip2 = new System.Windows.Forms.ToolStrip();
            this.ResumeEmulationButton = new System.Windows.Forms.ToolStripButton();
            this.RunToCursorButton = new System.Windows.Forms.ToolStripButton();
            this.StopDebuggerButton = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.StepInButton = new System.Windows.Forms.ToolStripButton();
            this.StepOutButton = new System.Windows.Forms.ToolStripButton();
            this.StepOverButton = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.ToggleBreakpointButton = new System.Windows.Forms.ToolStripButton();
            this.ClearAllBreakpointsButton = new System.Windows.Forms.ToolStripButton();
            this.BreakpointsButton = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.MemoryButton = new System.Windows.Forms.ToolStripButton();
            this.RegistersButton = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.ProfilerButton = new System.Windows.Forms.ToolStripButton();
            this.PokeMemoryButton = new System.Windows.Forms.ToolStripButton();
            this.callStackButton = new System.Windows.Forms.ToolStripButton();
            this.jumpAddrTextBox4 = new System.Windows.Forms.MaskedTextBox();
            this.jumpAddrButton = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.debugToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.resumeEmulationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.runToCursorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.stopDebuggingToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.stepOverToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.stepInToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.stepOutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.breakpointsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toggleBreakpointToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.clearAllBreakpointsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.breakpointsEditorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.machineStateToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.memoryViewerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.registersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator6 = new System.Windows.Forms.ToolStripSeparator();
            this.executionLogToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pokeMemoryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.systemToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aSCIICharactersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.numbersInHexToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.systemVariablesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.labelsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.monitorStatusLabel = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.callStack = new System.Windows.Forms.ToolStripButton();
            this.toolStrip2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // toolStrip2
            // 
            this.toolStrip2.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.toolStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ResumeEmulationButton,
            this.RunToCursorButton,
            this.StopDebuggerButton,
            this.toolStripSeparator2,
            this.StepInButton,
            this.StepOutButton,
            this.StepOverButton,
            this.toolStripSeparator3,
            this.ToggleBreakpointButton,
            this.ClearAllBreakpointsButton,
            this.BreakpointsButton,
            this.toolStripSeparator4,
            this.RegistersButton,
            this.callStack,
            this.MemoryButton,
            this.toolStripSeparator5,
            this.ProfilerButton,
            this.PokeMemoryButton,
            this.callStackButton});
            this.toolStrip2.Location = new System.Drawing.Point(0, 28);
            this.toolStrip2.Name = "toolStrip2";
            this.toolStrip2.Size = new System.Drawing.Size(372, 27);
            this.toolStrip2.TabIndex = 7;
            this.toolStrip2.Text = "toolStrip2";
            // 
            // ResumeEmulationButton
            // 
            this.ResumeEmulationButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.ResumeEmulationButton.Image = global::ZeroWin.Properties.Resources.PlayHS;
            this.ResumeEmulationButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.ResumeEmulationButton.Name = "ResumeEmulationButton";
            this.ResumeEmulationButton.Size = new System.Drawing.Size(24, 24);
            this.ResumeEmulationButton.Text = "Resume Emulation";
            this.ResumeEmulationButton.ToolTipText = "Resume emulation";
            this.ResumeEmulationButton.Click += new System.EventHandler(this.ResumeEmulationButton_Click);
            // 
            // RunToCursorButton
            // 
            this.RunToCursorButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.RunToCursorButton.Image = global::ZeroWin.Properties.Resources.GoToSourceCode_6546;
            this.RunToCursorButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.RunToCursorButton.Name = "RunToCursorButton";
            this.RunToCursorButton.Size = new System.Drawing.Size(24, 24);
            this.RunToCursorButton.Text = "Run to Cursor";
            this.RunToCursorButton.ToolTipText = "Run to cursor";
            this.RunToCursorButton.Click += new System.EventHandler(this.RunToCursorButton_Click);
            // 
            // StopDebuggerButton
            // 
            this.StopDebuggerButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.StopDebuggerButton.Image = global::ZeroWin.Properties.Resources.StopHS;
            this.StopDebuggerButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.StopDebuggerButton.Name = "StopDebuggerButton";
            this.StopDebuggerButton.Size = new System.Drawing.Size(24, 24);
            this.StopDebuggerButton.Text = "Stop Debugging";
            this.StopDebuggerButton.ToolTipText = "Stop Debugging";
            this.StopDebuggerButton.Click += new System.EventHandler(this.StopDebuggerButton_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 27);
            // 
            // StepInButton
            // 
            this.StepInButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.StepInButton.Image = global::ZeroWin.Properties.Resources.StepIn_6326;
            this.StepInButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.StepInButton.Name = "StepInButton";
            this.StepInButton.Size = new System.Drawing.Size(24, 24);
            this.StepInButton.Text = "Step Into";
            this.StepInButton.ToolTipText = "Step Into";
            this.StepInButton.Click += new System.EventHandler(this.StepInButton_Click);
            // 
            // StepOutButton
            // 
            this.StepOutButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.StepOutButton.Image = global::ZeroWin.Properties.Resources.Stepout_6327;
            this.StepOutButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.StepOutButton.Name = "StepOutButton";
            this.StepOutButton.Size = new System.Drawing.Size(24, 24);
            this.StepOutButton.Text = "Step Out";
            this.StepOutButton.ToolTipText = "Step Out";
            this.StepOutButton.Click += new System.EventHandler(this.StepOutButton_Click);
            // 
            // StepOverButton
            // 
            this.StepOverButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.StepOverButton.Image = global::ZeroWin.Properties.Resources.StepOver_6328;
            this.StepOverButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.StepOverButton.Name = "StepOverButton";
            this.StepOverButton.Size = new System.Drawing.Size(24, 24);
            this.StepOverButton.Text = "Step Over";
            this.StepOverButton.ToolTipText = "Step Over";
            this.StepOverButton.Click += new System.EventHandler(this.StepOverButton_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 27);
            // 
            // ToggleBreakpointButton
            // 
            this.ToggleBreakpointButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.ToggleBreakpointButton.Image = global::ZeroWin.Properties.Resources.ToggleAllBreakpoints_6554;
            this.ToggleBreakpointButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.ToggleBreakpointButton.Name = "ToggleBreakpointButton";
            this.ToggleBreakpointButton.Size = new System.Drawing.Size(24, 24);
            this.ToggleBreakpointButton.Text = "Toggle Breakpoint";
            this.ToggleBreakpointButton.ToolTipText = "Toggle Breakpoint";
            this.ToggleBreakpointButton.Click += new System.EventHandler(this.ToggleBreakpointButton_Click);
            // 
            // ClearAllBreakpointsButton
            // 
            this.ClearAllBreakpointsButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.ClearAllBreakpointsButton.Image = global::ZeroWin.Properties.Resources.clearallbreakpoints_6551;
            this.ClearAllBreakpointsButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.ClearAllBreakpointsButton.Name = "ClearAllBreakpointsButton";
            this.ClearAllBreakpointsButton.Size = new System.Drawing.Size(24, 24);
            this.ClearAllBreakpointsButton.Text = "Clear All Breakpoints";
            this.ClearAllBreakpointsButton.ToolTipText = "Clear All Breakpoint";
            this.ClearAllBreakpointsButton.Click += new System.EventHandler(this.ClearAllBreakpointsButton_Click);
            // 
            // BreakpointsButton
            // 
            this.BreakpointsButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.BreakpointsButton.Image = global::ZeroWin.Properties.Resources.BreakpointsWindow_6557;
            this.BreakpointsButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.BreakpointsButton.Name = "BreakpointsButton";
            this.BreakpointsButton.Size = new System.Drawing.Size(24, 24);
            this.BreakpointsButton.Text = "Breakpoint Editor";
            this.BreakpointsButton.Click += new System.EventHandler(this.BreakpointsButton_Click);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(6, 27);
            // 
            // MemoryButton
            // 
            this.MemoryButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.MemoryButton.Image = global::ZeroWin.Properties.Resources.MemoryWindow_6537;
            this.MemoryButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.MemoryButton.Name = "MemoryButton";
            this.MemoryButton.Size = new System.Drawing.Size(24, 24);
            this.MemoryButton.Text = "Memory Viewer";
            this.MemoryButton.Click += new System.EventHandler(this.MemoryButton_Click);
            // 
            // RegistersButton
            // 
            this.RegistersButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.RegistersButton.Image = global::ZeroWin.Properties.Resources.RegistersWindow_6538;
            this.RegistersButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.RegistersButton.Name = "RegistersButton";
            this.RegistersButton.Size = new System.Drawing.Size(24, 24);
            this.RegistersButton.Text = "Registers";
            this.RegistersButton.Click += new System.EventHandler(this.RegistersButton_Click);
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(6, 27);
            // 
            // ProfilerButton
            // 
            this.ProfilerButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.ProfilerButton.Image = global::ZeroWin.Properties.Resources.Record_8791;
            this.ProfilerButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.ProfilerButton.Name = "ProfilerButton";
            this.ProfilerButton.Size = new System.Drawing.Size(24, 24);
            this.ProfilerButton.Text = "Profiler";
            this.ProfilerButton.ToolTipText = "Rec Star / Stop";
            // 
            // PokeMemoryButton
            // 
            this.PokeMemoryButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.PokeMemoryButton.Enabled = false;
            this.PokeMemoryButton.Image = global::ZeroWin.Properties.Resources.magnifier_16xLG;
            this.PokeMemoryButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.PokeMemoryButton.Name = "PokeMemoryButton";
            this.PokeMemoryButton.Size = new System.Drawing.Size(24, 24);
            this.PokeMemoryButton.Text = "Beam On/Off";
            this.PokeMemoryButton.ToolTipText = "Beam On/Off";
            this.PokeMemoryButton.Click += new System.EventHandler(this.PokeMemoryButton_Click);
            // 
            // callStackButton
            // 
            this.callStackButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.callStackButton.Enabled = false;
            this.callStackButton.Image = global::ZeroWin.Properties.Resources.CallStackWindow_6561;
            this.callStackButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.callStackButton.Name = "callStackButton";
            this.callStackButton.Size = new System.Drawing.Size(24, 24);
            this.callStackButton.Text = "Stack";
            this.callStackButton.Visible = false;
            this.callStackButton.Click += new System.EventHandler(this.callStackButton_Click);
            // 
            // jumpAddrTextBox4
            // 
            this.jumpAddrTextBox4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.jumpAddrTextBox4.Location = new System.Drawing.Point(95, 375);
            this.jumpAddrTextBox4.Name = "jumpAddrTextBox4";
            this.jumpAddrTextBox4.Size = new System.Drawing.Size(85, 27);
            this.jumpAddrTextBox4.TabIndex = 2;
            this.jumpAddrTextBox4.TextMaskFormat = System.Windows.Forms.MaskFormat.ExcludePromptAndLiterals;
            // 
            // jumpAddrButton
            // 
            this.jumpAddrButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.jumpAddrButton.Location = new System.Drawing.Point(185, 376);
            this.jumpAddrButton.Name = "jumpAddrButton";
            this.jumpAddrButton.Size = new System.Drawing.Size(44, 25);
            this.jumpAddrButton.TabIndex = 0;
            this.jumpAddrButton.Text = "JP";
            this.jumpAddrButton.UseVisualStyleBackColor = true;
            this.jumpAddrButton.Click += new System.EventHandler(this.jumpAddrButton_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.WhiteSmoke;
            this.dataGridView1.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.Window;
            this.dataGridView1.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.RaisedVertical;
            this.dataGridView1.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableAlwaysIncludeHeaderText;
            this.dataGridView1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.dataGridView1.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter;
            this.dataGridView1.EnableHeadersVisualStyles = false;
            this.dataGridView1.GridColor = System.Drawing.SystemColors.ControlLightLight;
            this.dataGridView1.Location = new System.Drawing.Point(3, 54);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Consolas", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.RowHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView1.RowHeadersWidth = 20;
            this.dataGridView1.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Consolas", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.NullValue = null;
            this.dataGridView1.RowsDefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridView1.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Consolas", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.dataGridView1.ShowRowErrors = false;
            this.dataGridView1.Size = new System.Drawing.Size(369, 318);
            this.dataGridView1.TabIndex = 10;
            this.dataGridView1.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.dataGridView1_RowPostPaint);
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(8, 379);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(72, 20);
            this.label1.TabIndex = 11;
            this.label1.Text = "Address";
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.debugToolStripMenuItem,
            this.breakpointsToolStripMenuItem,
            this.toolsToolStripMenuItem,
            this.viewToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(372, 28);
            this.menuStrip1.TabIndex = 13;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.saveToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(44, 24);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // saveToolStripMenuItem
            // 
            this.saveToolStripMenuItem.Image = global::ZeroWin.Properties.Resources.disk;
            this.saveToolStripMenuItem.Name = "saveToolStripMenuItem";
            this.saveToolStripMenuItem.Size = new System.Drawing.Size(124, 26);
            this.saveToolStripMenuItem.Text = "Save...";
            this.saveToolStripMenuItem.Click += new System.EventHandler(this.saveToolStripMenuItem_Click);
            // 
            // debugToolStripMenuItem
            // 
            this.debugToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.resumeEmulationToolStripMenuItem,
            this.runToCursorToolStripMenuItem,
            this.stopDebuggingToolStripMenuItem,
            this.toolStripSeparator1,
            this.stepOverToolStripMenuItem,
            this.stepInToolStripMenuItem,
            this.stepOutToolStripMenuItem});
            this.debugToolStripMenuItem.Name = "debugToolStripMenuItem";
            this.debugToolStripMenuItem.Size = new System.Drawing.Size(66, 24);
            this.debugToolStripMenuItem.Text = "Debug";
            // 
            // resumeEmulationToolStripMenuItem
            // 
            this.resumeEmulationToolStripMenuItem.Image = global::ZeroWin.Properties.Resources.PlayHS;
            this.resumeEmulationToolStripMenuItem.Name = "resumeEmulationToolStripMenuItem";
            this.resumeEmulationToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F5;
            this.resumeEmulationToolStripMenuItem.Size = new System.Drawing.Size(181, 26);
            this.resumeEmulationToolStripMenuItem.Text = "Resume";
            this.resumeEmulationToolStripMenuItem.Click += new System.EventHandler(this.resumeEmulationToolStripMenuItem_Click);
            // 
            // runToCursorToolStripMenuItem
            // 
            this.runToCursorToolStripMenuItem.Image = global::ZeroWin.Properties.Resources.GoToSourceCode_6546;
            this.runToCursorToolStripMenuItem.Name = "runToCursorToolStripMenuItem";
            this.runToCursorToolStripMenuItem.Size = new System.Drawing.Size(181, 26);
            this.runToCursorToolStripMenuItem.Text = "Run To Cursor";
            this.runToCursorToolStripMenuItem.Click += new System.EventHandler(this.runToCursorToolStripMenuItem_Click);
            // 
            // stopDebuggingToolStripMenuItem
            // 
            this.stopDebuggingToolStripMenuItem.Image = global::ZeroWin.Properties.Resources.StopHS;
            this.stopDebuggingToolStripMenuItem.Name = "stopDebuggingToolStripMenuItem";
            this.stopDebuggingToolStripMenuItem.Size = new System.Drawing.Size(181, 26);
            this.stopDebuggingToolStripMenuItem.Text = "Stop";
            this.stopDebuggingToolStripMenuItem.Click += new System.EventHandler(this.stopDebuggingToolStripMenuItem_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(178, 6);
            // 
            // stepOverToolStripMenuItem
            // 
            this.stepOverToolStripMenuItem.Image = global::ZeroWin.Properties.Resources.StepOver_6328;
            this.stepOverToolStripMenuItem.Name = "stepOverToolStripMenuItem";
            this.stepOverToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F10;
            this.stepOverToolStripMenuItem.Size = new System.Drawing.Size(181, 26);
            this.stepOverToolStripMenuItem.Text = "Step Over";
            this.stepOverToolStripMenuItem.Click += new System.EventHandler(this.stepOverToolStripMenuItem_Click);
            // 
            // stepInToolStripMenuItem
            // 
            this.stepInToolStripMenuItem.Image = global::ZeroWin.Properties.Resources.StepIn_6326;
            this.stepInToolStripMenuItem.Name = "stepInToolStripMenuItem";
            this.stepInToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F11;
            this.stepInToolStripMenuItem.Size = new System.Drawing.Size(181, 26);
            this.stepInToolStripMenuItem.Text = "Step In";
            this.stepInToolStripMenuItem.Click += new System.EventHandler(this.stepInToolStripMenuItem_Click);
            // 
            // stepOutToolStripMenuItem
            // 
            this.stepOutToolStripMenuItem.Image = global::ZeroWin.Properties.Resources.Stepout_6327;
            this.stepOutToolStripMenuItem.Name = "stepOutToolStripMenuItem";
            this.stepOutToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F12;
            this.stepOutToolStripMenuItem.Size = new System.Drawing.Size(181, 26);
            this.stepOutToolStripMenuItem.Text = "Step Out";
            this.stepOutToolStripMenuItem.Click += new System.EventHandler(this.stepOutToolStripMenuItem_Click);
            // 
            // breakpointsToolStripMenuItem
            // 
            this.breakpointsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toggleBreakpointToolStripMenuItem,
            this.clearAllBreakpointsToolStripMenuItem});
            this.breakpointsToolStripMenuItem.Name = "breakpointsToolStripMenuItem";
            this.breakpointsToolStripMenuItem.Size = new System.Drawing.Size(99, 24);
            this.breakpointsToolStripMenuItem.Text = "Breakpoints";
            // 
            // toggleBreakpointToolStripMenuItem
            // 
            this.toggleBreakpointToolStripMenuItem.Image = global::ZeroWin.Properties.Resources.ToggleAllBreakpoints_6554;
            this.toggleBreakpointToolStripMenuItem.Name = "toggleBreakpointToolStripMenuItem";
            this.toggleBreakpointToolStripMenuItem.Size = new System.Drawing.Size(222, 26);
            this.toggleBreakpointToolStripMenuItem.Text = "Toggle Breakpoint";
            this.toggleBreakpointToolStripMenuItem.Click += new System.EventHandler(this.toggleBreakpointToolStripMenuItem_Click);
            // 
            // clearAllBreakpointsToolStripMenuItem
            // 
            this.clearAllBreakpointsToolStripMenuItem.Image = global::ZeroWin.Properties.Resources.clearallbreakpoints_6551;
            this.clearAllBreakpointsToolStripMenuItem.Name = "clearAllBreakpointsToolStripMenuItem";
            this.clearAllBreakpointsToolStripMenuItem.Size = new System.Drawing.Size(222, 26);
            this.clearAllBreakpointsToolStripMenuItem.Text = "Clear All Breakpoints";
            this.clearAllBreakpointsToolStripMenuItem.Click += new System.EventHandler(this.clearAllBreakpointsToolStripMenuItem_Click);
            // 
            // toolsToolStripMenuItem
            // 
            this.toolsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.breakpointsEditorToolStripMenuItem,
            this.machineStateToolStripMenuItem,
            this.memoryViewerToolStripMenuItem,
            this.registersToolStripMenuItem,
            this.toolStripSeparator6,
            this.executionLogToolStripMenuItem,
            this.pokeMemoryToolStripMenuItem,
            this.systemToolStripMenuItem});
            this.toolsToolStripMenuItem.Name = "toolsToolStripMenuItem";
            this.toolsToolStripMenuItem.Size = new System.Drawing.Size(56, 24);
            this.toolsToolStripMenuItem.Text = "Tools";
            // 
            // breakpointsEditorToolStripMenuItem
            // 
            this.breakpointsEditorToolStripMenuItem.Image = global::ZeroWin.Properties.Resources.BreakpointsWindow_6557;
            this.breakpointsEditorToolStripMenuItem.Name = "breakpointsEditorToolStripMenuItem";
            this.breakpointsEditorToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.B)));
            this.breakpointsEditorToolStripMenuItem.Size = new System.Drawing.Size(253, 26);
            this.breakpointsEditorToolStripMenuItem.Text = "Breakpoints Editor";
            this.breakpointsEditorToolStripMenuItem.Click += new System.EventHandler(this.breakpointsEditorToolStripMenuItem_Click);
            // 
            // machineStateToolStripMenuItem
            // 
            this.machineStateToolStripMenuItem.Name = "machineStateToolStripMenuItem";
            this.machineStateToolStripMenuItem.Size = new System.Drawing.Size(253, 26);
            // 
            // memoryViewerToolStripMenuItem
            // 
            this.memoryViewerToolStripMenuItem.Image = global::ZeroWin.Properties.Resources.MemoryWindow_6537;
            this.memoryViewerToolStripMenuItem.Name = "memoryViewerToolStripMenuItem";
            this.memoryViewerToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.V)));
            this.memoryViewerToolStripMenuItem.Size = new System.Drawing.Size(253, 26);
            this.memoryViewerToolStripMenuItem.Text = "Memory Viewer";
            this.memoryViewerToolStripMenuItem.Click += new System.EventHandler(this.memoryViewerToolStripMenuItem_Click);
            // 
            // registersToolStripMenuItem
            // 
            this.registersToolStripMenuItem.Image = global::ZeroWin.Properties.Resources.RegistersWindow_6538;
            this.registersToolStripMenuItem.Name = "registersToolStripMenuItem";
            this.registersToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.R)));
            this.registersToolStripMenuItem.Size = new System.Drawing.Size(253, 26);
            this.registersToolStripMenuItem.Text = "Registers";
            this.registersToolStripMenuItem.Click += new System.EventHandler(this.registersToolStripMenuItem_Click);
            // 
            // toolStripSeparator6
            // 
            this.toolStripSeparator6.Name = "toolStripSeparator6";
            this.toolStripSeparator6.Size = new System.Drawing.Size(250, 6);
            // 
            // executionLogToolStripMenuItem
            // 
            this.executionLogToolStripMenuItem.Image = global::ZeroWin.Properties.Resources.rzxPlay16x16;
            this.executionLogToolStripMenuItem.Name = "executionLogToolStripMenuItem";
            this.executionLogToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.L)));
            this.executionLogToolStripMenuItem.Size = new System.Drawing.Size(253, 26);
            this.executionLogToolStripMenuItem.Text = "Rec Star / Stop";
            // 
            // pokeMemoryToolStripMenuItem
            // 
            this.pokeMemoryToolStripMenuItem.Image = global::ZeroWin.Properties.Resources.PencilTool_206;
            this.pokeMemoryToolStripMenuItem.Name = "pokeMemoryToolStripMenuItem";
            this.pokeMemoryToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.P)));
            this.pokeMemoryToolStripMenuItem.Size = new System.Drawing.Size(253, 26);
            this.pokeMemoryToolStripMenuItem.Text = "Poke Memory";
            this.pokeMemoryToolStripMenuItem.Click += new System.EventHandler(this.pokeMemoryToolStripMenuItem_Click);
            // 
            // systemToolStripMenuItem
            // 
            this.systemToolStripMenuItem.Image = global::ZeroWin.Properties.Resources.logStart;
            this.systemToolStripMenuItem.Name = "systemToolStripMenuItem";
            this.systemToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.V)));
            this.systemToolStripMenuItem.Size = new System.Drawing.Size(253, 26);
            this.systemToolStripMenuItem.Text = "Custom Labels";
            this.systemToolStripMenuItem.Click += new System.EventHandler(this.systemToolStripMenuItem_Click);
            // 
            // viewToolStripMenuItem
            // 
            this.viewToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aSCIICharactersToolStripMenuItem,
            this.numbersInHexToolStripMenuItem,
            this.systemVariablesToolStripMenuItem,
            this.labelsToolStripMenuItem});
            this.viewToolStripMenuItem.Name = "viewToolStripMenuItem";
            this.viewToolStripMenuItem.Size = new System.Drawing.Size(53, 24);
            this.viewToolStripMenuItem.Text = "View";
            // 
            // aSCIICharactersToolStripMenuItem
            // 
            this.aSCIICharactersToolStripMenuItem.CheckOnClick = true;
            this.aSCIICharactersToolStripMenuItem.Name = "aSCIICharactersToolStripMenuItem";
            this.aSCIICharactersToolStripMenuItem.Size = new System.Drawing.Size(195, 26);
            this.aSCIICharactersToolStripMenuItem.Text = "ASCII characters";
            this.aSCIICharactersToolStripMenuItem.CheckedChanged += new System.EventHandler(this.aSCIICharactersToolStripMenuItem_CheckedChanged);
            // 
            // numbersInHexToolStripMenuItem
            // 
            this.numbersInHexToolStripMenuItem.CheckOnClick = true;
            this.numbersInHexToolStripMenuItem.Name = "numbersInHexToolStripMenuItem";
            this.numbersInHexToolStripMenuItem.Size = new System.Drawing.Size(195, 26);
            this.numbersInHexToolStripMenuItem.Text = "Hex Numbers";
            this.numbersInHexToolStripMenuItem.CheckedChanged += new System.EventHandler(this.numbersInHexToolStripMenuItem_CheckedChanged);
            // 
            // systemVariablesToolStripMenuItem
            // 
            this.systemVariablesToolStripMenuItem.Checked = true;
            this.systemVariablesToolStripMenuItem.CheckOnClick = true;
            this.systemVariablesToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked;
            this.systemVariablesToolStripMenuItem.Name = "systemVariablesToolStripMenuItem";
            this.systemVariablesToolStripMenuItem.Size = new System.Drawing.Size(195, 26);
            this.systemVariablesToolStripMenuItem.Text = "System Variables";
            this.systemVariablesToolStripMenuItem.CheckedChanged += new System.EventHandler(this.systemVariablesToolStripMenuItem_CheckedChanged);
            // 
            // labelsToolStripMenuItem
            // 
            this.labelsToolStripMenuItem.CheckOnClick = true;
            this.labelsToolStripMenuItem.Name = "labelsToolStripMenuItem";
            this.labelsToolStripMenuItem.Size = new System.Drawing.Size(195, 26);
            this.labelsToolStripMenuItem.Text = "Labels !";
            this.labelsToolStripMenuItem.ToolTipText = "Visualize custom labels";
            this.labelsToolStripMenuItem.CheckedChanged += new System.EventHandler(this.labelsToolStripMenuItem_CheckedChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(229, 384);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(0, 20);
            this.label2.TabIndex = 15;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(18, 382);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(0, 20);
            this.label3.TabIndex = 16;
            // 
            // monitorStatusLabel
            // 
            this.monitorStatusLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.monitorStatusLabel.Name = "monitorStatusLabel";
            this.monitorStatusLabel.Size = new System.Drawing.Size(0, 17);
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.BorderStyle = System.Windows.Forms.Border3DStyle.Bump;
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(0, 17);
            // 
            // statusStrip1
            // 
            this.statusStrip1.AutoSize = false;
            this.statusStrip1.BackColor = System.Drawing.SystemColors.Control;
            this.statusStrip1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.statusStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.monitorStatusLabel,
            this.toolStripStatusLabel1});
            this.statusStrip1.Location = new System.Drawing.Point(0, 407);
            this.statusStrip1.Margin = new System.Windows.Forms.Padding(8);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Padding = new System.Windows.Forms.Padding(1, 0, 16, 0);
            this.statusStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.ManagerRenderMode;
            this.statusStrip1.Size = new System.Drawing.Size(372, 22);
            this.statusStrip1.SizingGrip = false;
            this.statusStrip1.TabIndex = 6;
            this.statusStrip1.Text = "Monitor Status";
            // 
            // callStack
            // 
            this.callStack.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.callStack.Image = global::ZeroWin.Properties.Resources.DisassemblyWindow_6536;
            this.callStack.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.callStack.Name = "callStack";
            this.callStack.Size = new System.Drawing.Size(24, 24);
            this.callStack.Text = "toolStripButton1";
            this.callStack.Click += new System.EventHandler(this.callStack_Click);
            // 
            // MonitorRef
            // 
            this.AcceptButton = this.jumpAddrButton;
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(372, 429);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.jumpAddrTextBox4);
            this.Controls.Add(this.jumpAddrButton);
            this.Controls.Add(this.toolStrip2);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.menuStrip1);
            this.Font = new System.Drawing.Font("Consolas", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "MonitorRef";
            this.Text = "Monitor";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Monitor_FormClosing);
            this.Load += new System.EventHandler(this.Monitor_Load);
            this.Shown += new System.EventHandler(this.Monitor_Shown);
            this.VisibleChanged += new System.EventHandler(this.Monitor_VisibleChanged);
            this.toolStrip2.ResumeLayout(false);
            this.toolStrip2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.ToolStrip toolStrip2;
        private System.Windows.Forms.ToolStripButton ResumeEmulationButton;
        private System.Windows.Forms.ToolStripButton RunToCursorButton;
        private System.Windows.Forms.ToolStripButton StepInButton;
        private System.Windows.Forms.ToolStripButton StepOutButton;
        private System.Windows.Forms.ToolStripButton StopDebuggerButton;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripButton StepOverButton;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripButton ToggleBreakpointButton;
        private System.Windows.Forms.ToolStripButton ClearAllBreakpointsButton;
        private System.Windows.Forms.ToolStripButton BreakpointsButton;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripButton MemoryButton;
        private System.Windows.Forms.ToolStripButton RegistersButton;
        private System.Windows.Forms.ToolStripButton ProfilerButton;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.ToolStripButton PokeMemoryButton;
        private System.Windows.Forms.Button jumpAddrButton;
        private System.Windows.Forms.MaskedTextBox jumpAddrTextBox4;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem debugToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem resumeEmulationToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem runToCursorToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem stopDebuggingToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem stepInToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem stepOutToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem stepOverToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem breakpointsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toggleBreakpointToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem clearAllBreakpointsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem breakpointsEditorToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem memoryViewerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem registersToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem executionLogToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pokeMemoryToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem viewToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aSCIICharactersToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem numbersInHexToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem systemVariablesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem machineStateToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator6;
        private System.Windows.Forms.ToolStripButton callStackButton;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ToolStripStatusLabel monitorStatusLabel;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripMenuItem systemToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem labelsToolStripMenuItem;
        private System.Windows.Forms.ToolStripButton callStack;
    }
}