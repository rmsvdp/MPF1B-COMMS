-------------------
Using the Keyboard
-------------------
Zero emulates the MPF 1b keyboard faithfully and provides some additional functionality via the PC keyboard.

The following Spectial key's combinations are used by Zero:

F1		= GO
F3 		= Debugger
F4		= Search Infoseek
F5     		= ADDR
F6		= DATA
F7		= CBR
F8		= SBR
F9		= RELA
F10		= DEL
F11		= INS
F12		= MOVE
R		= RS ( Soft Reset)
+		= + Key
-		= - Key
L		= TAPE RD		Not implemented, use Load Binary Menu
S		= TAPE WR		Not implemented, use Save Binary Menu
M		= MONI			Not implemented
--------------------
About Zero
--------------------

Programmed by rmsvdp on 2025

Zero is a Multitech Microprofessor 1b emulator written entirely on the .NET platform, using C#, and requires .NET framework 4.71

See About ... option menu for credits!

--------------------------------------------------------------------------------------
